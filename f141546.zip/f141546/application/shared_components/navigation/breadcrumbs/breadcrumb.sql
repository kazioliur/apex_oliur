prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(21352564009959582961)
,p_name=>'Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(21352564278831582961)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(22705764945786032050)
,p_short_name=>'Department '
,p_link=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(22705766110605032054)
,p_parent_id=>wwv_flow_api.id(22705764945786032050)
,p_short_name=>'Department Entry Form'
,p_link=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(22708160761520148905)
,p_short_name=>'Designation Information'
,p_link=>'f?p=&APP_ID.:10:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(22708161934940148907)
,p_parent_id=>wwv_flow_api.id(22708160761520148905)
,p_short_name=>'Designation Entry Form'
,p_link=>'f?p=&APP_ID.:11:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24400914354800174229)
,p_short_name=>'User Type Report'
,p_link=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24400915682651174231)
,p_parent_id=>wwv_flow_api.id(24400914354800174229)
,p_short_name=>'User Type Form'
,p_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24408658164683702587)
,p_short_name=>'User Status Report'
,p_link=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24408659210169702596)
,p_parent_id=>wwv_flow_api.id(24408658164683702587)
,p_short_name=>'User Status Form'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24416999112490457961)
,p_short_name=>'User Information'
,p_link=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24417200395787457963)
,p_parent_id=>wwv_flow_api.id(24416999112490457961)
,p_short_name=>'Add user'
,p_link=>'f?p=&APP_ID.:19:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24735490631420914851)
,p_short_name=>'Purchase Item Information'
,p_link=>'f?p=&APP_ID.:25:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24735491848154914853)
,p_parent_id=>wwv_flow_api.id(24735490631420914851)
,p_short_name=>'Purchase Item Form'
,p_link=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24746661291788218621)
,p_parent_id=>0
,p_short_name=>'Supplier Report'
,p_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24746662447869218624)
,p_parent_id=>wwv_flow_api.id(24746661291788218621)
,p_short_name=>'Supplier Form'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24813811752199881267)
,p_short_name=>'Guest Report'
,p_link=>'f?p=&APP_ID.:22:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24813812902443881269)
,p_parent_id=>wwv_flow_api.id(24813811752199881267)
,p_short_name=>'Guest Form'
,p_link=>'f?p=&APP_ID.:23:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24894149144204151849)
,p_short_name=>'Expense Type Report'
,p_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(24894150361859151852)
,p_parent_id=>wwv_flow_api.id(24894149144204151849)
,p_short_name=>'Expense Type from'
,p_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25206649818087172575)
,p_short_name=>'Employee  Report'
,p_link=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25206651026784172577)
,p_parent_id=>wwv_flow_api.id(25206649818087172575)
,p_short_name=>'Employee Form'
,p_link=>'f?p=&APP_ID.:21:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25864030997488223629)
,p_short_name=>'Supplier  Payment Report'
,p_link=>'f?p=&APP_ID.:33:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25864032186118223632)
,p_parent_id=>wwv_flow_api.id(25864030997488223629)
,p_short_name=>'Supplier  Payment  Form'
,p_link=>'f?p=&APP_ID.:34:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25877141991556814412)
,p_short_name=>'Food Menu Report'
,p_link=>'f?p=&APP_ID.:35:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25877143293944814415)
,p_parent_id=>wwv_flow_api.id(25877141991556814412)
,p_short_name=>'Food Menu Form'
,p_link=>'f?p=&APP_ID.:36:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(26855032316180733436)
,p_short_name=>'User Information Report'
,p_link=>'f?p=&APP_ID.:31:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(26855033597703733438)
,p_parent_id=>wwv_flow_api.id(26855032316180733436)
,p_short_name=>'User Entry Form'
,p_link=>'f?p=&APP_ID.:32:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(27561583607433180410)
,p_short_name=>'Expense Entry Form'
,p_link=>'f?p=&APP_ID.:37:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(32802409473573880840)
,p_short_name=>'Menu_names_report'
,p_link=>'f?p=&APP_ID.:59:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>59
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(32802410650374880843)
,p_parent_id=>wwv_flow_api.id(32802409473573880840)
,p_short_name=>'Menus Report'
,p_link=>'f?p=&APP_ID.:62:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>62
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(43058357093511500214)
,p_short_name=>'report'
,p_link=>'f?p=&APP_ID.:86:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(43058358280628500216)
,p_parent_id=>wwv_flow_api.id(43058357093511500214)
,p_short_name=>'entry page'
,p_link=>'f?p=&APP_ID.:87:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>87
);
wwv_flow_api.component_end;
end;
/
