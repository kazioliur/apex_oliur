prompt --application/shared_components/navigation/breadcrumbs/food_menu_report
begin
--   Manifest
--     MENU: Food Menu Report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(25780353021401080791)
,p_name=>'Food Menu Report'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(25836593612634386587)
,p_parent_id=>0
,p_short_name=>'Guest Report'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_api.component_end;
end;
/
