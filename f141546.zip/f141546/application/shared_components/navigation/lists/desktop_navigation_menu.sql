prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(21352564536546582962)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21352821114209583090)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22712149235080804967)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Administrator'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =1',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_display_sequence=>602
,p_list_item_link_text=>'Form'
,p_list_item_icon=>'fa-book'
,p_parent_list_item_id=>wwv_flow_api.id(22712149235080804967)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(24400913715837174228)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'User Type'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layouts-grid-2x'
,p_parent_list_item_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(24408657533424702586)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'User Status'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock-password'
,p_parent_list_item_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,7'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(26855031726329733429)
,p_list_item_display_sequence=>392
,p_list_item_link_text=>'Add User'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_parent_list_item_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31,32'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32802408861610880836)
,p_list_item_display_sequence=>732
,p_list_item_link_text=>'Menu Name'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-contacts'
,p_parent_list_item_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'59,62'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33280827531047313760)
,p_list_item_display_sequence=>782
,p_list_item_link_text=>'Menu Access Control'
,p_list_item_link_target=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock-x'
,p_parent_list_item_id=>wwv_flow_api.id(32135778150804901921)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'75'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32136017565106263900)
,p_list_item_display_sequence=>612
,p_list_item_link_text=>'Report'
,p_list_item_icon=>'fa-combo-chart'
,p_parent_list_item_id=>wwv_flow_api.id(22712149235080804967)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32171865498163360103)
,p_list_item_display_sequence=>632
,p_list_item_link_text=>'Userstatus-Wise User Information'
,p_parent_list_item_id=>wwv_flow_api.id(32136017565106263900)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22717407686245567869)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'HRM'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =2',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13,20,20,50,55,82,83'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(30999824295773514222)
,p_list_item_display_sequence=>522
,p_list_item_link_text=>'Form'
,p_list_item_icon=>'fa-book'
,p_parent_list_item_id=>wwv_flow_api.id(22717407686245567869)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22705764347348032044)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Department'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book-o'
,p_parent_list_item_id=>wwv_flow_api.id(30999824295773514222)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8,9'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22708160115890148905)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Designation'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-image-o'
,p_parent_list_item_id=>wwv_flow_api.id(30999824295773514222)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,11'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25206648949806172568)
,p_list_item_display_sequence=>352
,p_list_item_link_text=>'Employee'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card-o'
,p_parent_list_item_id=>wwv_flow_api.id(30999824295773514222)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20,21'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_display_sequence=>532
,p_list_item_link_text=>'Report'
,p_list_item_icon=>'fa-combo-chart'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =10',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_parent_list_item_id=>wwv_flow_api.id(22717407686245567869)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31001054537288609952)
,p_list_item_display_sequence=>542
,p_list_item_link_text=>'Department-Wise Employee Information'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'50'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32048407119723134790)
,p_list_item_display_sequence=>592
,p_list_item_link_text=>'Year-Wise Employee Assign in  a Department'
,p_list_item_link_target=>'f?p=&APP_ID.:55:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'55'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32146514798144654996)
,p_list_item_display_sequence=>622
,p_list_item_link_text=>'Usertype-Wise  User Information'
,p_list_item_link_target=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'56'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35080627639099743434)
,p_list_item_display_sequence=>862
,p_list_item_link_text=>'Employee Contact Details'
,p_list_item_link_target=>'f?p=&APP_ID.:82:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'82'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(35094633220936560651)
,p_list_item_display_sequence=>872
,p_list_item_link_text=>'Department-Wise Employee'
,p_list_item_link_target=>'f?p=&APP_ID.:83:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(31000031115940158787)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'83'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22717587250714580450)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Purchase'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =3',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14,12,25,27,31,32,39,40,41,45,51,52,53,71,72,73,76'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29369882972604770249)
,p_list_item_display_sequence=>472
,p_list_item_link_text=>'Form'
,p_list_item_icon=>'fa-book'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =8',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_parent_list_item_id=>wwv_flow_api.id(22717587250714580450)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(24746660345271218613)
,p_list_item_display_sequence=>309
,p_list_item_link_text=>'Supplier'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-pin'
,p_parent_list_item_id=>wwv_flow_api.id(29369882972604770249)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27,28'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(24735489715684914850)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'Purchase Item'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-balance-scale'
,p_parent_list_item_id=>wwv_flow_api.id(29369882972604770249)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25,26'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(26474528629373197534)
,p_list_item_display_sequence=>382
,p_list_item_link_text=>'Purchase'
,p_list_item_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_parent_list_item_id=>wwv_flow_api.id(29369882972604770249)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'41'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_display_sequence=>482
,p_list_item_link_text=>'Report'
,p_list_item_icon=>'fa-combo-chart'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =9',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_parent_list_item_id=>wwv_flow_api.id(22717587250714580450)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33454442451180049793)
,p_list_item_display_sequence=>478
,p_list_item_link_text=>'Invoice-Wise Purchase Report'
,p_list_item_link_target=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'69'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31360712935403489358)
,p_list_item_display_sequence=>488
,p_list_item_link_text=>'Daily Purchase Report'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'51'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34160864982863633730)
,p_list_item_display_sequence=>489
,p_list_item_link_text=>'Period-Wise Purchase Report'
,p_list_item_link_target=>'f?p=&APP_ID.:76:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'76'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31427253821946167673)
,p_list_item_display_sequence=>562
,p_list_item_link_text=>'Period-Wise Purchase Summary'
,p_list_item_link_target=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'52'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(31637627987489205171)
,p_list_item_display_sequence=>572
,p_list_item_link_text=>'Supplier Wise Current Due'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'53'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32941933436591366742)
,p_list_item_display_sequence=>752
,p_list_item_link_text=>'Supplier-Wise Purchase Summary'
,p_list_item_link_target=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'71'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32950025518321902933)
,p_list_item_display_sequence=>762
,p_list_item_link_text=>'Supplier Contact Details'
,p_list_item_link_target=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'72'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32968625032042280694)
,p_list_item_display_sequence=>772
,p_list_item_link_text=>'Purchasing Item Information'
,p_list_item_link_target=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(29369358104126136354)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'73'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22717179925477116588)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sales'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =4',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15,35,38,42,43,44,47,49,46,48,54,58,60,61,63,57,64,65,66,67,84'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28790301538508420242)
,p_list_item_display_sequence=>419
,p_list_item_link_text=>'Form'
,p_list_item_icon=>'fa-book'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =6',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_parent_list_item_id=>wwv_flow_api.id(22717179925477116588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22780306796528351168)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Guest'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-male'
,p_parent_list_item_id=>wwv_flow_api.id(28790301538508420242)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25877141000628814410)
,p_list_item_display_sequence=>372
,p_list_item_link_text=>'Food Menu'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-coffee'
,p_parent_list_item_id=>wwv_flow_api.id(28790301538508420242)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'35,36'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28894983008057266259)
,p_list_item_display_sequence=>452
,p_list_item_link_text=>'Sales'
,p_list_item_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-credit-card-terminal'
,p_parent_list_item_id=>wwv_flow_api.id(28790301538508420242)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'47'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_display_sequence=>422
,p_list_item_link_text=>'Report'
,p_list_item_icon=>'fa-combo-chart'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =7',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_parent_list_item_id=>wwv_flow_api.id(22717179925477116588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28813264096916934263)
,p_list_item_display_sequence=>432
,p_list_item_link_text=>'Invoice-Wise Sales Report'
,p_list_item_link_target=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'43'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29005762051595658492)
,p_list_item_display_sequence=>433
,p_list_item_link_text=>'Daily Sales Report'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'49'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28858557999509781611)
,p_list_item_display_sequence=>442
,p_list_item_link_text=>'Period-Wise Sales Report'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'44'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32046047048425040371)
,p_list_item_display_sequence=>501
,p_list_item_link_text=>'Monthly Food Menu Sales'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'54'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(30962378686930413991)
,p_list_item_display_sequence=>502
,p_list_item_link_text=>'Monthly Average Order Value'
,p_list_item_link_target=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'46'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32519684277665761505)
,p_list_item_display_sequence=>511
,p_list_item_link_text=>'Monthly Customer Served'
,p_list_item_link_target=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'67'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(30965570505995532874)
,p_list_item_display_sequence=>512
,p_list_item_link_text=>'Guest-Wise Food Menu Consume'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'48'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32276282361733338344)
,p_list_item_display_sequence=>642
,p_list_item_link_text=>'Period-Wise Sales Summary'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'58'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32333803354954848338)
,p_list_item_display_sequence=>652
,p_list_item_link_text=>'Guest Information Report'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'60'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32345187641050854469)
,p_list_item_display_sequence=>662
,p_list_item_link_text=>'Guest Point Earning Information'
,p_list_item_link_target=>'f?p=&APP_ID.:61:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'61'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32487154531441755847)
,p_list_item_display_sequence=>672
,p_list_item_link_text=>'Top 10 Past Moving Food Menu'
,p_list_item_link_target=>'f?p=&APP_ID.:63:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'63'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32508077701657242748)
,p_list_item_display_sequence=>682
,p_list_item_link_text=>'Top 10 Best Earning Food Menu'
,p_list_item_link_target=>'f?p=&APP_ID.:57:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'57'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32515538584385474571)
,p_list_item_display_sequence=>692
,p_list_item_link_text=>'10 Slow Moving Product'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'64'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32516921980033237532)
,p_list_item_display_sequence=>702
,p_list_item_link_text=>'Income-Wise Food Menu Ranking'
,p_list_item_link_target=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'65'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32517632957107264534)
,p_list_item_display_sequence=>712
,p_list_item_link_text=>'Sales Quantity-Wise Food Menu Ranking'
,p_list_item_link_target=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28790058524728414817)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'66'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(11309172200962657492)
,p_list_item_display_sequence=>892
,p_list_item_link_text=>'HTML REPORT'
,p_parent_list_item_id=>wwv_flow_api.id(22717179925477116588)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'84'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(22717938059196593971)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Accounts'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V(''APP_USER'')',
'from   dual',
'where  V(''APP_USER'') in (select upper(MENU_ACCESS_CONTROL_M.USERNAME)',
'                         from    MENU_ACCESS_CONTROL_M,MENU_ACCESS_CONTROL_D',
'                         where   MENU_ACCESS_CONTROL_M.USERNAME = MENU_ACCESS_CONTROL_D.USERNAME',
'                          AND    MENU_ACCESS_CONTROL_D.MENU_ID =5',
'                          AND    MENU_ACCESS_CONTROL_D.ACCESS_STATUS=''Yes'')'))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16,2,2,33,33,37,77,78,79,80,81'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33380017601488568908)
,p_list_item_display_sequence=>792
,p_list_item_link_text=>'Form'
,p_list_item_icon=>'fa-book'
,p_parent_list_item_id=>wwv_flow_api.id(22717938059196593971)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(24894148260775151847)
,p_list_item_display_sequence=>331
,p_list_item_link_text=>'Expense Type'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tasks'
,p_parent_list_item_id=>wwv_flow_api.id(33380017601488568908)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,3'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25864030080917223627)
,p_list_item_display_sequence=>362
,p_list_item_link_text=>'Supplier  Payment'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_parent_list_item_id=>wwv_flow_api.id(33380017601488568908)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'33,34'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27561582541658180408)
,p_list_item_display_sequence=>412
,p_list_item_link_text=>'Expense'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-notebook'
,p_parent_list_item_id=>wwv_flow_api.id(33380017601488568908)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'37'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_display_sequence=>802
,p_list_item_link_text=>'Report'
,p_list_item_icon=>'fa-combo-chart'
,p_parent_list_item_id=>wwv_flow_api.id(22717938059196593971)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34369120456735673640)
,p_list_item_display_sequence=>812
,p_list_item_link_text=>'Business Status'
,p_list_item_link_target=>'f?p=&APP_ID.:77:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'77'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34605125327725748775)
,p_list_item_display_sequence=>822
,p_list_item_link_text=>'Expense Type-Wise Expense Report'
,p_list_item_link_target=>'f?p=&APP_ID.:78:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'78'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34624437408570808908)
,p_list_item_display_sequence=>832
,p_list_item_link_text=>'Period-Wise Expense Details'
,p_list_item_link_target=>'f?p=&APP_ID.:79:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'79'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34939338972858797899)
,p_list_item_display_sequence=>842
,p_list_item_link_text=>'Period-Wise Supplier Payment Details'
,p_list_item_link_target=>'f?p=&APP_ID.:80:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'80'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34944082846216099660)
,p_list_item_display_sequence=>852
,p_list_item_link_text=>'Supplier-Wise Due Paid Details'
,p_list_item_link_target=>'f?p=&APP_ID.:81:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(33380586295572618036)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'81'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4817675357273258957)
,p_list_item_display_sequence=>882
,p_list_item_link_text=>'Report Manager (REP)'
,p_list_item_link_target=>'https://apex.oracle.com/pls/apex/ddd45_1261366_workspace/r/hr33/home?session=8044318227294'
,p_list_item_icon=>'fa-combo-chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
