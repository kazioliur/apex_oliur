prompt --application/shared_components/security/authentications/user_authentication
begin
--   Manifest
--     AUTHENTICATION: USER_AUTHENTICATION
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_authentication(
 p_id=>wwv_flow_api.id(24216902924104101287)
,p_name=>'USER_AUTHENTICATION'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'USER_AUTHENTICATION'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUNCTION  USER_AUTHENTICATION(',
'    P_USERNAME IN VARCHAR2,',
'    P_PASSWORD  IN VARCHAR2',
')',
'RETURN BOOLEAN',
'',
'AS',
'',
'V_USER_INFO  NUMBER:= 0;',
'',
'',
'BEGIN',
'',
'SELECT 1',
'INTO  V_USER_INFO',
'FROM  USER_INFO',
'WHERE UPPER(USERNAME) = UPPER(P_USERNAME)',
'AND   PASSWORD   = P_PASSWORD;',
'',
'RETURN TRUE;',
'',
'EXCEPTION ',
'WHEN NO_DATA_FOUND THEN',
'RETURN FALSE;',
'END;',
''))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_api.component_end;
end;
/
