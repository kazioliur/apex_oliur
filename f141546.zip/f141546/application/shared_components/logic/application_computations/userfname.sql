prompt --application/shared_components/logic/application_computations/userfname
begin
--   Manifest
--     APPLICATION COMPUTATION: USERFNAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_flow_computation(
 p_id=>wwv_flow_api.id(5281573320802338693)
,p_computation_sequence=>10
,p_computation_item=>'USERFNAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT FIRST_NAME||'' ''||LAST_NAME  OK',
' FROM EMPLOYEE',
' WHERE EMPLOYEE_ID =(SELECT EMPLOYEE_ID FROM USER_INFO WHERE USERNAME = :USERNAME);'))
);
wwv_flow_api.component_end;
end;
/
