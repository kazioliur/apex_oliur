prompt --application/shared_components/user_interface/lovs/guest_name_guest_id
begin
--   Manifest
--     GUEST_NAME_GUEST_ID
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(27021886811124998313)
,p_lov_name=>'GUEST_NAME_GUEST_ID'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select guest_name,guest_id',
'from   guest',
'order  by guest_id desc;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'GUEST_ID'
,p_display_column_name=>'GUEST_ID'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(34473614486987708409)
,p_query_column_name=>'GUEST_ID'
,p_heading=>'Guest  ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(34473614876294708409)
,p_query_column_name=>'GUEST_NAME'
,p_heading=>'Guest Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.component_end;
end;
/
