prompt --application/shared_components/user_interface/lovs/purchase_item_name
begin
--   Manifest
--     PURCHASE_ITEM_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(26378730628098931295)
,p_lov_name=>'PURCHASE_ITEM_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'PURCHASE_ITEM'
,p_return_column_name=>'PURCHASE_ITEM_ID'
,p_display_column_name=>'PURCHASE_ITEM_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'PURCHASE_ITEM_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(26380834152025058092)
,p_query_column_name=>'PURCHASE_ITEM_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(26380834457178058093)
,p_query_column_name=>'PURCHASE_ITEM_NAME'
,p_heading=>'Purchase Item Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.component_end;
end;
/
