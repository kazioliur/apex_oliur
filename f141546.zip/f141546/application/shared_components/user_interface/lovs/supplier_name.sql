prompt --application/shared_components/user_interface/lovs/supplier_name
begin
--   Manifest
--     SUPPLIER_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(25866974875972852181)
,p_lov_name=>'SUPPLIER_NAME'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select supplier_name, supplier_id',
'from   supplier',
'order  by supplier_id desc;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'SUPPLIER_ID'
,p_display_column_name=>'SUPPLIER_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(34353109252147323168)
,p_query_column_name=>'SUPPLIER_NAME'
,p_heading=>'Supplier Name'
,p_display_sequence=>9
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(34353108891071323167)
,p_query_column_name=>'SUPPLIER_ID'
,p_heading=>'Supplier ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_searchable=>'N'
);
wwv_flow_api.component_end;
end;
/
