prompt --application/shared_components/reports/report_queries/period_wise_purchase_summary
begin
--   Manifest
--     WEB SERVICE: period_wise_purchase_summary
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(34290110585760899953)
,p_name=>'period_wise_purchase_summary'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PURCHASE_MASTER.INVOICE,SUPPLIER_NAME,PURCHASE_MASTER.PURCHASE_DATE,to_char(TOTAL_AMOUNT,''99,99,99,999.99'') Total_price, ',
'	to_char(DISCOUNT,''99,99,99,999.99'') Discount,to_char(GRAND_TOTAL,''99,99,99,999.99'') Grand_total,',
'	to_char(PAID_AMOUNT,''99,99,99,999.99'') Paid_amount, to_char(DUE,''99,99,99,999.99'') due',
'FROM PURCHASE_MASTER,SUPPLIER',
'WHERE PURCHASE_MASTER.SUPPLIER_ID=SUPPLIER.SUPPLIER_ID(+)',
'AND   PURCHASE_DATE BETWEEN :P52_FROM_DATE AND :P52_TO_DATE',
'ORDER BY INVOICE desc;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34299785107131387573)
,p_format=>'PDF'
,p_output_file_name=>'period_wise_purchase_summary'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P52_FROM_DATE:P52_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34985384220784500662)
,p_shared_query_id=>wwv_flow_api.id(34290110585760899953)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PURCHASE_MASTER.INVOICE,SUPPLIER_NAME,PURCHASE_MASTER.PURCHASE_DATE,to_char(TOTAL_AMOUNT,''99,99,99,999.99'') Total_price, ',
'	to_char(DISCOUNT,''99,99,99,999.99'') Discount,to_char(GRAND_TOTAL,''99,99,99,999.99'') Grand_total,',
'	to_char(PAID_AMOUNT,''99,99,99,999.99'') Paid_amount, to_char(DUE,''99,99,99,999.99'') due',
'FROM PURCHASE_MASTER,SUPPLIER',
'WHERE PURCHASE_MASTER.SUPPLIER_ID=SUPPLIER.SUPPLIER_ID(+)',
'AND   PURCHASE_DATE BETWEEN :P52_FROM_DATE AND :P52_TO_DATE',
'ORDER BY INVOICE,PURCHASE_DATE desc;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34985384424897500662)
,p_shared_query_id=>wwv_flow_api.id(34290110585760899953)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P76_FROM_DATE from_date ,:P76_TO_DATE to_dae,to_char(sum(TOTAL_AMOUNT),''99,99,99,999.99'') Total_price, to_char(sum(DISCOUNT),''99,99,99,999.99'') Discount,',
' to_char(sum(GRAND_TOTAL),''99,99,99,999.99'') Grand_total,to_char(sum(PAID_AMOUNT),''99,99,99,999.99'') Paid_amount, to_char(sum(DUE),''99,99,99,999.99'') due',
'from   PURCHASE_MASTER',
'where  PURCHASE_DATE BETWEEN :P52_FROM_DATE AND :P52_TO_DATE'))
);
wwv_flow_api.component_end;
end;
/
