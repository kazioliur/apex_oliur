prompt --application/shared_components/reports/report_queries/period_wise_purchase_report
begin
--   Manifest
--     WEB SERVICE: period_wise_purchase_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(34259370387759891881)
,p_name=>'period_wise_purchase_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  PURCHASE_ITEM_Name,',
'        sum(QUANTITY) Quantity,to_char(UNIT_PRICE,''99,99,99,999.99'') unit_price,to_char(sum(QUANTITY) * UNIT_PRICE,''99,99,99,999.99'') Unit_total',
'from   PURCHASE_DETAIL,PURCHASE_MASTER,purchase_item',
'Where  PURCHASE_DETAIL.invoice = PURCHASE_MASTER. invoice',
'and    purchase_detail.purchase_item_id = purchase_item.purchase_item_id',
'and    PURCHASE_DATE between :P76_FROM_DATE and :P76_TO_DATE',
'group  by PURCHASE_ITEM_Name,UNIT_PRICE;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34982491896919309416)
,p_format=>'PDF'
,p_output_file_name=>'period_wise_purchase_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P76_FROM_DATE:P76_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34982500579147312626)
,p_shared_query_id=>wwv_flow_api.id(34259370387759891881)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  PURCHASE_ITEM_Name,',
'        sum(QUANTITY) Quantity,to_char(UNIT_PRICE,''99,99,99,999.99'') unit_price,to_char(sum(QUANTITY) * UNIT_PRICE,''99,99,99,999.99'') Unit_total',
'from   PURCHASE_DETAIL,PURCHASE_MASTER,purchase_item',
'Where  PURCHASE_DETAIL.invoice = PURCHASE_MASTER. invoice',
'and    purchase_detail.purchase_item_id = purchase_item.purchase_item_id',
'and    PURCHASE_DATE between :P76_FROM_DATE and :P76_TO_DATE',
'group  by PURCHASE_ITEM_Name,UNIT_PRICE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34982500722281312626)
,p_shared_query_id=>wwv_flow_api.id(34259370387759891881)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P76_FROM_DATE from_date ,:P76_TO_DATE to_dae,to_char(sum(TOTAL_AMOUNT),''99,99,99,999.99'') Total_price, to_char(sum(DISCOUNT),''99,99,99,999.99'') Discount,',
' to_char(sum(GRAND_TOTAL),''99,99,99,999.99'') Grand_total,to_char(sum(PAID_AMOUNT),''99,99,99,999.99'') Paid_amount, to_char(sum(DUE),''99,99,99,999.99'') due',
'from   PURCHASE_MASTER',
'where  PURCHASE_DATE between :P76_FROM_DATE and :P76_TO_DATE'))
);
wwv_flow_api.component_end;
end;
/
