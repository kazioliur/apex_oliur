prompt --application/shared_components/reports/report_queries/invoice_wise_sales_report
begin
--   Manifest
--     WEB SERVICE: Invoice_wise_sales_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(31805307544519661152)
,p_name=>'Invoice_wise_sales_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.invoice,guest_name,order_date,TOTAL_PRICE-AFTER_DISCOUNT Discount,GRANT_TOTAL-AFTER_DISCOUNT vat, GRANT_TOTAL,',
'      nvl(food_menu_name,''Not Member'') Food_menu_name,order_detail.quantity,order_detail.price, order_detail.quantity*order_detail.price unit_tatal',
'from   order_master,order_detail,food_menu,guest',
'where  order_master.guest_id = guest.guest_id',
'and   order_detail.invoice = order_master.invoice',
'and  order_detail.food_menu_id=food_menu.food_menu_id',
'and  order_master.invoice= :P43_INVOICE;',
'',
''))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34807018517944369391)
,p_format=>'PDF'
,p_output_file_name=>'Invoice_wise_sales_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P43_INVOICE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34807597666124423891)
,p_shared_query_id=>wwv_flow_api.id(31805307544519661152)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.invoice,(select guest_name from guest where guest_id = order_master.guest_id) guest_name,to_char(order_date,''fmDay, DD Month,YYYY'') order_date,',
'        to_char(TOTAL_PRICE-AFTER_DISCOUNT,''99,99,99,999.99'') Discount,',
'       to_char(GRANT_TOTAL-AFTER_DISCOUNT,''99,99,99,999.99'') vat, to_char(GRANT_TOTAL,''99,99,99,999.99'')GRANT_TOTAL,',
'      (food_menu_name) Food_menu_name,order_detail.quantity,to_char(order_detail.price,''99,99,99,999.99'') price,',
'       to_char(order_detail.quantity*order_detail.price,''99,99,99,999.99'') unit_tatal,to_char(TOTAL_PRICE,''99,99,99,999.99'') Total_price,',
'       to_char(AFTER_DISCOUNT,''99,99,99,999.99'') After_discount',
'from   order_master,order_detail,food_menu',
'where  order_detail.invoice = order_master.invoice',
'and  order_detail.food_menu_id=food_menu.food_menu_id',
'and  order_master.invoice= :P43_INVOICE',
'order by quantity desc;',
''))
);
wwv_flow_api.component_end;
end;
/
