prompt --application/shared_components/reports/report_queries/top_ten_past_moving_food_menu
begin
--   Manifest
--     WEB SERVICE: top_ten_past_moving_food_menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(32503302515962710539)
,p_name=>'top_ten_past_moving_food_menu'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select food_menu_name,sum(quantity) quantity',
'from  order_view',
'group by food_menu_name',
'order by quantity desc',
'fetch first 10 rows only'))
,p_xml_structure=>'STANDARD'
,p_format=>'PDF'
,p_output_file_name=>'top_ten_past_moving_food_menu'
,p_content_disposition=>'ATTACHMENT'
);
wwv_flow_api.component_end;
end;
/
