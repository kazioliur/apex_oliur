prompt --application/shared_components/reports/report_queries/supplier_form_report
begin
--   Manifest
--     WEB SERVICE: supplier_form_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(34345331419817020635)
,p_name=>'supplier_form_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUPPLIER_ID,',
'       SUPPLIER_NAME,',
'       CELL_NUMBER,',
'       EMAIL,',
'       ADDRESS,',
'       WEBSITE',
'  from SUPPLIER',
'  where supplier_id = :P27_SUPPLIER_ID',
'  order by 1 desc'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34467836569082018432)
,p_format=>'PDF'
,p_output_file_name=>'supplier_form_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P27_SUPPLIER_ID'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34467672904000668231)
,p_shared_query_id=>wwv_flow_api.id(34345331419817020635)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUPPLIER_ID,',
'       SUPPLIER_NAME,',
'       CELL_NUMBER,',
'       EMAIL,',
'       ADDRESS,',
'       WEBSITE',
'  from SUPPLIER',
'  where supplier_id = :P27_SUPPLIER_ID',
'  order by 1 desc'))
);
wwv_flow_api.component_end;
end;
/
