prompt --application/shared_components/reports/report_queries/daily_sales_report
begin
--   Manifest
--     WEB SERVICE: Daily_sales_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(31332199531584307912)
,p_name=>'Daily_sales_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  to_char(order_date,''Day,DD Month, YYYY'') order_date,sum(TOTAL_PRICE) total_price,sum(TOTAL_PRICE) - sum(after_discount) Discount,',
'        sum(after_discount) Actual_sales,sum(grant_total) - sum(after_discount) vat, sum(grant_total) Gross_sales',
'FROM    order_master,order_detail',
'where   order_detail.invoice = order_master.invoice',
'AND    to_char(order_date,''DD-MON-RR'') = to_char(to_date(:P49_SALES_DATE,''DD-MON-RR''),''DD-MON-RR'')',
'group  by to_char(order_date,''Day,DD Month, YYYY'');'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34815863112965485225)
,p_format=>'PDF'
,p_output_file_name=>'Daily_sales_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P49_SALES_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34992726165008768525)
,p_shared_query_id=>wwv_flow_api.id(31332199531584307912)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   to_char(order_date,''fmDay, DD Month,YYYY'') order_date, to_char(sum(total_price),''99,99,99,999.99'') Total_price,',
'        to_char(sum(after_discount),''99,99,99,999.99'') net_sales,',
'         to_char(sum(total_price) - sum(after_discount),''99,99,99,999.99'')  discount,',
'         to_char(sum(grant_total) - sum(after_discount),''99,99,99,999.99'')  vat,',
'         to_char(sum(grant_total),''99,99,99,999.99'') Gross_Received',
'FROM     order_master',
'where    order_date = :P49_SALES_DATE',
'group  by to_char(order_date,''fmDay, DD Month,YYYY'');',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34992726335090768525)
,p_shared_query_id=>wwv_flow_api.id(31332199531584307912)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select payment_mode,To_char(sum(grant_total),''99,99,99,999.99'') Total_amount',
'from   order_master',
'where  order_date = :P49_SALES_DATE',
'group  by payment_mode;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34992726596455768525)
,p_shared_query_id=>wwv_flow_api.id(31332199531584307912)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(quantity) quantity, Food_menu_name,to_char(F.price,''99,99,99,999.99'') Price,to_char(sum(quantity) * f.price,''99,99,99,999.99'') Unit_Total',
'from   order_master M, order_detail d,food_menu f',
'where  d.invoice = m.invoice',
'and    d.food_menu_id = f.food_menu_id',
'and   order_date = :P49_SALES_DATE',
'group by Food_menu_name,F.price;'))
);
wwv_flow_api.component_end;
end;
/
