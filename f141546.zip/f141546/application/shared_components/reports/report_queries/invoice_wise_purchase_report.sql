prompt --application/shared_components/reports/report_queries/invoice_wise_purchase_report
begin
--   Manifest
--     WEB SERVICE: Invoice_wise_purchase_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(33609167431637133389)
,p_name=>'Invoice_wise_purchase_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select invoice,to_char(PURCHASE_DATE, ''Day, DD Month,YYYY'') order_date, SUPPLIER_ID, (select supplier_name from supplier where supplier_id = purchase_master.supplier_id) supplier_name, PURCHASE_DATE',
'from   purchase_master',
'Where  invoice = :P69_INVOICE'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34970649443292628178)
,p_format=>'PDF'
,p_output_file_name=>'Invoice_wise_purchase_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P69_INVOICE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34974757737846809273)
,p_shared_query_id=>wwv_flow_api.id(33609167431637133389)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select invoice,to_char(PURCHASE_DATE, ''Day, DD Month,YYYY'') Purchase_date, SUPPLIER_ID, (select supplier_name from supplier where supplier_id = purchase_master.supplier_id) supplier_name',
'from   purchase_master',
'Where  invoice = :P69_INVOICE'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34974757992504809273)
,p_shared_query_id=>wwv_flow_api.id(33609167431637133389)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select purchase_item_name from purchase_item where purchase_item_id= purchase_detail.purchase_item_id)Item_Name,',
'  Quantity,to_char(UNIT_PRICE,''99,99,99,999.99'') Unit_price,  to_char((Quantity * UNIT_PRICE),''99,99,99,999.99'') Unit_total',
'from   purchase_detail',
'Where  invoice = :P69_INVOICE',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34974758134944809273)
,p_shared_query_id=>wwv_flow_api.id(33609167431637133389)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(TOTAL_AMOUNT,''99,99,99,999.99'') Total_amount,to_char(DISCOUNT,''99,99,99,999.99'') discount,to_char(GRAND_TOTAL,''99,99,99,999.99'') Grand_Total,',
'         PAYMENT_MODE, to_char(PAID_AMOUNT,''99,99,99,999.99'')Paid, to_char(DUE,''99,99,99,999.99'') due',
'from   purchase_master',
'Where  invoice = :P69_INVOICE'))
);
wwv_flow_api.component_end;
end;
/
