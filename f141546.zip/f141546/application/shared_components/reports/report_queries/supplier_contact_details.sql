prompt --application/shared_components/reports/report_queries/supplier_contact_details
begin
--   Manifest
--     WEB SERVICE: supplier_contact_details
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(32956505957410426610)
,p_name=>'supplier_contact_details'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUPPLIER_ID,',
'       SUPPLIER_NAME,',
'       CELL_NUMBER,',
'       EMAIL,',
'       ADDRESS,',
'       WEBSITE',
'  from SUPPLIER',
'  where SUPPLIER_ID like nvl(:P72_SUPPLIER_ID, ''%'')'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(32961587119044517975)
,p_format=>'PDF'
,p_output_file_name=>'supplier_contact_details'
,p_content_disposition=>'ATTACHMENT'
,p_xml_items=>'P72_SUPPLIER_ID'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(32961629396575163244)
,p_shared_query_id=>wwv_flow_api.id(32956505957410426610)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUPPLIER_ID,',
'       SUPPLIER_NAME,',
'       CELL_NUMBER,',
'       EMAIL,',
'       ADDRESS,',
'       WEBSITE',
'  from SUPPLIER',
'  where SUPPLIER_ID like nvl(:P72_SUPPLIER_ID, ''%'')'))
);
wwv_flow_api.component_end;
end;
/
