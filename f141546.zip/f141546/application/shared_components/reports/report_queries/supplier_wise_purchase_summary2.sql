prompt --application/shared_components/reports/report_queries/supplier_wise_purchase_summary2
begin
--   Manifest
--     WEB SERVICE: supplier_wise_purchase_summary2
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(32983253350442247675)
,p_name=>'supplier_wise_purchase_summary2'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PURCHASE_MASTER.INVOICE, ',
'PURCHASE_MASTER.SUPPLIER_ID, SUPPLIER_NAME,PURCHASE_MASTER.PURCHASE_DATE, PURCHASE_MASTER.TOTAL_AMOUNT, ',
' PURCHASE_MASTER.DISCOUNT, PURCHASE_MASTER.PAID_AMOUNT, ',
'PURCHASE_MASTER.DUE',
'FROM PURCHASE_MASTER,SUPPLIER',
'WHERE PURCHASE_MASTER.SUPPLIER_ID=SUPPLIER.SUPPLIER_ID(+)',
'AND   SUPPLIER.SUPPLIER_ID LIKE NVL(:P71_SUPPLIER_ID,''%'')',
'AND   PURCHASE_MASTER.PURCHASE_DATE BETWEEN nvl(:P71_FROM_DATE,(sysdate-365)) AND nvl(:P71_TO_DATE,sysdate)',
'ORDER BY INVOICE;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(35373448758014634407)
,p_format=>'PDF'
,p_output_file_name=>'supplier_wise_purchase_summary2'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P71_SUPPLIER_ID:P71_FROM_DATE:P71_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35373457953400637121)
,p_shared_query_id=>wwv_flow_api.id(32983253350442247675)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PURCHASE_MASTER.INVOICE, ',
'PURCHASE_MASTER.SUPPLIER_ID, SUPPLIER_NAME,PURCHASE_MASTER.PURCHASE_DATE, PURCHASE_MASTER.TOTAL_AMOUNT, ',
' PURCHASE_MASTER.DISCOUNT, PURCHASE_MASTER.PAID_AMOUNT, ',
'PURCHASE_MASTER.DUE',
'FROM PURCHASE_MASTER,SUPPLIER',
'WHERE PURCHASE_MASTER.SUPPLIER_ID=SUPPLIER.SUPPLIER_ID(+)',
'AND   SUPPLIER.SUPPLIER_ID LIKE NVL(:P71_SUPPLIER_ID,''%'')',
'AND   PURCHASE_MASTER.PURCHASE_DATE BETWEEN :P71_FROM_DATE AND :P71_TO_DATE',
'ORDER BY INVOICE;'))
);
wwv_flow_api.component_end;
end;
/
