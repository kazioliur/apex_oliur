prompt --application/shared_components/reports/report_queries/business_status
begin
--   Manifest
--     WEB SERVICE: business_status
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(34706628154598609453)
,p_name=>'business_status'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_purchase(:P77_FROM_DATE,:P77_TO_DATE) Total_purchase_paid',
'from   dual;'))
,p_xml_structure=>'APEX'
,p_format=>'PDF'
,p_output_file_name=>'business_status'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P77_FROM_DATE:P77_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171509214103766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_purchase(:P77_FROM_DATE,:P77_TO_DATE) Total_purchase_paid',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171509423414766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE) total_Payable_due',
'from   dual;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171509630301766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select round(sum(grant_total))',
'from   order_master',
'where  order_date between :P77_FROM_DATE and :P77_TO_DATE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171509821303766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE) total_payable_vat',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171510088957766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE) Total_depreciation_cost',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171510206985766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select total_expense(:P77_FROM_DATE,:P77_TO_DATE) Others_expense',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171510458450766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (total_purchase(:P77_FROM_DATE,:P77_TO_DATE) + total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE) + total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE) + total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE) + total_expense(:P77_FROM_DATE,:P77_TO_DATE)) '
||'Total_Expenditure ',
'From Dual;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35171510689095766430)
,p_shared_query_id=>wwv_flow_api.id(34706628154598609453)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select round(nvl(total_income(:P77_FROM_DATE,:P77_TO_DATE),0) -(nvl(total_purchase(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE),0) + ',
'nvl(total_expense(:P77_FROM_DATE,:P77_TO_DATE),0))) Business_status',
'From Dual;',
''))
);
wwv_flow_api.component_end;
end;
/
