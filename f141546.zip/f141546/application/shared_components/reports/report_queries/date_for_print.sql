prompt --application/shared_components/reports/report_queries/date_for_print
begin
--   Manifest
--     WEB SERVICE: Date_for_print
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(31808736549524081830)
,p_name=>'Date_for_print'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(sysdate,''Day, DD Month, YYYY'')',
'from   dual;'))
,p_format=>'PDF'
,p_output_file_name=>'Date_for_print'
,p_content_disposition=>'ATTACHMENT'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(31808772243623101613)
,p_shared_query_id=>wwv_flow_api.id(31808736549524081830)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(sysdate,''Day, DD Month, YYYY'')',
'from   dual;'))
);
wwv_flow_api.component_end;
end;
/
