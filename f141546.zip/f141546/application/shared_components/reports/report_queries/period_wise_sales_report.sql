prompt --application/shared_components/reports/report_queries/period_wise_sales_report
begin
--   Manifest
--     WEB SERVICE: period_Wise_sales_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(33361475164909030363)
,p_name=>'period_Wise_sales_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select   sum(quantity) quantity, Food_menu_name,to_char((F.price),''99,99,99,999.99'') Price,to_char((sum(quantity) * f.price),''99,99,99,999.99'') Unit_Total',
'from     order_master M, order_detail d,food_menu f',
'where    d.invoice = m.invoice',
'and      d.food_menu_id = f.food_menu_id',
'and      order_date between :P44_FROM_DATE and :P44_TO_DATE',
'group by Food_menu_name,F.price;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34820929501495509834)
,p_format=>'PDF'
,p_output_file_name=>'period_Wise_sales_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P44_FROM_DATE:P44_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34820931178331510967)
,p_shared_query_id=>wwv_flow_api.id(33361475164909030363)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   sum(quantity) quantity, Food_menu_name,to_char((F.price),''99,99,99,999.99'') Price,to_char((sum(quantity) * f.price),''99,99,99,999.99'') Unit_Total',
'from     order_master M, order_detail d,food_menu f',
'where    d.invoice = m.invoice',
'and      d.food_menu_id = f.food_menu_id',
'and      order_date between :P44_FROM_DATE and :P44_TO_DATE',
'group by Food_menu_name,F.price',
'order  by 1 desc;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34820931356819510967)
,p_shared_query_id=>wwv_flow_api.id(33361475164909030363)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   to_char(sum(total_price),''99,99,99,999.99'') Gross_Sales,',
'         to_char(sum(total_price) - sum(after_discount),''99,99,99,999.99'')  discount, to_char(sum(after_discount),''99,99,99,999.99'')Net_Sales ,',
'         to_char(sum(grant_total) - sum(after_discount),''99,99,99,999.99'')  vat,',
'         to_char(sum(grant_total),''99,99,99,999.99'') Gross_Received,to_char(sum(grant_total),''99,99,99,999.99'')  Cash_to_account',
'FROM     order_master',
'where order_date between :P44_FROM_DATE and :P44_TO_DATE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34820931509367510967)
,p_shared_query_id=>wwv_flow_api.id(33361475164909030363)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select payment_mode,to_char(sum(grant_total),''99,99,99,999.99'') Amount',
'from   order_master',
'where  order_date between :P44_FROM_DATE and :P44_TO_DATE',
'group  by payment_mode;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34820931708493510967)
,p_shared_query_id=>wwv_flow_api.id(33361475164909030363)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(:P44_FROM_DATE,''fmDay, DD Month, YYYY'') From_date, to_char(:P44_TO_DATE,''fmDay, DD Month, YYYY'') to_dat',
'from   dual;'))
);
wwv_flow_api.component_end;
end;
/
