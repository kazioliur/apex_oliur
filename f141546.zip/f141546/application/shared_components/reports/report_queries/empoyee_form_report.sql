prompt --application/shared_components/reports/report_queries/empoyee_form_report
begin
--   Manifest
--     WEB SERVICE: Empoyee_form_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(35082096635985925213)
,p_name=>'Empoyee_form_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EMPLOYEE_ID, DEPARTMENT_NAME, DESIGNATION_NAME, Employee_name "Employee Name", CELL_NUMBER, EMAIL, DATE_OF_BIRTH, JOIN_DATE, SALARY',
'FROM   EMPLOYEE_VIEW',
'WHERE  EMPLOYEE_ID LIKE NVL (:P82_EMPLOYEE_ID, ''%'')',
'ORDER  BY EMPLOYEE_ID'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(35099353446083773026)
,p_format=>'PDF'
,p_output_file_name=>'Empoyee_form_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P20_EMPLOYEE_ID'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35099361596315775267)
,p_shared_query_id=>wwv_flow_api.id(35082096635985925213)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "EMPLOYEE_ID",(select department_name from department where department_id = employee.department_id)"DEPARTMENT_NAME",',
'(select designation_name from designation where designation_id = employee.designation_id)"DESIGNATION_NAME",',
'"FIRST_NAME"|| '' ''||"LAST_NAME" Emp_Name,"CELL_NUMBER","EMAIL","ADDRESS",',
'"DATE_OF_BIRTH","RELIGION","GENDER","NATIONALITY","NID","JOIN_DATE",',
'"SALARY",sys.dbms_lob.getlength("IMAGE")"IMAGE","ACTION_USER","ACTION_DATE"',
'from "EMPLOYEE"',
'where  employee_id = :P20_EMPLOYEE_ID'))
);
wwv_flow_api.component_end;
end;
/
