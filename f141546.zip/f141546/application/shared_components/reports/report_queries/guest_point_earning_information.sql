prompt --application/shared_components/reports/report_queries/guest_point_earning_information
begin
--   Manifest
--     WEB SERVICE: Guest_point_earning_information
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(32395512003677010494)
,p_name=>'Guest_point_earning_information'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.guest_id,guest_name,cell_number,email,sum(grant_total) "Total Consume",',
'       sum(grant_total)/100*5 "Total Point " ,round((sum(grant_total)/100*5)/2)"point value"',
'from   guest, order_master',
'where order_master.guest_id = guest.guest_id',
'and   order_master.guest_id like nvl(:P61_GUEST_ID,''%'')',
'group by order_master.guest_id,guest_name,cell_number,email;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(32400223795592108282)
,p_format=>'PDF'
,p_output_file_name=>'Guest_point_earning_information'
,p_content_disposition=>'ATTACHMENT'
,p_xml_items=>'P61_GUEST_ID'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(32400397991021758763)
,p_shared_query_id=>wwv_flow_api.id(32395512003677010494)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.guest_id,guest_name,cell_number,email,round(sum(grant_total)) "Total Consume",',
'       round(sum(grant_total)/100*5) "Total Point " ,round((sum(grant_total)/100*5)/2)"point value"',
'from   guest, order_master',
'where order_master.guest_id = guest.guest_id',
'and   order_master.guest_id like nvl(:P61_GUEST_ID,''%'')',
'group by order_master.guest_id,guest_name,cell_number,email;'))
);
wwv_flow_api.component_end;
end;
/
