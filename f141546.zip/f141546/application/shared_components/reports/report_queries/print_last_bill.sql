prompt --application/shared_components/reports/report_queries/print_last_bill
begin
--   Manifest
--     WEB SERVICE: print_last_bill
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(35137464561231802747)
,p_name=>'print_last_bill'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.invoice,(select guest_name from guest where guest_id = order_master.guest_id) guest_name,to_char(order_date,''fmDay, DD Month,YYYY'') order_date,',
'        to_char(TOTAL_PRICE-AFTER_DISCOUNT,''99,99,99,999.99'') Discount,',
'       to_char(GRANT_TOTAL-AFTER_DISCOUNT,''99,99,99,999.99'') vat, to_char(GRANT_TOTAL,''99,99,99,999.99'')GRANT_TOTAL,',
'      (food_menu_name) Food_menu_name,order_detail.quantity,to_char(order_detail.price,''99,99,99,999.99'') price,',
'       to_char(order_detail.quantity*order_detail.price,''99,99,99,999.99'') unit_tatal,to_char(TOTAL_PRICE,''99,99,99,999.99'') Total_price,',
'       to_char(AFTER_DISCOUNT,''99,99,99,999.99'') After_discount',
'from   order_master,order_detail,food_menu',
'where  order_detail.invoice = order_master.invoice',
'and  order_detail.food_menu_id=food_menu.food_menu_id',
'and  order_master.invoice= :P47_IINVOICE',
'order by quantity desc;',
''))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34807018517944369391)
,p_format=>'PDF'
,p_output_file_name=>'print_last_bill'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P47_IINVOICE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35137485152756833935)
,p_shared_query_id=>wwv_flow_api.id(35137464561231802747)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select order_master.invoice,(select guest_name from guest where guest_id = order_master.guest_id) guest_name,to_char(order_date,''fmDay, DD Month,YYYY'') order_date,',
'        to_char(TOTAL_PRICE-AFTER_DISCOUNT,''99,99,99,999.99'') Discount,',
'       to_char(GRANT_TOTAL-AFTER_DISCOUNT,''99,99,99,999.99'') vat, to_char(GRANT_TOTAL,''99,99,99,999.99'')GRANT_TOTAL,',
'      (food_menu_name) Food_menu_name,order_detail.quantity,to_char(order_detail.price,''99,99,99,999.99'') price,',
'       to_char(order_detail.quantity*order_detail.price,''99,99,99,999.99'') unit_tatal,to_char(TOTAL_PRICE,''99,99,99,999.99'') Total_price,',
'       to_char(AFTER_DISCOUNT,''99,99,99,999.99'') After_discount',
'from   order_master,order_detail,food_menu',
'where  order_detail.invoice = order_master.invoice',
'and  order_detail.food_menu_id=food_menu.food_menu_id',
'and  order_master.invoice= :P47_IINVOICE',
'order by quantity desc;',
''))
);
wwv_flow_api.component_end;
end;
/
