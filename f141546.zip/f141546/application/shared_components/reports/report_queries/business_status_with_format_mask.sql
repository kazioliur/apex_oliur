prompt --application/shared_components/reports/report_queries/business_status_with_format_mask
begin
--   Manifest
--     WEB SERVICE: business_status_with_format_mask
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(35180632862322995487)
,p_name=>'business_status_with_format_mask'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_purchase(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'') Total_purchase_paid',
'from   dual;',
''))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(35182930505417052085)
,p_format=>'PDF'
,p_output_file_name=>'business_status_with_format_mask'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P77_FROM_DATE:P77_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315048261530946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_purchase(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'') Total_purchase_paid',
'from   dual;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315048411764946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'')  total_Payable_due',
'from   dual;',
'',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315048654963946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'')  total_payable_vat',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315048895070946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'')  Total_depreciation_cost',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315049090207946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(total_expense(:P77_FROM_DATE,:P77_TO_DATE),''99,99,99,999.99'')  Others_expense',
'from   dual;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315049261385946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char((total_purchase(:P77_FROM_DATE,:P77_TO_DATE) + total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE) + total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE) + total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE) + total_expense(:P77_FROM_DATE,:P77_TO'
||'_DATE)),''99,99,99,999.99'')  Total_Expenditure ',
'From Dual;',
''))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315049483918946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(round(sum(grant_total)),''99,99,99,999.99'') total_income',
'from   order_master',
'where  order_date between :P77_FROM_DATE and :P77_TO_DATE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35315049610600946718)
,p_shared_query_id=>wwv_flow_api.id(35180632862322995487)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(round(nvl(total_income(:P77_FROM_DATE,:P77_TO_DATE),0) -(nvl(total_purchase(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_Payble_due(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_payable_vat(:P77_FROM_DATE,:P77_TO_DATE),0) +',
' nvl(total_depreciation_cost(:P77_FROM_DATE,:P77_TO_DATE),0) + ',
'nvl(total_expense(:P77_FROM_DATE,:P77_TO_DATE),0))),''99,99,99,999.99'')  Business_status',
'From Dual;',
''))
);
wwv_flow_api.component_end;
end;
/
