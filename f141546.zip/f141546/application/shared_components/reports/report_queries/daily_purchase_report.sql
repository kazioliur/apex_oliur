prompt --application/shared_components/reports/report_queries/daily_purchase_report
begin
--   Manifest
--     WEB SERVICE: daily_purchase_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(34142707678043068594)
,p_name=>'daily_purchase_report'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select purchase_item_name from purchase_item where PURCHASE_ITEM_ID = PURCHASE_DETAIL.purchase_item_id) PURCHASE_ITEM_Name,',
'        sum(QUANTITY) Quantity,to_char(UNIT_PRICE,''99,99,99,999.99'') unit_price,to_char(sum(QUANTITY) * UNIT_PRICE,''99,99,99,999.99'') Unit_total',
'from   PURCHASE_DETAIL,PURCHASE_MASTER',
'Where  PURCHASE_DETAIL.invoice = PURCHASE_MASTER. invoice',
'and    PURCHASE_DATE = :P51_SALES_DATE',
'group  by PURCHASE_ITEM_ID,UNIT_PRICE;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(34975240297557913296)
,p_format=>'PDF'
,p_output_file_name=>'daily_purchase_report'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P51_SALES_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34975242295106914688)
,p_shared_query_id=>wwv_flow_api.id(34142707678043068594)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select purchase_item_name from purchase_item where PURCHASE_ITEM_ID = PURCHASE_DETAIL.purchase_item_id) PURCHASE_ITEM_Name,',
'        sum(QUANTITY) Quantity,to_char(UNIT_PRICE,''99,99,99,999.99'') unit_price,to_char(sum(QUANTITY) * UNIT_PRICE,''99,99,99,999.99'') Unit_total',
'from   PURCHASE_DETAIL,PURCHASE_MASTER',
'Where  PURCHASE_DETAIL.invoice = PURCHASE_MASTER. invoice',
'and    PURCHASE_DATE = :P51_SALES_DATE',
'group  by PURCHASE_ITEM_ID,UNIT_PRICE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(34975242474226914688)
,p_shared_query_id=>wwv_flow_api.id(34142707678043068594)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(PURCHASE_DATE,''Day,DD Month,YYYY'') Purchase_date,to_char(sum(TOTAL_AMOUNT),''99,99,99,999.99'') Total_price, to_char(sum(DISCOUNT),''99,99,99,999.99'') Discount,',
' to_char(sum(GRAND_TOTAL),''99,99,99,999.99'') Grand_total,to_char(sum(PAID_AMOUNT),''99,99,99,999.99'') Paid_amount, to_char(sum(DUE),''99,99,99,999.99'') due',
'from   PURCHASE_MASTER',
'where  PURCHASE_DATE = :P51_SALES_DATE',
'group  by to_char(PURCHASE_DATE,''Day,DD Month,YYYY'');'))
);
wwv_flow_api.component_end;
end;
/
