prompt --application/shared_components/reports/report_queries/period_wise_sales_summary
begin
--   Manifest
--     WEB SERVICE: period_wise_sales_summary
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(35053673125740700745)
,p_name=>'period_wise_sales_summary'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   invoice, Order_date,to_char((total_price),''99,99,99,999.99'') Gross_Sales,',
'         to_char((total_price) - (after_discount),''99,99,99,999.99'')  discount, to_char((after_discount),''99,99,99,999.99'')Net_Sales ,',
'         to_char((grant_total) - (after_discount),''99,99,99,999.99'')  vat,',
'         to_char((grant_total),''99,99,99,999.99'') Paid_amount',
'FROM     order_master',
'where order_date between :P58_FROM_DATE and :P58_TO_DATE;'))
,p_xml_structure=>'APEX'
,p_report_layout_id=>wwv_flow_api.id(35068249599173194656)
,p_format=>'PDF'
,p_output_file_name=>'period_wise_sales_summary'
,p_content_disposition=>'INLINE'
,p_xml_items=>'P58_FROM_DATE:P58_TO_DATE'
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35068402957190157364)
,p_shared_query_id=>wwv_flow_api.id(35053673125740700745)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   invoice, Order_date,to_char((total_price),''99,99,99,999.99'') Gross_Sales,',
'         to_char((total_price) - (after_discount),''99,99,99,999.99'')  discount, to_char((after_discount),''99,99,99,999.99'')Net_Sales ,',
'         to_char((grant_total) - (after_discount),''99,99,99,999.99'')  vat,',
'         to_char((grant_total),''99,99,99,999.99'') Paid_amount',
'FROM     order_master',
'where order_date between :P58_FROM_DATE and :P58_TO_DATE;'))
);
wwv_flow_api.create_shared_query_stmnt(
 p_id=>wwv_flow_api.id(35068403187287157364)
,p_shared_query_id=>wwv_flow_api.id(35053673125740700745)
,p_sql_statement=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   count(invoice) invoice,to_char(sum(total_price),''99,99,99,999.99'') Total_price,',
'        to_char(sum(after_discount),''99,99,99,999.99'') net_sales,',
'         to_char(sum(total_price) - sum(after_discount),''99,99,99,999.99'')  discount,',
'         to_char(sum(grant_total) - sum(after_discount),''99,99,99,999.99'')  vat,',
'         to_char(sum(grant_total),''99,99,99,999.99'') Gross_Received',
'FROM     order_master',
'where    order_date between :P58_FROM_DATE and :P58_TO_DATE;',
''))
);
wwv_flow_api.component_end;
end;
/
