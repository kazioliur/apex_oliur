prompt --application/shared_components/reports/report_layouts/daily_sales_report_layout
begin
--   Manifest
--     REPORT LAYOUT: daily_sales_report_layout
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
    wwv_flow_api.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff0\deff0\stshfdbch0\stshfloch31506\stshfhich31506\stshf';
    wwv_flow_api.g_varchar2_table(2) := 'bi31506\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi \froman';
    wwv_flow_api.g_varchar2_table(3) := '\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f34\fbidi \froman\fcharset0\fprq2';
    wwv_flow_api.g_varchar2_table(4) := '{\*\panose 02040503050406030204}Cambria Math;}'||wwv_flow.LF||
'{\f37\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f05';
    wwv_flow_api.g_varchar2_table(5) := '02020204030204}Calibri;}{\f40\fbidi \fswiss\fcharset0\fprq2{\*\panose 020b0604030504040204}Tahoma;}{';
    wwv_flow_api.g_varchar2_table(6) := '\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\f';
    wwv_flow_api.g_varchar2_table(7) := 'dbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fhima';
    wwv_flow_api.g_varchar2_table(8) := 'jor\f31502\fbidi \froman\fcharset0\fprq2{\*\panose 02040503050406030204}Cambria;}'||wwv_flow.LF||
'{\fbimajor\f31503';
    wwv_flow_api.g_varchar2_table(9) := '\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\flominor\f31504\fbi';
    wwv_flow_api.g_varchar2_table(10) := 'di \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi';
    wwv_flow_api.g_varchar2_table(11) := ' \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fhiminor\f31506\fbidi \fs';
    wwv_flow_api.g_varchar2_table(12) := 'wiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri;}'||wwv_flow.LF||
'{\fbiminor\f31507\fbidi \froman\fchar';
    wwv_flow_api.g_varchar2_table(13) := 'set0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f285\fbidi \froman\fcharset238\fprq2 Ti';
    wwv_flow_api.g_varchar2_table(14) := 'mes New Roman CE;}{\f286\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\f288\fbidi \froman';
    wwv_flow_api.g_varchar2_table(15) := '\fcharset161\fprq2 Times New Roman Greek;}{\f289\fbidi \froman\fcharset162\fprq2 Times New Roman Tur';
    wwv_flow_api.g_varchar2_table(16) := ';}{\f290\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f291\fbidi \froman\fcharset178\';
    wwv_flow_api.g_varchar2_table(17) := 'fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f292\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\f';
    wwv_flow_api.g_varchar2_table(18) := '293\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f625\fbidi \froman\fcharset238\f';
    wwv_flow_api.g_varchar2_table(19) := 'prq2 Cambria Math CE;}{\f626\fbidi \froman\fcharset204\fprq2 Cambria Math Cyr;}'||wwv_flow.LF||
'{\f628\fbidi \froma';
    wwv_flow_api.g_varchar2_table(20) := 'n\fcharset161\fprq2 Cambria Math Greek;}{\f629\fbidi \froman\fcharset162\fprq2 Cambria Math Tur;}{\f';
    wwv_flow_api.g_varchar2_table(21) := '632\fbidi \froman\fcharset186\fprq2 Cambria Math Baltic;}{\f633\fbidi \froman\fcharset163\fprq2 Camb';
    wwv_flow_api.g_varchar2_table(22) := 'ria Math (Vietnamese);}'||wwv_flow.LF||
'{\f655\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}{\f656\fbidi \fswiss\fch';
    wwv_flow_api.g_varchar2_table(23) := 'arset204\fprq2 Calibri Cyr;}{\f658\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\f659\fbidi \fswi';
    wwv_flow_api.g_varchar2_table(24) := 'ss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\f660\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\f661\';
    wwv_flow_api.g_varchar2_table(25) := 'fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\f662\fbidi \fswiss\fcharset186\fprq2 Calibri Bal';
    wwv_flow_api.g_varchar2_table(26) := 'tic;}{\f663\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}'||wwv_flow.LF||
'{\f685\fbidi \fswiss\fcharset238';
    wwv_flow_api.g_varchar2_table(27) := '\fprq2 Tahoma CE;}{\f686\fbidi \fswiss\fcharset204\fprq2 Tahoma Cyr;}{\f688\fbidi \fswiss\fcharset16';
    wwv_flow_api.g_varchar2_table(28) := '1\fprq2 Tahoma Greek;}{\f689\fbidi \fswiss\fcharset162\fprq2 Tahoma Tur;}'||wwv_flow.LF||
'{\f690\fbidi \fswiss\fcha';
    wwv_flow_api.g_varchar2_table(29) := 'rset177\fprq2 Tahoma (Hebrew);}{\f691\fbidi \fswiss\fcharset178\fprq2 Tahoma (Arabic);}{\f692\fbidi ';
    wwv_flow_api.g_varchar2_table(30) := '\fswiss\fcharset186\fprq2 Tahoma Baltic;}{\f693\fbidi \fswiss\fcharset163\fprq2 Tahoma (Vietnamese);';
    wwv_flow_api.g_varchar2_table(31) := '}'||wwv_flow.LF||
'{\f694\fbidi \fswiss\fcharset222\fprq2 Tahoma (Thai);}{\flomajor\f31508\fbidi \froman\fcharset238';
    wwv_flow_api.g_varchar2_table(32) := '\fprq2 Times New Roman CE;}{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(33) := '{\flomajor\f31511\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flomajor\f31512\fbidi \fr';
    wwv_flow_api.g_varchar2_table(34) := 'oman\fcharset162\fprq2 Times New Roman Tur;}{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times ';
    wwv_flow_api.g_varchar2_table(35) := 'New Roman (Hebrew);}'||wwv_flow.LF||
'{\flomajor\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\';
    wwv_flow_api.g_varchar2_table(36) := 'flomajor\f31515\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flomajor\f31516\fbidi \fro';
    wwv_flow_api.g_varchar2_table(37) := 'man\fcharset163\fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fdbmajor\f31518\fbidi \froman\fcharset238\fp';
    wwv_flow_api.g_varchar2_table(38) := 'rq2 Times New Roman CE;}{\fdbmajor\f31519\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdb';
    wwv_flow_api.g_varchar2_table(39) := 'major\f31521\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}'||wwv_flow.LF||
'{\fdbmajor\f31522\fbidi \froma';
    wwv_flow_api.g_varchar2_table(40) := 'n\fcharset162\fprq2 Times New Roman Tur;}{\fdbmajor\f31523\fbidi \froman\fcharset177\fprq2 Times New';
    wwv_flow_api.g_varchar2_table(41) := ' Roman (Hebrew);}{\fdbmajor\f31524\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdb';
    wwv_flow_api.g_varchar2_table(42) := 'major\f31525\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbmajor\f31526\fbidi \froman';
    wwv_flow_api.g_varchar2_table(43) := '\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhimajor\f31528\fbidi \froman\fcharset238\fprq2 C';
    wwv_flow_api.g_varchar2_table(44) := 'ambria CE;}'||wwv_flow.LF||
'{\fhimajor\f31529\fbidi \froman\fcharset204\fprq2 Cambria Cyr;}{\fhimajor\f31531\fbidi ';
    wwv_flow_api.g_varchar2_table(45) := '\froman\fcharset161\fprq2 Cambria Greek;}{\fhimajor\f31532\fbidi \froman\fcharset162\fprq2 Cambria T';
    wwv_flow_api.g_varchar2_table(46) := 'ur;}'||wwv_flow.LF||
'{\fhimajor\f31535\fbidi \froman\fcharset186\fprq2 Cambria Baltic;}{\fhimajor\f31536\fbidi \fro';
    wwv_flow_api.g_varchar2_table(47) := 'man\fcharset163\fprq2 Cambria (Vietnamese);}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times ';
    wwv_flow_api.g_varchar2_table(48) := 'New Roman CE;}'||wwv_flow.LF||
'{\fbimajor\f31539\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbimajor\f3';
    wwv_flow_api.g_varchar2_table(49) := '1541\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset';
    wwv_flow_api.g_varchar2_table(50) := '162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (';
    wwv_flow_api.g_varchar2_table(51) := 'Hebrew);}{\fbimajor\f31544\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f315';
    wwv_flow_api.g_varchar2_table(52) := '45\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\fbimajor\f31546\fbidi \froman\fcharse';
    wwv_flow_api.g_varchar2_table(53) := 't163\fprq2 Times New Roman (Vietnamese);}{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New';
    wwv_flow_api.g_varchar2_table(54) := ' Roman CE;}{\flominor\f31549\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\flominor\f3155';
    wwv_flow_api.g_varchar2_table(55) := '1\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flominor\f31552\fbidi \froman\fcharset162';
    wwv_flow_api.g_varchar2_table(56) := '\fprq2 Times New Roman Tur;}{\flominor\f31553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebre';
    wwv_flow_api.g_varchar2_table(57) := 'w);}'||wwv_flow.LF||
'{\flominor\f31554\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flominor\f31555\';
    wwv_flow_api.g_varchar2_table(58) := 'fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\';
    wwv_flow_api.g_varchar2_table(59) := 'fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fdbminor\f31558\fbidi \froman\fcharset238\fprq2 Times New Ro';
    wwv_flow_api.g_varchar2_table(60) := 'man CE;}{\fdbminor\f31559\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdbminor\f31561\fbi';
    wwv_flow_api.g_varchar2_table(61) := 'di \froman\fcharset161\fprq2 Times New Roman Greek;}'||wwv_flow.LF||
'{\fdbminor\f31562\fbidi \froman\fcharset162\fp';
    wwv_flow_api.g_varchar2_table(62) := 'rq2 Times New Roman Tur;}{\fdbminor\f31563\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);';
    wwv_flow_api.g_varchar2_table(63) := '}{\fdbminor\f31564\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdbminor\f31565\fbi';
    wwv_flow_api.g_varchar2_table(64) := 'di \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbminor\f31566\fbidi \froman\fcharset163\fpr';
    wwv_flow_api.g_varchar2_table(65) := 'q2 Times New Roman (Vietnamese);}{\fhiminor\f31568\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}'||wwv_flow.LF||
'{\f';
    wwv_flow_api.g_varchar2_table(66) := 'himinor\f31569\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}{\fhiminor\f31571\fbidi \fswiss\fcharset';
    wwv_flow_api.g_varchar2_table(67) := '161\fprq2 Calibri Greek;}{\fhiminor\f31572\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\fhiminor';
    wwv_flow_api.g_varchar2_table(68) := '\f31573\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\fhiminor\f31574\fbidi \fswiss\fcharset17';
    wwv_flow_api.g_varchar2_table(69) := '8\fprq2 Calibri (Arabic);}{\fhiminor\f31575\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}'||wwv_flow.LF||
'{\fhim';
    wwv_flow_api.g_varchar2_table(70) := 'inor\f31576\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}{\fbiminor\f31578\fbidi \froman\fc';
    wwv_flow_api.g_varchar2_table(71) := 'harset238\fprq2 Times New Roman CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roma';
    wwv_flow_api.g_varchar2_table(72) := 'n Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\';
    wwv_flow_api.g_varchar2_table(73) := 'fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fpr';
    wwv_flow_api.g_varchar2_table(74) := 'q2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Ar';
    wwv_flow_api.g_varchar2_table(75) := 'abic);}{\fbiminor\f31585\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\f';
    wwv_flow_api.g_varchar2_table(76) := 'bidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\green0\blue0;\red0\';
    wwv_flow_api.g_varchar2_table(77) := 'green0\blue255;\red0\green255\blue255;\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blu';
    wwv_flow_api.g_varchar2_table(78) := 'e0;\red255\green255\blue0;\red255\green255\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0';
    wwv_flow_api.g_varchar2_table(79) := '\green128\blue0;'||wwv_flow.LF||
'\red128\green0\blue128;\red128\green0\blue0;\red128\green128\blue0;\red128\green12';
    wwv_flow_api.g_varchar2_table(80) := '8\blue128;\red192\green192\blue192;\red231\green243\blue253;\red192\green0\blue0;\red0\green112\blue';
    wwv_flow_api.g_varchar2_table(81) := '192;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\as';
    wwv_flow_api.g_varchar2_table(82) := 'palpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa200\sl276';
    wwv_flow_api.g_varchar2_table(83) := '\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af0\a';
    wwv_flow_api.g_varchar2_table(84) := 'fs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext0 ';
    wwv_flow_api.g_varchar2_table(85) := '\sqformat \spriority0 Normal;}{\*\cs10 \additive \ssemihidden \sunhideused \spriority1 Default Parag';
    wwv_flow_api.g_varchar2_table(86) := 'raph Font;}{\*'||wwv_flow.LF||
'\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpadd';
    wwv_flow_api.g_varchar2_table(87) := 'fr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdr';
    wwv_flow_api.g_varchar2_table(88) := 'v \ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\l';
    wwv_flow_api.g_varchar2_table(89) := 'in0\itap0 \rtlch\fcs1 \af31506\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_api.g_varchar2_table(90) := 'ngnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused Normal Table;}{\*\ts15\tsrowd'||wwv_flow.LF||
'\trbrdrt\brd';
    wwv_flow_api.g_varchar2_table(91) := 'rs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(92) := '10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpadd';
    wwv_flow_api.g_varchar2_table(93) := 'fr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdr';
    wwv_flow_api.g_varchar2_table(94) := 'v '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs';
    wwv_flow_api.g_varchar2_table(95) := '1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(96) := '\sbasedon11 \snext15 \sunhideused \spriority59 \styrsid12461720 Table Grid;}{\s16\ql \li0\ri0\widctl';
    wwv_flow_api.g_varchar2_table(97) := 'par\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1';
    wwv_flow_api.g_varchar2_table(98) := ' \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \';
    wwv_flow_api.g_varchar2_table(99) := 'sbasedon0 \snext16 \slink17 \sunhideused \styrsid14755898 header;}{\*\cs17 \additive \rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(100) := '0 \ltrch\fcs0 \sbasedon10 \slink16 \slocked \styrsid14755898 Header Char;}{'||wwv_flow.LF||
'\s18\ql \li0\ri0\widctl';
    wwv_flow_api.g_varchar2_table(101) := 'par\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1';
    wwv_flow_api.g_varchar2_table(102) := ' \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(103) := 'sbasedon0 \snext18 \slink19 \sunhideused \styrsid14755898 footer;}{\*\cs19 \additive \rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(104) := '0 \ltrch\fcs0 \sbasedon10 \slink18 \slocked \styrsid14755898 Footer Char;}{'||wwv_flow.LF||
'\s20\ql \li0\ri0\widctl';
    wwv_flow_api.g_varchar2_table(105) := 'par\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af40\afs16\alang1025';
    wwv_flow_api.g_varchar2_table(106) := ' \ltrch\fcs0 \f40\fs16\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'\sbasedon0 \snext20 \slin';
    wwv_flow_api.g_varchar2_table(107) := 'k21 \ssemihidden \sunhideused \styrsid14755898 Balloon Text;}{\*\cs21 \additive \rtlch\fcs1 \af40\af';
    wwv_flow_api.g_varchar2_table(108) := 's16 \ltrch\fcs0 \f40\fs16 \sbasedon10 \slink20 \slocked \ssemihidden \styrsid14755898 Balloon Text C';
    wwv_flow_api.g_varchar2_table(109) := 'har;}{\*\cs22 \additive '||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \cf15 \sbasedon10 \ssemihidden \styrsid121559';
    wwv_flow_api.g_varchar2_table(110) := '72 Placeholder Text;}}{\*\rsidtbl \rsid548971\rsid659748\rsid1454064\rsid1595358\rsid1643773\rsid186';
    wwv_flow_api.g_varchar2_table(111) := '4469\rsid2167877\rsid2450894\rsid3091585\rsid3149001\rsid3433759\rsid3674752'||wwv_flow.LF||
'\rsid3878147\rsid41317';
    wwv_flow_api.g_varchar2_table(112) := '30\rsid4291205\rsid4338339\rsid4915635\rsid5065116\rsid5922837\rsid6095647\rsid6385073\rsid6705959\r';
    wwv_flow_api.g_varchar2_table(113) := 'sid6776828\rsid6908450\rsid7102897\rsid7297683\rsid7559807\rsid7563929\rsid7945636\rsid8092395\rsid8';
    wwv_flow_api.g_varchar2_table(114) := '203828\rsid8600143\rsid8723429'||wwv_flow.LF||
'\rsid8787903\rsid8811083\rsid9510813\rsid9524954\rsid9704800\rsid100';
    wwv_flow_api.g_varchar2_table(115) := '36636\rsid10378696\rsid11148086\rsid11543638\rsid11628887\rsid12131786\rsid12155972\rsid12394647\rsi';
    wwv_flow_api.g_varchar2_table(116) := 'd12461720\rsid12791250\rsid13314409\rsid13568925\rsid13575715\rsid14049607\rsid14484609'||wwv_flow.LF||
'\rsid145025';
    wwv_flow_api.g_varchar2_table(117) := '14\rsid14635001\rsid14755898\rsid14954308\rsid15339498\rsid15424737\rsid15562122\rsid15758703\rsid16';
    wwv_flow_api.g_varchar2_table(118) := '201548\rsid16345204\rsid16385731\rsid16649907\rsid16667257}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub';
    wwv_flow_api.g_varchar2_table(119) := '0\msmallFrac0\mdispDef1\mlMargin0\mrMargin0'||wwv_flow.LF||
'\mdefJc1\mwrapIndent1440\mintLim0\mnaryLim1}{\info{\aut';
    wwv_flow_api.g_varchar2_table(120) := 'hor oliur}{\operator oliur}{\creatim\yr2021\mo9\dy18\hr4\min2}{\revtim\yr2021\mo9\dy18\hr4\min10}{\v';
    wwv_flow_api.g_varchar2_table(121) := 'ersion3}{\edmins8}{\nofpages1}{\nofwords91}{\nofchars525}{\nofcharsws615}{\vern49247}}'||wwv_flow.LF||
'{\*\xmlnstbl';
    wwv_flow_api.g_varchar2_table(122) := ' {\xmlns1 http://schemas.microsoft.com/office/word/2003/wordml}}\paperw12240\paperh15840\margl1440\m';
    wwv_flow_api.g_varchar2_table(123) := 'argr1440\margt1440\margb1440\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\trackmoves0\trackformatting1';
    wwv_flow_api.g_varchar2_table(124) := '\donotembedsysfont1\relyonvml0\donotembedlingdata0\grfdocevents0\validatexml1\showplaceholdtext0\ign';
    wwv_flow_api.g_varchar2_table(125) := 'oremixedcontent0\saveinvalidxml0\showxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\expshrtn\noultrlspc\dntblnsbdb\nospace';
    wwv_flow_api.g_varchar2_table(126) := 'forul\formshade\horzdoc\dgmargin\dghspace180\dgvspace180\dghorigin1440\dgvorigin1440\dghshow1\dgvsho';
    wwv_flow_api.g_varchar2_table(127) := 'w1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100\pgbrdrhead\pgbrdrfoot\splytwnine\ftnlytwnine\htmautsp\nolnhtadjt';
    wwv_flow_api.g_varchar2_table(128) := 'bl\useltbaln\alntblind\lytcalctblwd\lyttblrtgr\lnbrkrule\nobrkwrptbl\snaptogridincell\allowfieldends';
    wwv_flow_api.g_varchar2_table(129) := 'el\wrppunct'||wwv_flow.LF||
'\asianbrkrule\rsidroot8600143\newtblstyruls\nogrowautofit\usenormstyforlist\noindnmbrts';
    wwv_flow_api.g_varchar2_table(130) := '\felnbrelev\nocxsptable\indrlsweleven\noafcnsttbl\afelev\utinl\hwelev\spltpgpar\notcvasp\notbrkcnstf';
    wwv_flow_api.g_varchar2_table(131) := 'rctbl\notvatxbx\krnprsnet\cachedcolbal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wgrffmtfilter 2450}\nofeaturethrottle1';
    wwv_flow_api.g_varchar2_table(132) := '\ilfomacatclnup0{\*\ftnsep \ltrpar \pard\plain \ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\as';
    wwv_flow_api.g_varchar2_table(133) := 'pnum\faauto\adjustright\rin0\lin0\itap0\pararsid14755898 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs';
    wwv_flow_api.g_varchar2_table(134) := '0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \in';
    wwv_flow_api.g_varchar2_table(135) := 'srsid14635001 \chftnsep '||wwv_flow.LF||
'\par }}{\*\ftnsepc \ltrpar \pard\plain \ltrpar\ql \li0\ri0\widctlpar\wrapd';
    wwv_flow_api.g_varchar2_table(136) := 'efault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid14755898 \rtlch\fcs1 \af0\afs22\al';
    wwv_flow_api.g_varchar2_table(137) := 'ang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {'||wwv_flow.LF||
'\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(138) := 'f0 \ltrch\fcs0 \insrsid14635001 \chftnsepc '||wwv_flow.LF||
'\par }}{\*\aftnsep \ltrpar \pard\plain \ltrpar\ql \li0\';
    wwv_flow_api.g_varchar2_table(139) := 'ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid14755898 \rtlch';
    wwv_flow_api.g_varchar2_table(140) := '\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp103';
    wwv_flow_api.g_varchar2_table(141) := '3 {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14635001 \chftnsep '||wwv_flow.LF||
'\par }}{\*\aftnsepc \ltrpar \pard\pla';
    wwv_flow_api.g_varchar2_table(142) := 'in \ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\para';
    wwv_flow_api.g_varchar2_table(143) := 'rsid14755898 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\lan';
    wwv_flow_api.g_varchar2_table(144) := 'gnp1033\langfenp1033 {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid14635001 \chftnsepc '||wwv_flow.LF||
'\par }}\ltrpar \s';
    wwv_flow_api.g_varchar2_table(145) := 'ectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {\head';
    wwv_flow_api.g_varchar2_table(146) := 'err \ltrpar \pard\plain \ltrpar\s16\qc \fi2880\li0\ri0\widctlpar'||wwv_flow.LF||
'\tqc\tx4680\tqr\tx9360\wrapdefault';
    wwv_flow_api.g_varchar2_table(147) := '\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid6776828 \rtlch\fcs1 \af0\afs22\alang1025';
    wwv_flow_api.g_varchar2_table(148) := ' \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch';
    wwv_flow_api.g_varchar2_table(149) := '\fcs0 '||wwv_flow.LF||
'\lang1024\langfe1024\noproof\insrsid14635001 {\shp{\*\shpinst\shpleft4455\shptop405\shpright';
    wwv_flow_api.g_varchar2_table(150) := '5247\shpbottom1093\shpfhdr0\shpbxcolumn\shpbxignore\shpbypage\shpbyignore\shpwr3\shpwrk0\shpfblwtxt0';
    wwv_flow_api.g_varchar2_table(151) := '\shpz0\shplid2049'||wwv_flow.LF||
'{\sp{\sn shapeType}{\sv 75}}{\sp{\sn fFlipH}{\sv 0}}{\sp{\sn fFlipV}{\sv 0}}{\sp{';
    wwv_flow_api.g_varchar2_table(152) := '\sn fLockAspectRatio}{\sv 1}}{\sp{\sn fLockPosition}{\sv 0}}{\sp{\sn fLockAgainstSelect}{\sv 0}}{\sp';
    wwv_flow_api.g_varchar2_table(153) := '{\sn fLockAgainstGrouping}{\sv 0}}{\sp{\sn pib}{\sv '||wwv_flow.LF||
'{\pict\picscalex105\picscaley92\piccropl0\picc';
    wwv_flow_api.g_varchar2_table(154) := 'ropr0\piccropt0\piccropb0\picw1328\pich1316\picwgoal753\pichgoal746\jpegblip\bliptag1982191550{\*\bl';
    wwv_flow_api.g_varchar2_table(155) := 'ipuid 7625d7beb2922187a56e7c9aa7c90388}'||wwv_flow.LF||
'ffd8ffe000104a4649460001010100dc00dc0000ffdb004300020101010';
    wwv_flow_api.g_varchar2_table(156) := '101020101010202020202040302020202050404030406050606060506060607090806'||wwv_flow.LF||
'0709070606080b08090a0a0a0a0a0';
    wwv_flow_api.g_varchar2_table(157) := '6080b0c0b0a0c090a0a0affdb004301020202020202050303050a0706070a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a';
    wwv_flow_api.g_varchar2_table(158) := ''||wwv_flow.LF||
'0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0affc00011080072007303012200021101031101f';
    wwv_flow_api.g_varchar2_table(159) := 'fc4001f0000010501010101010100'||wwv_flow.LF||
'000000000000000102030405060708090a0bffc400b51000020103030204030505040';
    wwv_flow_api.g_varchar2_table(160) := '40000017d01020300041105122131410613516107227114328191a10823'||wwv_flow.LF||
'42b1c11552d1f02433627282090a161718191a2';
    wwv_flow_api.g_varchar2_table(161) := '5262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a'||wwv_flow.LF||
'838485868';
    wwv_flow_api.g_varchar2_table(162) := '788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e';
    wwv_flow_api.g_varchar2_table(163) := '2e3e4e5e6e7e8e9eaf1'||wwv_flow.LF||
'f2f3f4f5f6f7f8f9faffc4001f01000301010101010101010100000000000001020304050607080';
    wwv_flow_api.g_varchar2_table(164) := '90a0bffc400b5110002010204040304070504040001027700'||wwv_flow.LF||
'0102031104052131061241510761711322328108144291a1b';
    wwv_flow_api.g_varchar2_table(165) := '1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a43444546474849'||wwv_flow.LF||
'4a535455565758595a6';
    wwv_flow_api.g_varchar2_table(166) := '36465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b';
    wwv_flow_api.g_varchar2_table(167) := '9bac2c3c4'||wwv_flow.LF||
'c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c030100021103110';
    wwv_flow_api.g_varchar2_table(168) := '03f00fe7fe8a28a0028a74713ca7082b6344f0c'||wwv_flow.LF||
'5feab7b1e99a6584d757570cb1dbdbdbc45e4964638545500966270001c';
    wwv_flow_api.g_varchar2_table(169) := '9340195159cd20cede83356d346721b703f2ae7f9d7ea07eca1ff0006d0fed05e29f8'||wwv_flow.LF||
'6dff000d21ff00050bf8c5e1bfd9a';
    wwv_flow_api.g_varchar2_table(170) := '7e18ac2b24ba878f2645d5a64209016d249235819864059e449738c44fdfd427f89bff06be7ec27e7693f0bbf66df883fb5';
    wwv_flow_api.g_varchar2_table(171) := ''||wwv_flow.LF||
'078a2c21cbf88bc5b7af67a4c8c33b8047f250aee071fe8728c7476eac01f8ec742daaff00bbced5cff3a593410bbff75f7';
    wwv_flow_api.g_varchar2_table(172) := '541afe86ff6d8ff008280df7fc133'||wwv_flow.LF||
'3c25f68f0c7fc139ff00619f09eb51dc5ac4df0c741d6e2d63c476705c5bbcf1dd5cc';
    wwv_flow_api.g_varchar2_table(173) := '369636889094087797dcde7210a5496af30fd937fe0b99f1fff006eff00'||wwv_flow.LF||
'da33c37fb29597fc12ff00f661d7755f165e35b';
    wwv_flow_api.g_varchar2_table(174) := '58c1ab78767b7b61b629257323b0b9daa2389c92236e9d2803f0b67d10a6ec2fddc5559f4e9a227033838afdf'||wwv_flow.LF||
'4fda37c7b';
    wwv_flow_api.g_varchar2_table(175) := 'ff0481bad3f509ffe0a39ff00044987e13d9c5f10b58f04278e7e08f8a2d4c2dace992225e3a5adb1b190c28644224682543';
    wwv_flow_api.g_varchar2_table(176) := 'bb0033020789f8cff00'||wwv_flow.LF||
'e0de2fd94bf6d2f0b6a1f12ffe08a1ff000502d07e234d6b1fda6e7e17f8fae12c35cb6418e0398';
    wwv_flow_api.g_varchar2_table(177) := 'e26049f957ceb78a3247fae3d6803f1c19590ed65c5257a97'||wwv_flow.LF||
'ed1ffb2dfc74fd95fe256a1f07ff00689f851ad783fc49a7c';
    wwv_flow_api.g_varchar2_table(178) := '8bf68d2b5bb3689ca13812467eecb1b60ed910b230e5588af33bab392dd9b8e01c5004345145005'||wwv_flow.LF||
'cb4f11f886c2dd6d2c7';
    wwv_flow_api.g_varchar2_table(179) := '5dbc8625fbb1c374eaa39cf001f5a2a9d140053a28da56daa29a327815b9e16f0f6a5adea36fa4691a74d77797922c56b6b6';
    wwv_flow_api.g_varchar2_table(180) := 'f11792691'||wwv_flow.LF||
'885545500966248000e493401dc7ecbffb2e7c66fdadbe32e89fb3f7ecfde03bbf1178abc4538834dd3ad57ea';
    wwv_flow_api.g_varchar2_table(181) := '5a5918fcb1448a0b3c8c42a2a924802bf63ed0f'||wwv_flow.LF||
'fc13cbfe0daad1edbc2fa5d9687f1aff006c0bab189f5cd7ee2d4dce91f';
    wwv_flow_api.g_varchar2_table(182) := '0fd645e7cb8f2ac1d5492114a5cccb92ef6d1c8886b6a573e13ff0083687f600b5f07'||wwv_flow.LF||
'784adf4ebafdb33e387867ed5ad6a';
    wwv_flow_api.g_varchar2_table(183) := '92224cfe04d1db3b634ce46e5705547dd96e11dd8bc76d1a1fc99d62eb5ef166b1ad78abc55abdd6a5a96a30b5dea1a85f5';
    wwv_flow_api.g_varchar2_table(184) := ''||wwv_flow.LF||
'c34d3dd4f234acf2c8ec4b3bb312c589249393401fd01dd7ec6b6be3afdae356d77fe0a37f1897f68af84ff1fbe094dff0a';
    wwv_flow_api.g_varchar2_table(185) := 'c7e2b5d69eb12f84750166f77730e'||wwv_flow.LF||
'9f668cd0e9c66b2f3eee09235f31c5a0405dd652ff00889fb5efec91e3dfd8ebf689f';
    wwv_flow_api.g_varchar2_table(186) := '1dfece3f126056d4bc2ce615bc897115fdb3077b7bb8bfe99cd0b472af7'||wwv_flow.LF||
'c3807906bf4d3fe08bff00f052fd43c23f04ed7';
    wwv_flow_api.g_varchar2_table(187) := 'f67af19e9b3789f5ff867ac58df783fc1eb119eebc61a15cdf0336956718e64d42cae717d6839251ae61f9236'||wwv_flow.LF||
'761ee7fb7';
    wwv_flow_api.g_varchar2_table(188) := '0ff00c1397f666f1be97e1df8b3ff00053ff8f7a57c17f0bf84f4bd4348f0ad8d95c25d78c75cf0c8ba965d3ad2ea38fcf8d';
    wwv_flow_api.g_varchar2_table(189) := '25b281cc0a604ba6653'||wwv_flow.LF||
'9919586d001f267fc165bc27e19f8d1f01be157c70f057ec61e20d5fc5be2afd9f7c2be22f177c6';
    wwv_flow_api.g_varchar2_table(190) := '9d3b56bfb8b5b48edad27b3b8d3e6b3488dbc5b1a0476b877'||wwv_flow.LF||
'dd82a30a01dde3dff046c96e3e0bfc67f8bffb5e40be5dcfc';
    wwv_flow_api.g_varchar2_table(191) := '1ef807e20d7345baed1eab710ff0066d9ae7b167bc3f8035f73ebbff0566ff82477c11f83527ecc'||wwv_flow.LF||
'3f0d7e03fc72f895e0d';
    wwv_flow_api.g_varchar2_table(192) := 'd17436b47d37c4df102f2c74abdb3732e6236ab79e53a31df90f6cb9ddd380070d61ff0524ff82275fe8fe24f01f8c7fe095';
    wwv_flow_api.g_varchar2_table(193) := 'de2af0b68'||wwv_flow.LF||
'3af69f6f6fe268fc0be389e23a8dbacbe6471cd1c3736ab304911645576203007a8a760388ff0083a4dfc2fe1';
    wwv_flow_api.g_varchar2_table(194) := 'df8c1f0e7e04783eed67b786c75cf1e5f347fc5'||wwv_flow.LF||
'75e22d6a59ceec7f12c76b1a8ff6429ef5e1bfb007ec66de0cfd9afc43f';
    wwv_flow_api.g_varchar2_table(195) := 'b67f893c31ae5f78ebc71e22b7f00fecb5a0e83addce9b7d7be289a48d65d6a39ada4'||wwv_flow.LF||
'8e5586c47f16ef29dcc91c98e2bec';
    wwv_flow_api.g_varchar2_table(196) := '8f8e7fb187fc13b7fe0b25e3193c5dfb277fc145358d27e2aff0065d969d63e06f8c96e91f9b0dba85b7b486448e36385ea';
    wwv_flow_api.g_varchar2_table(197) := ''||wwv_flow.LF||
'd1b5dbf5247535b5fb7f7c4ef0b7fc134742f0bf8cef2c3c45a4fc58f07fc1fb4f01fc14f87b71e13923d1fc1d773858757';
    wwv_flow_api.g_varchar2_table(198) := 'f125bea8ac6db519a557664743e70'||wwv_flow.LF||
'69144f1a9e1101c8fc55ff0082817ec6bf193e29eb9ff048eff82cf78b74df8afa3f8';
    wwv_flow_api.g_varchar2_table(199) := '56eadf45d13f699d17454d3aff40d73c8885ca48e85c98a2b92d09bb550'||wwv_flow.LF||
'b27923ed1048a5a41f99ff00f056dff82417c6b';
    wwv_flow_api.g_varchar2_table(200) := 'ff82607c4eb6835bd461f167c37f15b0b9f87df123498c1b3d5edcaab08dca9658ae0210c53715653bd1994e4'||wwv_flow.LF||
'78ff00893';
    wwv_flow_api.g_varchar2_table(201) := '4e9ae6e2faeaea46925935289a492462ccec7ca2493d4924d7e8d7fc11e3f6f9f859f1afe1e6a1ff0460ff82965cff6cfc20';
    wwv_flow_api.g_varchar2_table(202) := 'f1f4e961f0f7c41a84c'||wwv_flow.LF||
'3ed1e0fd5df69b648a6707ca8da660626e4452b0520c52c81403f1d2f6d1ade46c0e3762a0afa33';
    wwv_flow_api.g_varchar2_table(203) := 'fe0a43fb05fc56ff82767ed5be2afd973e2dc1e6dc68f78b2'||wwv_flow.LF||
'e8dac470948758d364e6def62ce7e575e19727648b22124a1';
    wwv_flow_api.g_varchar2_table(204) := 'af9d668cc52143da801b45145004d65099a6c62bf53bfe0da4fd94be1b6aff1cbc69ff0521fda4e'||wwv_flow.LF||
'cd57e19fecd3e177f12';
    wwv_flow_api.g_varchar2_table(205) := '5cbcd1865b8d60472496aaaad812344b14b32a839132db0fe319fcbbd162dcf9c7635fb25f19cff00c30c7fc1afbf0a7e0c6';
    wwv_flow_api.g_varchar2_table(206) := '8e7ec7e24'||wwv_flow.LF||
'fda73c6971e25f12edf95a7d2e02248c03d4831c1a49c74c48e3f8b900f83bf6c7fda9fe257edcff00b4ef8e7';
    wwv_flow_api.g_varchar2_table(207) := 'f6a5f8ad72cdaa78aae24b98acfcc2d1e9f6a03'||wwv_flow.LF||
'2dbda479fe08a2548c773b7272492697c38f85fe31f8a7e3287e1afc3cf';
    wwv_flow_api.g_varchar2_table(208) := '0e5d6adaf6bcb6f61a3697671ee96eeea6791238947ab3103d39e6b8fd32d47d9ae3e'||wwv_flow.LF||
'5ff98667f46afd5aff0082147c38f';
    wwv_flow_api.g_varchar2_table(209) := '057ecc7f097e357fc1623e30787e1bfd37e117865b4cf01d8dc70b77af4b1b6403fc2d8b8b6801e702f58e3280d007abf8b';
    wwv_flow_api.g_varchar2_table(210) := ''||wwv_flow.LF||
'fc47f03bfe0ddef8193fc3cf84da7e89e31fdaebc55e155b9f14789ee611716be0db4911da3862078ea1b6a70662be6cb88';
    wwv_flow_api.g_varchar2_table(211) := 'fc989bf377e32fc40f89ff1d3c73e'||wwv_flow.LF||
'2cf89ff187c71a9f893c41a968ab2df6adab5d34d2c87fd230327eea8e8a8b8550300';
    wwv_flow_api.g_varchar2_table(212) := '0000a4f8bff00117c77f1d3e2678ebe307c4fd765d53c41e22b36d4356b'||wwv_flow.LF||
'e98f324d235c9200fe151c2aa8e154051800549';
    wwv_flow_api.g_varchar2_table(213) := 'acd9aaaf88801d3c369ff00b75548ab19faf6871c635d057eee8319fd6e2a4f10e8912b6b202fddb2b73ff8f4'||wwv_flow.LF||
'95eb7e01f';
    wwv_flow_api.g_varchar2_table(214) := 'd91bf698fda10ebc7e077c02f16f8aa393458a25bad17419e78049bae3e532aaec53c8e0b0eb5ec7fb687fc11fbf6ccfd96b';
    wwv_flow_api.g_varchar2_table(215) := '59d4a11f0bb58f1ae93'||wwv_flow.LF||
'71e1ab2bc97c41e0ed06eeead6da42d2f9b6f2111e55a3239240055d0f0490283dd3e33d7f45782';
    wwv_flow_api.g_varchar2_table(216) := 'e7539e12cad1dc599565e181dcbc835fa05fb147fc14f3e1f'||wwv_flow.LF||
'7ed09e0ab8ff008275ff00c15c42f8c3e1aead7f6f65e15f8';
    wwv_flow_api.g_varchar2_table(217) := '81aac99d4bc2d7acb18b791ee4e5ca2c8e36cec4b4409590bc25953e1ff001258490ddeb504d132'||wwv_flow.LF||
'b25d59ab232e0a9dcb9';
    wwv_flow_api.g_varchar2_table(218) := '04763581e28d397cdd49827fcc72c47eb6f482c757ff053ff00f82767c4dff82757ed11abfc1cf1bb1d4347bebeb7bff0678';
    wwv_flow_api.g_varchar2_table(219) := '9a38f6c5a'||wwv_flow.LF||
'ce9acf12a4a3190b22905248f3f2b2e4655919be54d7ec5a27ba913e565bf870476e22afd95f085e4fff00056';
    wwv_flow_api.g_varchar2_table(220) := '8ff00822ef8dbe0af8b545f7c56fd95ee60d5fc'||wwv_flow.LF||
'27a94cdbae6ffc3eb1a4cf067ef3e208a68768ce5adacc9c93cfe41789a';
    wwv_flow_api.g_varchar2_table(221) := 'cf0d7bc7fcc4a11fa435049fa5ffb5dcbff000f9fff008213e95fb5fdd27dbfe397ec'||wwv_flow.LF||
'ad7a9a27c40bafbd75ace80c233f6';
    wwv_flow_api.g_varchar2_table(222) := 'a93bb7eecc7705d8e03dbdf607cf5f8afac5bf972b301d1bfa57ebb7fc1b11f17345d33f6f3f16fec73f1100baf077c7af0';
    wwv_flow_api.g_varchar2_table(223) := ''||wwv_flow.LF||
'1ea7e1cd634b95b11dc4f159b5c465b3c67ece2f621ff5f15f98dfb4efc1cd6fe007c78f1d7c09f1292da8782fc5fa86857';
    wwv_flow_api.g_varchar2_table(224) := 'cc571ba5b4b87818e3d09427f1a00'||wwv_flow.LF||
'f34a283c7145006c68280b2ffb86bf663fe0e1bf096b86fbf634fd8c3c251c40f877f';
    wwv_flow_api.g_varchar2_table(225) := '678d360d26ce6b85863f3ee043698dcc4282df6041d79381d48afc67d00'||wwv_flow.LF||
'8dcbfee7f5afd9eff838d749f0afc45fda1bf65';
    wwv_flow_api.g_varchar2_table(226) := '5f883e2ef1b7fc239e16f157ecf1a42dc788934f92efec702cf24d24a9147f34cc12e50aa02b925416504b000'||wwv_flow.LF||
'f987e3aff';
    wwv_flow_api.g_varchar2_table(227) := 'c12cfe3dfece9f05f44f8b1e27bdd3e417de02b8d57c65a5dc4f1da4be139e3beb9b48ac2e0cb20f36e2630b18e241e63b47';
    wwv_flow_api.g_varchar2_table(228) := '38546581a43f687ed54'||wwv_flow.LF||
'7fe1487fc1b71f037e17e8c7c89fe2578b354d7f5e78f8fb4c711bc28adeb856b3fc6115f227ed2';
    wwv_flow_api.g_varchar2_table(229) := '7fb53fc1afda6fe1268de006f1e789b4f3e18f02dd5f69336'||wwv_flow.LF||
'b37977a84b7daa0bfbe8fc8d559f227bc9ec23b1912f62052';
    wwv_flow_api.g_varchar2_table(230) := '267fb3102154fb2fd77fb7b8ff84fff00e0deff00d967e26e95f3dae8579ac6857857fe59cc7ed6'||wwv_flow.LF||
'8037a67ec4c7f11ea29';
    wwv_flow_api.g_varchar2_table(231) := 'a03e0c9a0022f10363fe65e4ffdb9afd5eff82767fc1217c2da47c03d53f6fafdaefc3f6fa859dd68505c783fc0bab69ef71';
    wwv_flow_api.g_varchar2_table(232) := '6b2db877d'||wwv_flow.LF||
'9797d0ac91b4f1c82505200caa530cfb83841f9c1fb32e93e04f117ed0da4e95f143c31ae6b7e19696c1fc47a';
    wwv_flow_api.g_varchar2_table(233) := '3f8674f6bbbfbdb0496e1ee21822520b3b44aea'||wwv_flow.LF||
'3046339ed5fd0758ff00c1603f667834f92c25f809f1a2c2d6cac55bc89';
    wwv_flow_api.g_varchar2_table(234) := '3e12def96b16180451186070131b47418f514f52ba1e47e32fdb03f6be9348b9f0f7c'||wwv_flow.LF||
'29f15daf8774db1d39574b8bc23f0';
    wwv_flow_api.g_varchar2_table(235) := '5b51896dd46f002f9d05f458002e02a607a722bc97f64aff82df7ed8d69f1bfc51f053e29fc0dd73e3247a6cc4588f05f87';
    wwv_flow_api.g_varchar2_table(236) := ''||wwv_flow.LF||
'fc9d6e00b3488ccf0c30a4722615721a38594e4b11f7471dfb6e7fc148b46f889aa78934ff00873ff0480f0bde59db69bbe';
    wwv_flow_api.g_varchar2_table(237) := 'dfc45f11be1fcb35ddf29330c3476'||wwv_flow.LF||
'd1c4d0fddced13b9f9fa8cd707f077fe0b29fb437ec8736b76be05fd897e15e87a698';
    wwv_flow_api.g_varchar2_table(238) := '6da6be8b49f075f69f71787320c4971f68667da3eeef0db771c75a649f4'||wwv_flow.LF||
'8ffc14a7e0e7c30fdba3e1fea7af597fc12fbe3';
    wwv_flow_api.g_varchar2_table(239) := 'e7867e23148a4d3fc61a4f8274c57ba9410563bc44bf0d7317014b30f31072a700ab7e35fc62f86fe39f855e3'||wwv_flow.LF||
'2f117c3df';
    wwv_flow_api.g_varchar2_table(240) := '897e11d4342d734df1169f1ea1a4ea96ad0cf6ec45ab00c8c011956561ea0823835fd187fc136bfe0ac3f0b3fe0a1f79aef8';
    wwv_flow_api.g_varchar2_table(241) := '1b4ef02ea3e15f18786'||wwv_flow.LF||
'6ce2bbd5b47ba9c5c5bcb6ee42f9b04e0296018a86574420bae370c91f0cff00c1d2dfb3a681a06';
    wwv_flow_api.g_varchar2_table(242) := 'a9f0fbf6a5d034c8e0bad72fa2d0bc472c7185f3e4867865b'||wwv_flow.LF||
'591b1f79fcb33a163ced8a31d14612ec544f9bff00e0dc8f1';
    wwv_flow_api.g_varchar2_table(243) := 'ebf863fe0a7137c39b955974ef1f786f55d1b50b39398e644b18af46e1d0ffc7a91f4661dcd7c4f'||wwv_flow.LF||
'7dfb157c4cf899fb517';
    wwv_flow_api.g_varchar2_table(244) := '8f3f676f853a6add4fe15f1d4d65a84924c3367656f74904d7922fde30c28a6495c03b114b1c0afb0bfe0de5f095f78a3fe0';
    wwv_flow_api.g_varchar2_table(245) := 'ad3e1ad5e'||wwv_flow.LF||
'ce2668fc3f6dac6a178cbfc31b68ed6c09f6df7083f1af97fc65f19be1c68ffb68fc62fda5b54f1d6b16b2c7f';
    wwv_flow_api.g_varchar2_table(246) := '10b52d47c2fa3f87aeae2da5d726bbbbf96196e'||wwv_flow.LF||
'a12a60b311c85a7dac24963fdcc7b4c86588649d87c0efd94be2bffc137';
    wwv_flow_api.g_varchar2_table(247) := 'bfe0b0ff084ebfe20d3f50d161fda334ef0fe83e24b5ba8a26d7acc6a30585d5dc56d'||wwv_flow.LF||
'e634ab07ef2585a420c7e6a4b12c8';
    wwv_flow_api.g_varchar2_table(248) := 'ed13e3c87fe0e2ff0259fc3dff82cafc7ad0aca1548ee3c5167a99551d5ef74cb3bc73f8b4ec4fbd7ab786bc67f0b7f6b0f';
    wwv_flow_api.g_varchar2_table(249) := ''||wwv_flow.LF||
'f82b8fc27f893f0e3c73a85d6aba87ed2da0e9cda2dc59cc2d4e8f06ad6a6caf6c0ba8fb2dbfd95555ac98298193318f2dc';
    wwv_flow_api.g_varchar2_table(250) := '45079effc1cb9e24b4f13ff00c169'||wwv_flow.LF||
'fe395f59481a38354d16cf8fefc1a1e9d0b8ff00bed1aa40fcfb9062461ef45129cc8';
    wwv_flow_api.g_varchar2_table(251) := 'd8f5a28034343970f8cff0009afd8eff828e20fdad7fe0deffd907f6c3d'||wwv_flow.LF||
'1ffd26f3e16c775f0f3c4de5f325ba2c42da169';
    wwv_flow_api.g_varchar2_table(252) := '4fa634b80827fe7ed7fbd5f8cfa74de54d827ad7ec27fc1bb7e3cf087ed8ffb33fc7aff0082247c56d760b45f'||wwv_flow.LF||
'8a5e1b97c';
    wwv_flow_api.g_varchar2_table(253) := '47f0ceeaf1be4b5d7ad6342f81c924182cee36ae3e4b39ffbd401f9d7a65c8fb35cf3ff0030bc7e8d5fae3ff04b678bfe0a0';
    wwv_flow_api.g_varchar2_table(254) := '7ff0004a2f8f9ff0004'||wwv_flow.LF||
'b7b6659fc73e1cb51e39f8636f238df72f801ede2cf03f7d179649e9fda59ec71f925e34f0678c7';
    wwv_flow_api.g_varchar2_table(255) := 'e12f8e3c47f0b3e226853e97af78766b8d335ad36e97125ad'||wwv_flow.LF||
'd40f2472c6deeaea457b47ec5bfb60fc49fd88ff0068fd1bf';
    wwv_flow_api.g_varchar2_table(256) := '69af85370a754f0cac53c963348561d42d8f9cb35a4b8fe09232c84f55c86186504007eab7fc11f'||wwv_flow.LF||
'ff00e0a63ff04bff00d';
    wwv_flow_api.g_varchar2_table(257) := '8abe047f627c7bf84b71a37c58d06faf27d5bc5d1f8352f2f2e2091a658c4771feba10916f85a1f940f98f3e6357db371ff0';
    wwv_flow_api.g_varchar2_table(258) := '00715ff00'||wwv_flow.LF||
'c133ed85d197c67e2bff0043b5171363c2737119dfc8e793f2357e71ff00c14cbf626f007eda1f08f57ff82b8';
    wwv_flow_api.g_varchar2_table(259) := 'ffc1382ce4d6bc3de28d29e4f8a7e01b18435ff'||wwv_flow.LF||
'00877544491ee27f25324e4c9ba6500e0fefd4bc52968ff3d350d6d5a3d';
    wwv_flow_api.g_varchar2_table(260) := '7c16fbde1f41ffa5355619fd15ddffc1c41ff0004d5b217467f1978abfd0ed56e26c7'||wwv_flow.LF||
'84e6e10efc11cf3f71a96eff00e0e';
    wwv_flow_api.g_varchar2_table(261) := '1eff826b591b813f8cbc55fe8b1a49363c27370ac4e3bf3d0d7f3d3e20d523906bc55fae8317f3b9a7788b528f76b47cceb';
    wwv_flow_api.g_varchar2_table(262) := ''||wwv_flow.LF||
'636fff00a1494728f94fe83a7ff8387bfe09956135c48de2bf142c90b46b332f8426cfce46de73cf5ae4fe307fc178ff00e';
    wwv_flow_api.g_varchar2_table(263) := '08e3f14bc3b3786fe31f87aff00c6'||wwv_flow.LF||
'1616379195d2b5ef872b7b18b865010a2dc0281f12603718dc790335f81fe23d6504b';
    wwv_flow_api.g_varchar2_table(264) := 'ab056eb3d9ffe84b5f457fc137ffe099ff127fe0a15f13755d635abb93c'||wwv_flow.LF||
'2bf0a7c37aa417be3af1fdf6d86dedede08e19a';
    wwv_flow_api.g_varchar2_table(265) := '4821924c234c5179272b129defc6d572c23e9bfd84b54f09fec39fb1afed41ff056ab5f0bcbe19b4f1c6a175e'||wwv_flow.LF||
'12f80fa4d';
    wwv_flow_api.g_varchar2_table(266) := 'c4999923b99951361c9f31639bc904839c69b39f435f8e1e27bb05ef4eeff00989407f486beeeff0082d67fc1473c03fb51f';
    wwv_flow_api.g_varchar2_table(267) := '8a343fd97ff0065ad39'||wwv_flow.LF||
'749f81ff0007a6b7d2fc19676e195354993ca57d4194f382bf247bf2fb77bb61a6751f9f7e23bfd';
    wwv_flow_api.g_varchar2_table(268) := 'cd77f375bf84fe915488fb97fe0dacf80eff1bbfe0ae1e17f'||wwv_flow.LF||
'14dfc0ada37c38b1d43c59ac4d270912c36a20818b1e062e6';
    wwv_flow_api.g_varchar2_table(269) := 'e206fa21f4247c35ff0508f8f91fed3dfb68fc5afda12d67692d7c61f10f54d534d2dd56d25b963'||wwv_flow.LF||
'6e9ff018bcb5fc2bf4f';
    wwv_flow_api.g_varchar2_table(270) := 'bf66e8dbfe0927ff040df89dfb60f8a07f67fc50fdaa674f0b7c37b67f96e2df4331bc4d76bfc51e626bbb80e383fe8473f3';
    wwv_flow_api.g_varchar2_table(271) := '2d7e2eeb7'||wwv_flow.LF||
'73bde45cf57fe82803349c9cd14514002b156dc2bd2bf66bfda03e23feccff001a3c2ff1ff00e10ebeda6f89b';
    wwv_flow_api.g_varchar2_table(272) := 'c21ab43a9e8f78bc859a260db5c7f1c6c32ae87'||wwv_flow.LF||
'8646653c135e6b52dadcb5bbe477e2803f6cbfe0ad3fb3f7c3aff82a4fe';
    wwv_flow_api.g_varchar2_table(273) := 'c9f61ff0005d1fd86b4056be9b474b0fda17c0961fbcb8d1750b78955ef4a81b98229'||wwv_flow.LF||
'5123606e83c89f681e711f9756fab';
    wwv_flow_api.g_varchar2_table(274) := '662bef9bae9aa3f492bd4bfe0935ff055bf8cdff04b8f8f4df123c1102ebde0fd76de3b3f1ff80efa6c5a6bb620b7182084';
    wwv_flow_api.g_varchar2_table(275) := ''||wwv_flow.LF||
'9d03398e5c1da59948647746fb83f6d8ff0082457c16fdb6be11ea5ff0526ff821e5f0f1678475481a6f1a7c15b38c2eb1e';
    wwv_flow_api.g_varchar2_table(276) := '16bc2acf2456f6c096c0dc7fd1464'||wwv_flow.LF||
'8c06b73344ea1002b7fc1bb1a7fedb3e2bfdb27c4337ec99f172cfc25a4e8be0ff00e';
    wwv_flow_api.g_varchar2_table(277) := 'd1f1c5d788ece4bbd12ea146985b5b5dc2b2479324a70b22bac91a099d0'||wwv_flow.LF||
'9dac8df4efc4af82bff04acff82997c2a5fda67';
    wwv_flow_api.g_varchar2_table(278) := 'c65a2ebbfb2a788fc617171a5c3e3e9b4966f04f882f236955e449dd62806584ad976b391c89322428e45aff8'||wwv_flow.LF||
'2527c39f8';
    wwv_flow_api.g_varchar2_table(279) := '4bf0abfe09efe32f863a27c488d65d4bc136b75f183c45e179526bf975ef104ada7d87862c981e751b5d3c5d45e436425f6a';
    wwv_flow_api.g_varchar2_table(280) := 'd093828d8f957fe0e0e'||wwv_flow.LF||
'fdb634ef14fc43d07fe09e1f0aad74cd2fc13f027c389617da4e81213649af344cb3c119e0c8967';
    wwv_flow_api.g_varchar2_table(281) := '185b557601cb8b866e5cd007a678eff00e0dbcfdb9752b3d4'||wwv_flow.LF||
'3c49fb3f7c4ff861f12741d4b4f5874dd4b41f14189a6c798';
    wwv_flow_api.g_varchar2_table(282) := '72c248c4433bc7dd95c7bd67e93ff0006dd7fc150fc537d7d06b7e1ef04f876dee2de3537dad78c'||wwv_flow.LF||
'2368a30a58966fb324c';
    wwv_flow_api.g_varchar2_table(283) := 'd800ff76a7f1668daefec5bff00047bf845f1f7c2bfb06f877c551f8b7c23ad5ffc41f8a9711ddd9df69125d6a2d168e05dd';
    wwv_flow_api.g_varchar2_table(284) := '94f149c24'||wwv_flow.LF||
'ab85903a92500db920f9e7fc1167c59f087f6abf8fbf143e06feddd7fabf8c3c3ba97c1cd52f34bb8d5b56b8b';
    wwv_flow_api.g_varchar2_table(285) := 'a9f4bb8b5024967b5577204cb6c6e2453824342'||wwv_flow.LF||
'b8a7703dbb48ff0082717fc1283f629d79756ff82827edd7a5fc4cf124b';
    wwv_flow_api.g_varchar2_table(286) := '7b6d1c3f0a3e17dda624b9deaa90dcdc0943468cc41dd33d9a81c97c67367fe0acff1'||wwv_flow.LF||
'b3f69ef8bffb24fc48f83bf0a3c2b';
    wwv_flow_api.g_varchar2_table(287) := '67f07fc1bf007e20697a1f8ebe01f876c912e23d1ae4432d96b5717703ecbab59666c793122c685964769b8907cd1ff0005';
    wwv_flow_api.g_varchar2_table(288) := ''||wwv_flow.LF||
'e0fd98f52fd9a7c45f0775fbbd174fb57d6fe165a68baa5de956a915b6a9a968b74f632ea1184f94adcdbfd8ae01ea44e18';
    wwv_flow_api.g_varchar2_table(289) := 'fdeafa63fe09d5f1a7c41fb7df873'||wwv_flow.LF||
'c03f17fc23a2697e28f88ff0fac57e177ed29e0cd5758b7b3ff84d7e1adea88e3d61d';
    wwv_flow_api.g_varchar2_table(290) := 'a77412c962a7f78db8bb342acc4028a501f8dfafeafbbed9f3f5d4613ff'||wwv_flow.LF||
'00a2abea8ff823a7fc1316ff00fe0a2ff1f750f';
    wwv_flow_api.g_varchar2_table(291) := '15fc56bb3a07c12f877326b1f14bc5d7937d9edd6d618d66fb0a4c480b248a877be479516f909cec57f40fd99'||wwv_flow.LF||
'3fe084be3';
    wwv_flow_api.g_varchar2_table(292) := 'afdacbf690f88dad597c4cb7f0bfeccbe04f1b6a514ff001cb5d92386d755d22cae1904d62d2158ee0b47164dc03f678fe66';
    wwv_flow_api.g_varchar2_table(293) := '2cc42c6f99ff0572ff8'||wwv_flow.LF||
'2bcfc14bbf8216dff04b3ff825768d27857e00f866658fc41afc21a3bcf1cdd2b2b3cd2b30121b7';
    wwv_flow_api.g_varchar2_table(294) := '6701c97c3ccc14b044544a00f1fff0082ea7fc14f2cbfe0a2'||wwv_flow.LF||
'ff00b54e3e15daff0065fc23f86f683c3bf0af43861f2624b';
    wwv_flow_api.g_varchar2_table(295) := '18f607bcf2b0046d394421700a451c08465093f075dcc66999fdeacea77c6691901ead9fd0552a0'||wwv_flow.LF||
'028a28a0028a28a009a';
    wwv_flow_api.g_varchar2_table(296) := 'deede0e33c118af6cfd8dbf6ecfda67f613f8b10fc6bfd96fe2c6a1e17d6e18963b916ec1edb5084127c8b981f31dc444ff0';
    wwv_flow_api.g_varchar2_table(297) := '00ba9c1f9'||wwv_flow.LF||
'976b00c3c369c923c6728d401fbc1f01ff00e0b6bff04c1fdb9fc6da3fc42fdb77c05aa7ece3f1db4bbcb6bdb';
    wwv_flow_api.g_varchar2_table(298) := '3f8e1f0bad44fa6de5f42aeb0dcde5a4914eb23'||wwv_flow.LF||
'29760a2ea0ba08a5b13c60f1e7ff0015bfe0daefda0be3743ac7c6dff82';
    wwv_flow_api.g_varchar2_table(299) := '7efedb7f0c3f688d0f56679e4beb5f12476ba9cb348cee7cdf9e6b7321663b8bce8c5'||wwv_flow.LF||
'b3951c81f8d30eab22060ffc4b8ae';
    wwv_flow_api.g_varchar2_table(300) := '93c13f15bc6df0f35d5f157c3ef1a6aba0ea90c788352d1f5096d6e23ebf7648d830fc0d007ee17fc1543fe09a5fb49fc67';
    wwv_flow_api.g_varchar2_table(301) := ''||wwv_flow.LF||
'f805e08d4be1afecfdfb4069be32f875f083c37e018fe1affc20b67a8e97aa47605fcdba5bfd2f51b88f3be69661bd096c2';
    wwv_flow_api.g_varchar2_table(302) := '8c29391f3effc12dff619ff00829d'||wwv_flow.LF||
'fecc5fb7b7c3ff008f9e29ff00827afc5993c3fa4eadf67f12dbc9e1192069b4cb982';
    wwv_flow_api.g_varchar2_table(303) := '6b4bc502e0c68e7c8b8930a580271c8eb5f27f81bfe0b7dff00055ff877'||wwv_flow.LF||
'67f61f0cff00c140be28490c718589756f144da';
    wwv_flow_api.g_varchar2_table(304) := '86debc0fb51938fe55b1e23ff0082fa7fc15ebc4967258dff00edf9e3d8d1971bb4fbd8ad1c7d1e08d187e740'||wwv_flow.LF||
'1fab1f1df';
    wwv_flow_api.g_varchar2_table(305) := 'f00e0951ff0526fdbb3f617f85bfb34fed13f0fbc37f0b6dbe09f883515d17e297c4af1dda34b2f85640ab6f04d6b63f68d9';
    wwv_flow_api.g_varchar2_table(306) := '3a4715b21df32285b75'||wwv_flow.LF||
'04924b0f014f037fc1bb9ff0499793c47f163e30de7ed85f152c6456b7f0c786a3897c336f7031b';
    wwv_flow_api.g_varchar2_table(307) := '7cd6567b77407860f35d74cfd9c1afca2f8cffb59fed19fb4'||wwv_flow.LF||
'25db5ffc79fda03c69e3598481e393c59e29bbd4590fa8f3e';
    wwv_flow_api.g_varchar2_table(308) := '46c7e15e7775acb396da739606803ed7ff829c7fc1713f6beff00829285f0178b754b3f057c31d3'||wwv_flow.LF||
'6688687f0bfc1f9834d';
    wwv_flow_api.g_varchar2_table(309) := '8238f6f9467230d74e800c17c46846638e3c915f11dfea4f333043f79b39aaf35ccb31cb3547400649e4d145140051451400';
    wwv_flow_api.g_varchar2_table(310) := '514514005145140051451400bb9bfbc68dedfde345140099a28a2800a28a2800a28a2800a28a2803fffd9}'||wwv_flow.LF||
'}}{\sp{\sn p';
    wwv_flow_api.g_varchar2_table(311) := 'ictureGray}{\sv 0}}{\sp{\sn pictureBiLevel}{\sv 0}}{\sp{\sn fFilled}{\sv 0}}{\sp{\sn fNoFillHitTest}';
    wwv_flow_api.g_varchar2_table(312) := '{\sv 0}}{\sp{\sn fLine}{\sv 0}}{\sp{\sn wzName}{\sv Picture 1}}{\sp{\sn posrelv}{\sv 1}}{\sp{\sn dhg';
    wwv_flow_api.g_varchar2_table(313) := 't}{\sv 251659264}}'||wwv_flow.LF||
'{\sp{\sn fLayoutInCell}{\sv 1}}{\sp{\sn fAllowOverlap}{\sv 1}}{\sp{\sn fBehindDo';
    wwv_flow_api.g_varchar2_table(314) := 'cument}{\sv 0}}{\sp{\sn fHidden}{\sv 0}}{\sp{\sn sizerelh}{\sv 0}}{\sp{\sn sizerelv}{\sv 0}}{\sp{\sn';
    wwv_flow_api.g_varchar2_table(315) := ' fLayoutInCell}{\sv 1}}}{\shprslt\par\pard'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\pvpg\posx4454\posy404\dxfrtext180';
    wwv_flow_api.g_varchar2_table(316) := '\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {\pict\picscale';
    wwv_flow_api.g_varchar2_table(317) := 'x105\picscaley92\piccropl0\piccropr0\piccropt0\piccropb0'||wwv_flow.LF||
'\picw1328\pich1316\picwgoal753\pichgoal746';
    wwv_flow_api.g_varchar2_table(318) := '\wmetafile8\bliptag1982191550\blipupi220{\*\blipuid 7625d7beb2922187a56e7c9aa7c90388}010009000003c64';
    wwv_flow_api.g_varchar2_table(319) := 'd000000009d4d000000000400000003010800050000000b0200000000050000000c0233003300030000001e0004000000070';
    wwv_flow_api.g_varchar2_table(320) := '1040004000000'||wwv_flow.LF||
'070104009d4d0000410b2000cc00720073000000000032003200000000002800000073000000720000000';
    wwv_flow_api.g_varchar2_table(321) := '100180000000000f89a000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(322) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(323) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(324) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(325) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(326) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(327) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(328) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(329) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(330) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(331) := '00000000000000000000000000000000000000000000000000000000808080000000808080000000808'||wwv_flow.LF||
'080000000808080';
    wwv_flow_api.g_varchar2_table(332) := '0000008080800000008080800000008080800000008080800000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(333) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(334) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(335) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(336) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(337) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(338) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000808080000000808080';
    wwv_flow_api.g_varchar2_table(339) := '000000808080000000808080000000808080000000808080000000000000000'||wwv_flow.LF||
'00080808000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(340) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(341) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(342) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(343) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(344) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(345) := '0000000000000000000000808080000000000000000000808080808080808080000000808080808080808080000001010100';
    wwv_flow_api.g_varchar2_table(346) := '8080808080800'||wwv_flow.LF||
'0000080808080808080808000000080808080808080808000000080808080808080808000000080808080';
    wwv_flow_api.g_varchar2_table(347) := '8080808080000000808080000000000000000000808'||wwv_flow.LF||
'0800000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(348) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(349) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(350) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(351) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(352) := '000000000000000000000000000000000000000000000080808000000080808'||wwv_flow.LF||
'08080808080808080808080800000008080';
    wwv_flow_api.g_varchar2_table(353) := '808080808080808080808080808080808080808080808080800000008080800000008080800000008080808080808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(354) := '0000000000000000008080800000008080800000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(355) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(356) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(357) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(358) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080';
    wwv_flow_api.g_varchar2_table(359) := '8080000000808'||wwv_flow.LF||
'0800000008080800000008080808080808080800000008080808080808080800000008080808080810101';
    wwv_flow_api.g_varchar2_table(360) := '0080808080808080808101010000000080808080808'||wwv_flow.LF||
'0808080808080808080808080808080808081010100808080808080';
    wwv_flow_api.g_varchar2_table(361) := '8080808080808080808080808080808080800000008080800000008080800000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(362) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(363) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(364) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(365) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(366) := '000000000000000000000000808080000000000000000000808080000000808080808080808080808080808080808'||wwv_flow.LF||
'08101';
    wwv_flow_api.g_varchar2_table(367) := '0100808080000000808081010100808080808080808081010100808080808080808080808080808080808080808081010100';
    wwv_flow_api.g_varchar2_table(368) := '80808080808080808080808'||wwv_flow.LF||
'000000080808080808080808000000080808000000080808000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(369) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(370) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(371) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(372) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(373) := '8080800000008080800000008080808080808080800'||wwv_flow.LF||
'0000101010080808101010080808101010080808101010000000101';
    wwv_flow_api.g_varchar2_table(374) := '0100808081010100808081818181010101010100808081010100808080808080808081010'||wwv_flow.LF||
'1010101010101008080810101';
    wwv_flow_api.g_varchar2_table(375) := '0080808080808080808101010080808080808080808101010080808080808080808080808080808080808000000080808000';
    wwv_flow_api.g_varchar2_table(376) := '000'||wwv_flow.LF||
'08080800000008080800000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(377) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(378) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(379) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(380) := '0080808000000080808000000080808000000080808080808080808080808080808080808080808080808101010080808080';
    wwv_flow_api.g_varchar2_table(381) := '80808080818181839393952'||wwv_flow.LF||
'52526b6b6b8484849494949c9c9ca5a5a5a5a5a5a5a5a59c9c9c8c8c8c7b7b7b5a5a5a42424';
    wwv_flow_api.g_varchar2_table(382) := '21818181010100808080808080808080808080808080808080808'||wwv_flow.LF||
'080808080808080808080808080808080000000808080';
    wwv_flow_api.g_varchar2_table(383) := '00000080808000000080808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(384) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(385) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(386) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000008080800000008080800000';
    wwv_flow_api.g_varchar2_table(387) := '0080808080808080808080808080808080808080808080808101010080808101010101010'||wwv_flow.LF||
'1010100808081818184242428';
    wwv_flow_api.g_varchar2_table(388) := '48484adadade7e7e7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(389) := 'fff'||wwv_flow.LF||
'ffffffffffefefefc6c6c69494945a5a5a2121211010100808081010100808080808080808081010100808080808080';
    wwv_flow_api.g_varchar2_table(390) := '808080808080808080808080000000808'||wwv_flow.LF||
'08000000080808000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(391) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(392) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(393) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(394) := '00808080000000808080808'||wwv_flow.LF||
'080808080808080808080808081010100808080808080808082121216b6b6bb5b5b5f7f7f7f';
    wwv_flow_api.g_varchar2_table(395) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(396) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffcecece84848439393910101000000010'||wwv_flow.LF||
'101008080810101';
    wwv_flow_api.g_varchar2_table(397) := '0000000080808080808080808000000080808000000080808000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(398) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(399) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(400) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000080808000000080808000';
    wwv_flow_api.g_varchar2_table(401) := '0000808080808080808080000001010100808081010100808081010101010101818185a5a5ac6c6c6fffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(402) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffffffffdededeb5b5b58c8c8c7b7b7b6363635252524a4a4a4a4a4a4242424a4a4a4a4a4a636';
    wwv_flow_api.g_varchar2_table(403) := '3637373738c8c8ca5a5a5cececef7f7f7'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffdedede7b7b7b29292910101';
    wwv_flow_api.g_varchar2_table(404) := '010101008080808080810101010101008080808080810101000000000000008'||wwv_flow.LF||
'08080808080000000000000000000000000';
    wwv_flow_api.g_varchar2_table(405) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(406) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(407) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(408) := '00008080808080808080808080808080808080810101008080808'||wwv_flow.LF||
'08082121218c8c8cefefeffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(409) := 'ffffffff7f7f7b5b5b57b7b7b4242421818182121214242426b6b6b9494947b7b7b1010101010101010'||wwv_flow.LF||
'101818181010101';
    wwv_flow_api.g_varchar2_table(410) := '010101818181010101818186363632929291818183131316b6b6ba5a5a5dededefffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(411) := 'fadadad424242'||wwv_flow.LF||
'0000001010100808081010100000000808080808080808080000000808080000000000000000000000000';
    wwv_flow_api.g_varchar2_table(412) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(413) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(414) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000080808000000080808080';
    wwv_flow_api.g_varchar2_table(415) := '808'||wwv_flow.LF||
'1010100808081010100808081010100808081010101010102929299c9c9cffffffffffffffffffffffffffffffefefe';
    wwv_flow_api.g_varchar2_table(416) := 'fa5a5a54a4a4a21212110101018181810'||wwv_flow.LF||
'10107b7b7bffffffffffffffffffffffffcecece1818181010102121211818181';
    wwv_flow_api.g_varchar2_table(417) := '81818101010212121181818424242ffffffa5a5a51010102929297b7b7b4a4a'||wwv_flow.LF||
'4a101010393939848484d6d6d6fffffffff';
    wwv_flow_api.g_varchar2_table(418) := 'fffffffffffffffffffffc6c6c64a4a4a101010101010080808101010080808080808080808080808080808000000'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(419) := '8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(420) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(421) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000808080000000000000';
    wwv_flow_api.g_varchar2_table(422) := '80808080808080808080808080808080808101010080808181818949494f7f7f7ffffffffffffffffff'||wwv_flow.LF||
'ffffffbdbdbd5a5';
    wwv_flow_api.g_varchar2_table(423) := 'a5a212121101010101010181818212121181818101010636363ffffffcecece6b6b6b4242422121211818181010101818182';
    wwv_flow_api.g_varchar2_table(424) := '1212110101010'||wwv_flow.LF||
'1010181818212121737373ffffff636363212121949494ffffffcecece181818101010101010181818393';
    wwv_flow_api.g_varchar2_table(425) := '9399c9c9cf7f7f7ffffffffffffffffffffffffbdbd'||wwv_flow.LF||
'bd39393908080810101008080810101000000008080808080808080';
    wwv_flow_api.g_varchar2_table(426) := '8000000080808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(427) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(428) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000808080000000808080';
    wwv_flow_api.g_varchar2_table(429) := '000000808080808081010100000001010'||wwv_flow.LF||
'10101010101010636363efefefffffffffffffffffffffffffa5a5a5393939101';
    wwv_flow_api.g_varchar2_table(430) := '010181818181818181818101010212121181818212121080808424242ffffff'||wwv_flow.LF||
'cecece10101021212121212121212110101';
    wwv_flow_api.g_varchar2_table(431) := '0212121212121212121101010212121181818b5b5b5ffffff393939313131ffffffffffff94949418181810101018'||wwv_flow.LF||
'18181';
    wwv_flow_api.g_varchar2_table(432) := '81818181818101010181818848484e7e7e7ffffffffffffffffffffffff94949418181810101008080808080808080810101';
    wwv_flow_api.g_varchar2_table(433) := '00808080808080000000808'||wwv_flow.LF||
'080000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(434) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(435) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000008080';
    wwv_flow_api.g_varchar2_table(436) := '8000000080808000000101010080808080808080808292929c6c6c6ffffffffffffffffffffffff9c9c9c2929291818187b7';
    wwv_flow_api.g_varchar2_table(437) := 'b7bf7f7f73131'||wwv_flow.LF||
'31212121181818080808181818212121181818181818212121ffffffefefef18181818181821212121212';
    wwv_flow_api.g_varchar2_table(438) := '1181818212121212121181818181818212121181818'||wwv_flow.LF||
'e7e7e7e7e7e7212121a5a5a5ffffffffffff6363632121211010101';
    wwv_flow_api.g_varchar2_table(439) := '81818181818181818080808212121181818181818737373efefefffffffffffffffffffef'||wwv_flow.LF||
'efef525252101010080808080';
    wwv_flow_api.g_varchar2_table(440) := '8080808080808080000000808080000000808080000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(441) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(442) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000008080800000008080';
    wwv_flow_api.g_varchar2_table(443) := '80808080808080808080808080808081010100808086b6b6bf7f7f7ffffffff'||wwv_flow.LF||
'ffffffffffbdbdbd4242421818188484844';
    wwv_flow_api.g_varchar2_table(444) := '24242848484ffffffa5a5a5181818212121101010212121212121212121101010212121d6d6d6ffffff3939395a5a'||wwv_flow.LF||
'5a636';
    wwv_flow_api.g_varchar2_table(445) := '363212121101010212121212121212121101010292929393939ffffffb5b5b54a4a4affffffffffffffffff3131311818181';
    wwv_flow_api.g_varchar2_table(446) := '81818181818212121181818'||wwv_flow.LF||
'181818101010181818181818181818212121949494ffffffffffffffffffffffff9c9c9c101';
    wwv_flow_api.g_varchar2_table(447) := '01010101010101008080808080808080808080800000008080800'||wwv_flow.LF||
'000000000000000008080800000000000000000000000';
    wwv_flow_api.g_varchar2_table(448) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(449) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000008080808080800000';
    wwv_flow_api.g_varchar2_table(450) := '0000000080808'||wwv_flow.LF||
'080808080808080808101010101010a5a5a5ffffffffffffffffffefefef636363212121181818848484f';
    wwv_flow_api.g_varchar2_table(451) := 'fffffdedede212121e7e7e7ffffff39393918181810'||wwv_flow.LF||
'1010212121212121212121101010212121b5b5b5fffffffffffffff';
    wwv_flow_api.g_varchar2_table(452) := 'fffefefef212121181818212121212121212121181818212121737373ffffff7b7b7bb5b5'||wwv_flow.LF||
'b5f7f7f7f7f7f7e7e7e718181';
    wwv_flow_api.g_varchar2_table(453) := '82121211010101818181818182121211010102121216b6b6bf7f7f7ffffffbdbdbd313131393939c6c6c6fffffffffffffff';
    wwv_flow_api.g_varchar2_table(454) := 'fff'||wwv_flow.LF||
'd6d6d631313108080810101000000008080800000008080800000008080800000008080800000000000000000000000';
    wwv_flow_api.g_varchar2_table(455) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(456) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000080808080808080';
    wwv_flow_api.g_varchar2_table(457) := '808000000101010080808101010000000101010292929d6d6d6ffffffffffffffffffbdbdbd212121393939efefef'||wwv_flow.LF||
'94949';
    wwv_flow_api.g_varchar2_table(458) := '4393939ffffffffffffa5a5a56b6b6bffffffadadad212121101010292929212121212121101010212121949494ffffffd6d';
    wwv_flow_api.g_varchar2_table(459) := '6d69c9c9c73737329292910'||wwv_flow.LF||
'10102929292121212121211818182929299c9c9cffffff7b7b7bffffffadadadffffffadada';
    wwv_flow_api.g_varchar2_table(460) := 'd292929212121181818181818292929212121101010424242ffff'||wwv_flow.LF||
'ffffffffdededeffffffe7e7e7181818101010848484f';
    wwv_flow_api.g_varchar2_table(461) := 'ffffffffffffffffff7f7f75a5a5a101010080808080808101010080808080808080808080808080808'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(462) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(463) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000080';
    wwv_flow_api.g_varchar2_table(464) := '8080808080808080808081010100808080808083939'||wwv_flow.LF||
'39f7f7f7ffffffffffffffffff7b7b7b181818101010181818deded';
    wwv_flow_api.g_varchar2_table(465) := 'ef7f7f7212121dededeffffffffffff6b6b6be7e7e7ffffff424242101010212121212121'||wwv_flow.LF||
'2121211818182121216b6b6bf';
    wwv_flow_api.g_varchar2_table(466) := 'fffffadadad212121292929292929181818212121292929212121181818212121d6d6d6f7f7f7cececeefefef7b7b7bfffff';
    wwv_flow_api.g_varchar2_table(467) := 'f84'||wwv_flow.LF||
'8484212121212121181818212121212121212121101010cececeffffff7b7b7b080808bdbdbdffffff4242421010101';
    wwv_flow_api.g_varchar2_table(468) := '81818424242e7e7e7ffffffffffffffff'||wwv_flow.LF||
'ff737373000000101010080808080808080808080808000000080808000000080';
    wwv_flow_api.g_varchar2_table(469) := '808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(470) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000008080800'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(471) := '808080000001010100808080808080808081010104a4a4af7f7f7ffffffffffffefefef4a4a4a18181818181808080821212';
    wwv_flow_api.g_varchar2_table(472) := '1636363ffffff9c9c9c9494'||wwv_flow.LF||
'94ffffffc6c6c6f7f7f78c8c8cffffffbdbdbd1010102929292929292929291818182929294';
    wwv_flow_api.g_varchar2_table(473) := 'a4a4affffffd6d6d6292929292929313131181818313131292929'||wwv_flow.LF||
'292929181818313131ffffffffffffffffff8c8c8ca5a';
    wwv_flow_api.g_varchar2_table(474) := '5a5ffffff4a4a4a2929292121212121212121212929292121216b6b6bffffffdedede212121181818e7'||wwv_flow.LF||
'e7e7ffffff29292';
    wwv_flow_api.g_varchar2_table(475) := '9101010181818181818212121cececeffffffffffffffffff8c8c8c080808101010080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(476) := '8080000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(477) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(478) := '000000808080808080808080808080808081010104a4a4affffffffffffffffffd6d6d629'||wwv_flow.LF||
'2929181818181818101010101';
    wwv_flow_api.g_varchar2_table(479) := '010181818212121cececeffffff5a5a5affffff8c8c8cdededecececedededeffffff4242422121212929292121211010102';
    wwv_flow_api.g_varchar2_table(480) := '929'||wwv_flow.LF||
'29313131f7f7f7f7f7f74242426363638484844242422929293131312929291818185a5a5affffffffffffefefef313';
    wwv_flow_api.g_varchar2_table(481) := '131d6d6d6efefef212121292929292929'||wwv_flow.LF||
'181818212121212121292929e7e7e7ffffff5a5a5a212121848484ffffffa5a5a';
    wwv_flow_api.g_varchar2_table(482) := '5212121080808181818181818181818080808a5a5a5ffffffffffffffffff94'||wwv_flow.LF||
'94941010101010100000000808080808080';
    wwv_flow_api.g_varchar2_table(483) := '808080000000808080000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(484) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000808080000000';
    wwv_flow_api.g_varchar2_table(485) := '80808000000080808101010'||wwv_flow.LF||
'0808080000001010104a4a4affffffffffffffffffc6c6c6292929080808181818181818212';
    wwv_flow_api.g_varchar2_table(486) := '121080808212121181818636363ffffffadadade7e7e7cecece39'||wwv_flow.LF||
'3939ffffffd6d6d6ffffffc6c6c629292929292931313';
    wwv_flow_api.g_varchar2_table(487) := '1181818313131292929dededeffffffffffffffffffffffff8484843131313131312929292121219494'||wwv_flow.LF||
'94ffffffffffff7';
    wwv_flow_api.g_varchar2_table(488) := '37373393939ffffffc6c6c6212121313131292929212121212121292929949494ffffffbdbdbd212121393939fffffff7f7f';
    wwv_flow_api.g_varchar2_table(489) := '7393939212121'||wwv_flow.LF||
'1010101818181818181818181010101818188c8c8cffffffffffffffffff9494940808080808080808081';
    wwv_flow_api.g_varchar2_table(490) := '0101008080808080808080808080800000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(491) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(492) := '0080808000000080808080808080808080808080808393939f7f7f7ffffffffffffbdbdbd212121101010101010181818181';
    wwv_flow_api.g_varchar2_table(493) := '818'||wwv_flow.LF||
'181818101010181818212121212121cececef7f7f7b5b5b5ffffff3131317b7b7bffffffffffffffffff5a5a5a31313';
    wwv_flow_api.g_varchar2_table(494) := '1292929181818292929313131adadadde'||wwv_flow.LF||
'dedeb5b5b59494947373733939393131313131312929292121215a5a5aa5a5a5b';
    wwv_flow_api.g_varchar2_table(495) := '5b5b52929295a5a5affffff8484842929292929292929291818182929293939'||wwv_flow.LF||
'39ffffffffffff4a4a4a292929a5a5a5fff';
    wwv_flow_api.g_varchar2_table(496) := 'fff8c8c8c212121212121101010212121181818181818101010181818101010848484ffffffffffffffffff848484'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(497) := '8080808080808080808000000080808000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(498) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000008080800000';
    wwv_flow_api.g_varchar2_table(499) := '0080808080808080808080808080808080808101010292929efef'||wwv_flow.LF||
'efffffffffffffc6c6c62121211818181818181010102';
    wwv_flow_api.g_varchar2_table(500) := '121211818182121211010102121212121212929294a4a4affffffdededeffffff737373292929bdbdbd'||wwv_flow.LF||
'ffffffffffffd6d';
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(501) := '6d62929293131311818183131313131313939392121215a5a5a7373738c8c8c8c8c8c9c9c9c9c9c9c9c9c9c8484847b7b7b5';
    wwv_flow_api.g_varchar2_table(502) := 'a5a5a39393921'||wwv_flow.LF||
'21214a4a4a8c8c8c4a4a4a292929313131292929212121212121b5b5b5ffffff9c9c9c2929294a4a4afff';
    wwv_flow_api.g_varchar2_table(503) := 'fffe7e7e72929292121212121211818181818182121'||wwv_flow.LF||
'21181818101010181818181818101010848484fffffffffffffffff';
    wwv_flow_api.g_varchar2_table(504) := 'f6b6b6b101010101010080808080808080808080808000000080808000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(505) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(506) := '008'||wwv_flow.LF||
'0808000000080808080808080808080808101010101010d6d6d6ffffffffffffcecece1818181010101818181818181';
    wwv_flow_api.g_varchar2_table(507) := '010101818182121212121211010102121'||wwv_flow.LF||
'21292929212121101010bdbdbdffffffffffffcecece292929393939e7e7e7fff';
    wwv_flow_api.g_varchar2_table(508) := 'fffefefef4a4a4a292929292929737373adadaddededeffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(509) := 'fffffffffffffffffffe7e7e7bdbdbd8c8c8c393939292929313131313131212121525252fffffff7f7f721212129'||wwv_flow.LF||
'2929c';
    wwv_flow_api.g_varchar2_table(510) := '6c6c6ffffff5a5a5a292929212121212121101010212121212121212121080808181818181818181818080808949494fffff';
    wwv_flow_api.g_varchar2_table(511) := 'ffffffff7f7f74a4a4a0808'||wwv_flow.LF||
'081010100000001010100808080808080000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(512) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000080';
    wwv_flow_api.g_varchar2_table(513) := '808080808080808080808080808080808080808080808101010adadadffffffffffffefefef31313108'||wwv_flow.LF||
'080818181818181';
    wwv_flow_api.g_varchar2_table(514) := '8212121101010212121212121212121101010292929212121292929181818525252ffffffffffffffffff424242313131636';
    wwv_flow_api.g_varchar2_table(515) := '3638484844242'||wwv_flow.LF||
'426b6b6bbdbdbdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(516) := 'fffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffd6d6d68c8c8c4242422929299c9c9cffffff8484841818186';
    wwv_flow_api.g_varchar2_table(517) := 'b6b6bffffffcecece10101029292929292921212118181821212121212121212110101018'||wwv_flow.LF||
'1818212121181818101010181';
    wwv_flow_api.g_varchar2_table(518) := '818b5b5b5ffffffffffffe7e7e72929291010100808080808080808080808080808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(519) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(520) := '000000000000000080808000000080808'||wwv_flow.LF||
'080808080808080808737373fffffffffffff7f7f74a4a4a10101010101018181';
    wwv_flow_api.g_varchar2_table(521) := '821212118181810101021212121212121212118181821212129292929292918'||wwv_flow.LF||
'1818292929bdbdbdffffffffffff8484843';
    wwv_flow_api.g_varchar2_table(522) := '13131393939848484e7e7e7ffffffffffffffffffffffffffffffffffffe7e7e7bdbdbda5a5a58c8c8c7373737373'||wwv_flow.LF||
'73737';
    wwv_flow_api.g_varchar2_table(523) := '3737373737b7b7b949494b5b5b5d6d6d6ffffffffffffffffffffffffffffffffffffffffff9c9c9c4a4a4a6b6b6b3939392';
    wwv_flow_api.g_varchar2_table(524) := '12121e7e7e7ffffff525252'||wwv_flow.LF||
'181818292929212121292929101010292929212121212121101010212121181818212121080';
    wwv_flow_api.g_varchar2_table(525) := '808181818212121d6d6d6ffffffffffffbdbdbd10101000000010'||wwv_flow.LF||
'101008080808080800000008080800000000000000000';
    wwv_flow_api.g_varchar2_table(526) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(527) := '00000000000000000080808080808080808080808080808080808313131f7f7f7ffffffffffff73737318181818181808080';
    wwv_flow_api.g_varchar2_table(528) := '8181818212121'||wwv_flow.LF||
'2121211010102121212121212929291010102929292929292929291818183131314a4a4affffff9494944';
    wwv_flow_api.g_varchar2_table(529) := '24242848484efefefffffffffffffffffffffffffef'||wwv_flow.LF||
'efefb5b5b57b7b7b4a4a4a212121393939393939393939212121393';
    wwv_flow_api.g_varchar2_table(530) := '9393939393939392929293939393939393131313131316b6b6b9c9c9ce7e7e7ffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffadada';
    wwv_flow_api.g_varchar2_table(531) := 'd393939525252ffffffb5b5b5292929181818292929292929292929181818212121292929212121181818212121212121181';
    wwv_flow_api.g_varchar2_table(532) := '818'||wwv_flow.LF||
'101010181818181818292929ffffffffffffffffff73737308080808080808080808080808080808080808080800000';
    wwv_flow_api.g_varchar2_table(533) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(534) := '00000000000000000080808000000080808000000101010101010101010c6c6'||wwv_flow.LF||
'c6ffffffffffffadadad181818181818181';
    wwv_flow_api.g_varchar2_table(535) := '818101010181818212121181818101010212121292929212121181818292929292929292929181818292929313131'||wwv_flow.LF||
'31313';
    wwv_flow_api.g_varchar2_table(536) := '1424242d6d6d6ffffffffffffffffffffffffd6d6d67b7b7b292929393939424242393939212121393939424242393939292';
    wwv_flow_api.g_varchar2_table(537) := '12142393942393931313129'||wwv_flow.LF||
'29293939394242423131313129293939394242422929295a5a5aadadadfffffffffffffffff';
    wwv_flow_api.g_varchar2_table(538) := 'ffffffff7f7f76b6b6b3939394242423131311010103131312929'||wwv_flow.LF||
'292929291010102929292121212929291010102121212';
    wwv_flow_api.g_varchar2_table(539) := '121211818180808081818181010101818185a5a5affffffffffffffffff292929101010080808101010'||wwv_flow.LF||
'000000080808000';
    wwv_flow_api.g_varchar2_table(540) := '0000808080000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(541) := '0000000000000'||wwv_flow.LF||
'0000080808080808080808080808101010080808101010737373ffffffffffffefefef181818181818181';
    wwv_flow_api.g_varchar2_table(542) := '8182121211010102121212121212121211010102929'||wwv_flow.LF||
'2929292929292910101031313129292931313118181831313131313';
    wwv_flow_api.g_varchar2_table(543) := '1949494ffffffffffffffffffffffffc6c6c66b6b6b393939393939212121424242424242'||wwv_flow.LF||
'4242422121214a42424242424';
    wwv_flow_api.g_varchar2_table(544) := '242422929294a42424239394239392929294242424242423939392929294242423939393131312929294242424a4a4aa5a5a';
    wwv_flow_api.g_varchar2_table(545) := '5ff'||wwv_flow.LF||
'ffffffffffffffffffffffbdbdbd4242423131312121213131313131312929291818182929292929292121211818182';
    wwv_flow_api.g_varchar2_table(546) := '121212929291818181010101818182121'||wwv_flow.LF||
'21181818101010adadadffffffffffffc6c6c6101010101010080808080808000';
    wwv_flow_api.g_varchar2_table(547) := '000080808000000080808000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(548) := '0000000000000000000000000000000000000080808101010080808101010212121f7f7f7ffffffffffff5a5a5a10'||wwv_flow.LF||
'10101';
    wwv_flow_api.g_varchar2_table(549) := '0101021212118181818181818181821212121212118181821212129292929292918181829292929292929292921212131313';
    wwv_flow_api.g_varchar2_table(550) := '1bdbdbdffffffffffffffff'||wwv_flow.LF||
'ffefefef7373732121213939394242423939392121214239394242424242422929294239394';
    wwv_flow_api.g_varchar2_table(551) := '24242393939292929424242424242393939313131423939424242'||wwv_flow.LF||
'393131313131393939424242292929393939393939393';
    wwv_flow_api.g_varchar2_table(552) := '9392929294a4a4ac6c6c6ffffffffffffffffffe7e7e75a5a5a10101031313129292929292918181829'||wwv_flow.LF||
'292929292929292';
    wwv_flow_api.g_varchar2_table(553) := '9101010212121181818292929101010181818181818212121080808212121e7e7e7ffffffffffff6b6b6b080808080808080';
    wwv_flow_api.g_varchar2_table(554) := '8080808080000'||wwv_flow.LF||
'0008080800000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(555) := '0000000000000000000080808000000080808080808'||wwv_flow.LF||
'080808080808080808080808a5a5a5ffffffffffffb5b5b51818181';
    wwv_flow_api.g_varchar2_table(556) := '0101018181818181821212110101021212121212129292910101029292929292931313118'||wwv_flow.LF||
'1818313131313131393939313';
    wwv_flow_api.g_varchar2_table(557) := '131dededeffffffffffffffffffb5b5b54242424242422121214242423939394a4a4a2121214a42424239394a42422929294';
    wwv_flow_api.g_varchar2_table(558) := 'a42'||wwv_flow.LF||
'424a42424a42422929294a4a4a4a42424242422929294a4a4a424242393939313131424242393939393939313131424';
    wwv_flow_api.g_varchar2_table(559) := '2424242422929293131313939397b7b7b'||wwv_flow.LF||
'fffffffffffffffffff7f7f763636331313131313129292921212129292929292';
    wwv_flow_api.g_varchar2_table(560) := '929292918181821212129292921212118181818181821212118181810101018'||wwv_flow.LF||
'18186b6b6bffffffffffffe7e7e71818181';
    wwv_flow_api.g_varchar2_table(561) := '010100808080808080808080000000808080000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(562) := '000000000000000000000000000000000080808080808080808080808080808080808393939ffffffffffffffffff3131311';
    wwv_flow_api.g_varchar2_table(563) := '01010101010101010212121'||wwv_flow.LF||
'1818181010102121212121212121211010102929292929292929291818183129293131314a4';
    wwv_flow_api.g_varchar2_table(564) := 'a4ae7e7e7fffffffffffffff7f76b6b6b39393942393939393921'||wwv_flow.LF||
'21214242424242424242422921214242424a424a42424';
    wwv_flow_api.g_varchar2_table(565) := '22921294a424a4a4a4a4242422929294a42424a4a4a4239423129314a42424a4a4a3931393131314242'||wwv_flow.LF||
'424a42423131313';
    wwv_flow_api.g_varchar2_table(566) := '13131424242424242292929393939393939424242424242dededeffffffffffffffffff7b7b7b31313131313118181829292';
    wwv_flow_api.g_varchar2_table(567) := '9292929292929'||wwv_flow.LF||
'101010292929212121292929101010212121181818212121080808181818101010cececeffffffffffff8';
    wwv_flow_api.g_varchar2_table(568) := '4848410101000000008080808080808080800000008'||wwv_flow.LF||
'0808000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(569) := '0000000000000000000000000000000000808080000000808080808081010100808081010'||wwv_flow.LF||
'10adadadffffffffffff94949';
    wwv_flow_api.g_varchar2_table(570) := '41818181818181010101818181818182121211010102121212929292929291010103131312929292929291818183939394a4';
    wwv_flow_api.g_varchar2_table(571) := '242'||wwv_flow.LF||
'efe7e7ffffffffffffefefef635a5a2121214242424239394242422121214a42424242424a42422121214a4a4a4a424';
    wwv_flow_api.g_varchar2_table(572) := 'a4a4a4a292129524a4a4a4a4a4a4a4a29'||wwv_flow.LF||
'29294a4a4a4a4a4a4a42423129314a4a4a4a4a4a4239423131314a4a4a4a42423';
    wwv_flow_api.g_varchar2_table(573) := '939393131314a4a4a424242313131393939424242423939292929424242cece'||wwv_flow.LF||
'ceffffffffffffffffff737373393939212';
    wwv_flow_api.g_varchar2_table(574) := '121292929313131292929181818212121292929212121181818212121212121212121101010181818212121424242'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(575) := 'fffffffefefef181818080808080808101010080808080808000000080808000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(576) := '00000000000000000000000'||wwv_flow.LF||
'0000000000000000000000080808000000080808080808101010292929fffffffffffff7f7f';
    wwv_flow_api.g_varchar2_table(577) := '72929291010101818181010101818181818182121211818182121'||wwv_flow.LF||
'212121212929291818182929293131312929291818183';
    wwv_flow_api.g_varchar2_table(578) := '93131e7dedeffffffffffffe7e7e75252524242422121213939394242424242422921214242424a4242'||wwv_flow.LF||
'4242422929294a4';
    wwv_flow_api.g_varchar2_table(579) := '2424a4a4a4a4a4a2929294a4a4a4a4a4a4a42423129314a4a4a4a4a4a4242423131314a424a4a4a4a3939393931394a42424';
    wwv_flow_api.g_varchar2_table(580) := 'a4a4a31313139'||wwv_flow.LF||
'39394242424a4242292929393939423939424242212121393939393939bdbdbdffffffffffffffffff5a5';
    wwv_flow_api.g_varchar2_table(581) := 'a5a1818183131312929292929291818182929292121'||wwv_flow.LF||
'2129292910101021212118181821212110101018181810101018181';
    wwv_flow_api.g_varchar2_table(582) := '8b5b5b5ffffffffffff848484000000101010080808080808000000080808000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(583) := '000000000000000000000000000000000000000000000000808080808080808080808081010100808089c9c9cfffffffffff';
    wwv_flow_api.g_varchar2_table(584) := 'f8c'||wwv_flow.LF||
'8c8c1010101818182121211010102121211818182929291010102929292929292929291818183131312929293131312';
    wwv_flow_api.g_varchar2_table(585) := '12121cec6c6fffffffffffff7efef5252'||wwv_flow.LF||
'524239394242422121214242424242424a4a4a2921214a4a4a4a42424a4a4a292';
    wwv_flow_api.g_varchar2_table(586) := '929524a4a4a4a4a524a52292929524a524a4a4a4a4a4a312929524a524a4a4a'||wwv_flow.LF||
'4a4a4a313131524a524a4a4a42424239313';
    wwv_flow_api.g_varchar2_table(587) := '9524a4a4a4a4a3939393939394a4a4a4a42423131313939394a4242423939292929393939424242424242c6c6c6ff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(588) := 'fffffefefef39393931313131313129292918181829292929292929292918181821212121212121212110101018181821212';
    wwv_flow_api.g_varchar2_table(589) := '1101010424242ffffffffff'||wwv_flow.LF||
'ffe7e7e71010100808081010100808080808080808080808080000000000000000000000000';
    wwv_flow_api.g_varchar2_table(590) := '00000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'000000080808000000080808080808181818f7f7f7fff';
    wwv_flow_api.g_varchar2_table(591) := 'fffffffff29292910101021212118181810101018181821212121212118181821212129292929292918'||wwv_flow.LF||
'181829292931313';
    wwv_flow_api.g_varchar2_table(592) := '13131318c8c8cffffffffffffffffff4242424239393939394239392929294242424a42424242422929294a42424a4a4a4a4';
    wwv_flow_api.g_varchar2_table(593) := '2422929294a4a'||wwv_flow.LF||
'4a524a4a4a4a4a2929294a4a4a524a524a424a3129314a4a4a524a524242423131314a4a4a524a5242393';
    wwv_flow_api.g_varchar2_table(594) := '93931394a4a4a524a4a3931313939394a4a4a4a4a4a'||wwv_flow.LF||
'3129294239394242424a4242292929393939393939393939292929d';
    wwv_flow_api.g_varchar2_table(595) := '6d6d6ffffffffffffcecece39393931313131313110101031313129292929292910101021'||wwv_flow.LF||
'2121212121212121080808212';
    wwv_flow_api.g_varchar2_table(596) := '121181818181818080808c6c6c6ffffffffffff5a5a5a1010100808080808080000000808080000000808080000000000000';
    wwv_flow_api.g_varchar2_table(597) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000080808000000080808080808080808101010101010737373fff';
    wwv_flow_api.g_varchar2_table(598) := 'fffffffffadadad101010181818181818'||wwv_flow.LF||
'21212110101021212121212129292910101029292921212131313118181831313';
    wwv_flow_api.g_varchar2_table(599) := '13131315a5a5affffffffffffffffff7b7b7b21181842424242424242424221'||wwv_flow.LF||
'21214a4a4a4242424a4a4a292121524a4a4';
    wwv_flow_api.g_varchar2_table(600) := 'a4a4a524a4a2929295252524a4a4a5252522929295252524a4a4a524a4a312929525252524a4a4a4a4a3131315252'||wwv_flow.LF||
'52524';
    wwv_flow_api.g_varchar2_table(601) := 'a4a4242423931395252524a4a4a423939393939524a4a4a4a4a3931313939394a4a4a4242422929293939394a4a4a4239392';
    wwv_flow_api.g_varchar2_table(602) := '121214a4a4aefefefffffff'||wwv_flow.LF||
'ffffff949494393939313131181818292929313131292929181818212121292929212121101';
    wwv_flow_api.g_varchar2_table(603) := '0101818182121211818180808085a5a5affffffffffffcecece10'||wwv_flow.LF||
'101010101008080808080808080808080800000000000';
    wwv_flow_api.g_varchar2_table(604) := '00000000000000000000000000000000000000000000000000000000000000808080808080808080808'||wwv_flow.LF||
'08080808080808d';
    wwv_flow_api.g_varchar2_table(605) := '6d6d6ffffffffffff4a4a4a10101010101018181818181818181818181821212121212118181821212129292929292918181';
    wwv_flow_api.g_varchar2_table(606) := '8292929313131'||wwv_flow.LF||
'd6d6d6ffffffffffffb5b5b53939392121213939394242424242422929294242424a4a4a4a42422929294';
    wwv_flow_api.g_varchar2_table(607) := 'a4a4a524a4a4a4a4a2929294a4a4a524a524a4a4a31'||wwv_flow.LF||
'29314a4a4a524a524a4a4a3131314a4a4a524a524242423931394a4';
    wwv_flow_api.g_varchar2_table(608) := 'a4a524a524239423939394a4a4a524a4a3939394239394a4a4a4a4a4a3131314242424242'||wwv_flow.LF||
'424a4a4a29292942424239393';
    wwv_flow_api.g_varchar2_table(609) := '94242421818184242426b6b6bffffffffffffffffff4a4a4a313131101010313131292929292929101010292929212121212';
    wwv_flow_api.g_varchar2_table(610) := '121'||wwv_flow.LF||
'101010212121181818181818101010181818e7e7e7ffffffffffff29292908080808080800000008080800000008080';
    wwv_flow_api.g_varchar2_table(611) := '800000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000808080808080808080808080808081010103';
    wwv_flow_api.g_varchar2_table(612) := '93939ffffffffffffdedede1818181010101818181818182121211010102121'||wwv_flow.LF||
'21212121292929181818292929292929313';
    wwv_flow_api.g_varchar2_table(613) := '131181818393939848484ffffffffffffefefef4242424242422121214242424242424a42422921214a4a4a4a4242'||wwv_flow.LF||
'4a4a4';
    wwv_flow_api.g_varchar2_table(614) := 'a292929524a4a4a4a4a525252292929525252524a4a525252312929525252524a4a524a52313131525252524a4a4a4a4a313';
    wwv_flow_api.g_varchar2_table(615) := '131525252524a524a424a39'||wwv_flow.LF||
'39395252524a4a4a4242423939395252524a4a4a3939394242424a4a4a4a4a4a29292942393';
    wwv_flow_api.g_varchar2_table(616) := '94a4242424242292929393939424242adadadffffffffffffcece'||wwv_flow.LF||
'ce3131312121212929293131312929291818182929292';
    wwv_flow_api.g_varchar2_table(617) := '92929212121181818212121212121181818101010181818949494ffffffffffff848484101010080808'||wwv_flow.LF||
'080808080808080';
    wwv_flow_api.g_varchar2_table(618) := '8080000000808080000000000000000000000000000000000000000000000000000000000000808080808080808080808081';
    wwv_flow_api.g_varchar2_table(619) := '010107b7b7bff'||wwv_flow.LF||
'ffffffffff8c8c8c181818101010101010212121181818181818181818292929212121181818212121313';
    wwv_flow_api.g_varchar2_table(620) := '131292929212121393939efefefffffffffffff7373'||wwv_flow.LF||
'733939393939392121213939394242424242422929294242424a4a4';
    wwv_flow_api.g_varchar2_table(621) := 'a4a4a4a2929294a4a4a4a4a4a4a4a4a2929294a4a4a5252524a4a4a2929294a4a4a525252'||wwv_flow.LF||
'4a4a4a3131314a4a4a5252524';
    wwv_flow_api.g_varchar2_table(622) := '242423131314a4a4a5252524242423939394a4a4a5252523939393939394a4a4a4a4a4a3131314242424a4a4a4a4a4a21212';
    wwv_flow_api.g_varchar2_table(623) := '142'||wwv_flow.LF||
'4242424242424242212121424242393939424242efefefffffffffffff6b6b6b1818183131312929293131311010102';
    wwv_flow_api.g_varchar2_table(624) := '929292121212929291010102121211818'||wwv_flow.LF||
'18181818101010181818393939ffffffffffffd6d6d6080808080808000000080';
    wwv_flow_api.g_varchar2_table(625) := '808000000080808000000080808000000000000000000000000000000000000'||wwv_flow.LF||
'08080800000008080808080808080808080';
    wwv_flow_api.g_varchar2_table(626) := '8101010080808cececeffffffffffff42424218181810101018181821212121212110101021212121212129292918'||wwv_flow.LF||
'18182';
    wwv_flow_api.g_varchar2_table(627) := '929293131313131311818188c8c8cffffffffffffbdbdbd3939393939394242422121214a4a4a4a4a4a42424229292952525';
    wwv_flow_api.g_varchar2_table(628) := '24a4a4a4a4a4a2929295252'||wwv_flow.LF||
'525252525252522929295252525252525252523131315252525252525252523131315252525';
    wwv_flow_api.g_varchar2_table(629) := '252524a4a4a3939395252525252524a4a4a393939525252525252'||wwv_flow.LF||
'3939393939395252524a4a4a3939394242425252524a4';
    wwv_flow_api.g_varchar2_table(630) := 'a4a2929294242424a4a4a424242292929424242424242393939848484ffffffffffffcecece21212129'||wwv_flow.LF||
'292931313129292';
    wwv_flow_api.g_varchar2_table(631) := '9181818292929292929212121101010212121212121212121080808181818181818dededeffffffffffff313131101010080';
    wwv_flow_api.g_varchar2_table(632) := '8080808080808'||wwv_flow.LF||
'0808080800000000000000000000000000000000000000000000000000000008080800000008080808080';
    wwv_flow_api.g_varchar2_table(633) := '8080808080808212121ffffffffffffe7e7e7181818'||wwv_flow.LF||
'1818181010101010102121212121211818181818182929292929291';
    wwv_flow_api.g_varchar2_table(634) := '81818292929292929313131212121efefefffffffffffff4a4a4a3939394242423939396b'||wwv_flow.LF||
'6b6ba5a5a5adadadadadada5a';
    wwv_flow_api.g_varchar2_table(635) := '5a5adadadadadadadadada5a5a5adadadb5b5b5adadada5a5a5adadadb5b5b5adadada5a5a5adadadb5b5b5adadada5a5a5a';
    wwv_flow_api.g_varchar2_table(636) := 'dad'||wwv_flow.LF||
'adb5b5b5adadada5a5a5adadadb5b5b5a5a5a5adadadadadadb5b5b5a5a5a5adadadadadadb5b5b5a5a5a5adadadada';
    wwv_flow_api.g_varchar2_table(637) := 'dadb5b5b5a5a5a5adadadadadadadadad'||wwv_flow.LF||
'9c9c9c7b7b7b393939393939212121efefefffffffffffff4a4a4a31313129292';
    wwv_flow_api.g_varchar2_table(638) := '931313110101029292921212129292910101021212118181818181810101018'||wwv_flow.LF||
'1818181818949494ffffffffffff6363631';
    wwv_flow_api.g_varchar2_table(639) := '010100000000808080808080808080000000000000000000000000000000000000000000000000808080000000808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(640) := '8081010100808080808085a5a5affffffffffffadadad1818182121211010101818182121212121211818182121212929292';
    wwv_flow_api.g_varchar2_table(641) := '92929181818292929313131'||wwv_flow.LF||
'3131316b6b6bffffffffffffd6d6d61818184242423939399c9c9cfffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(642) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(643) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(644) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff9c9c9c4242422121218c8c8cffffffffffffb5b5b531313';
    wwv_flow_api.g_varchar2_table(645) := '1313131292929'||wwv_flow.LF||
'1818182929292929292121211818182121212121211818181010101818181818185a5a5affffffffffffb';
    wwv_flow_api.g_varchar2_table(646) := '5b5b508080808080808080808080808080808080800'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(647) := '000080808080808080808080808949494ffffffffffff6b6b6b1818181818181818181818'||wwv_flow.LF||
'1821212121212118181821212';
    wwv_flow_api.g_varchar2_table(648) := '1292929292929181818292929313131292929c6c6c6ffffffffffff737373212121393939424242e7e7e7fffffffffffffff';
    wwv_flow_api.g_varchar2_table(649) := 'fff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(650) := 'fffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(651) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe7e7'||wwv_flow.LF||
'e7393939212121424242f7f7f7fffffff7f';
    wwv_flow_api.g_varchar2_table(652) := '7f7424242313131313131101010292929292929292929101010212121212121212121080808181818181818212121'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(653) := 'fffffffe7e7e7101010000000080808080808080808000000000000000000000000000000000000000000000000080808000';
    wwv_flow_api.g_varchar2_table(654) := '00008080808080810101008'||wwv_flow.LF||
'0808080808c6c6c6ffffffffffff39393918181818181810101018181821212121212118181';
    wwv_flow_api.g_varchar2_table(655) := '8212121292929292929181818313131313131424242ffffffffff'||wwv_flow.LF||
'fff7f7f7424242181818424242424242dededefffffff';
    wwv_flow_api.g_varchar2_table(656) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(657) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(658) := 'fffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffdedede393939292929393939bdbdbdfff';
    wwv_flow_api.g_varchar2_table(659) := 'fffffffff7b7b7b3131313131311818182929292929'||wwv_flow.LF||
'2929292918181821212129292918181818181818181821212118181';
    wwv_flow_api.g_varchar2_table(660) := '8d6d6d6ffffffffffff212121080808080808080808080808080808000000080808000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(661) := '00000080808000000080808080808080808080808f7f7f7fffffff7f7f710101018181818181818181818181821212121212';
    wwv_flow_api.g_varchar2_table(662) := '118'||wwv_flow.LF||
'1818212121292929292929181818292929313131737373ffffffffffffb5b5b5393939212121393939424242737373f';
    wwv_flow_api.g_varchar2_table(663) := '7f7f7ffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(664) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(665) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff6b6b6b42424221212139'||wwv_flow.LF||
'39396';
    wwv_flow_api.g_varchar2_table(666) := 'b6b6bffffffffffffbdbdbd31313131313118181829292929292929292910101029292921212121212108080818181818181';
    wwv_flow_api.g_varchar2_table(667) := '81818189c9c9cffffffffff'||wwv_flow.LF||
'ff5252520000001010100808080808080000000808080000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(668) := '00000080808000000080808080808101010080808292929ffffff'||wwv_flow.LF||
'ffffffc6c6c6181818181818212121101010181818212';
    wwv_flow_api.g_varchar2_table(669) := '121292929181818212121292929313131181818313131313131b5b5b5ffffffffffff7b7b7b39393921'||wwv_flow.LF||
'212142424242424';
    wwv_flow_api.g_varchar2_table(670) := '24242423131316b6b6b737373fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(671) := 'fffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(672) := 'ff7f7f7ffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffefefef6b6b6b5252524a4a4a4242424242422929293';
    wwv_flow_api.g_varchar2_table(673) := '93939424242ffffffffffffefefef31313131313118181829292929292929292918181821'||wwv_flow.LF||
'2121212121212121101010212';
    wwv_flow_api.g_varchar2_table(674) := '1211818181818187b7b7bffffffffffff7b7b7b0808080808080808080808080808080808080000000000000000000000000';
    wwv_flow_api.g_varchar2_table(675) := '000'||wwv_flow.LF||
'00000000000000080808000000080808080808101010424242ffffffffffffa5a5a5101010181818181818181818181';
    wwv_flow_api.g_varchar2_table(676) := '818292929212121181818212121292929'||wwv_flow.LF||
'292929181818292929313131dededeffffffffffff52525239393921212142424';
    wwv_flow_api.g_varchar2_table(677) := '24242424242422921214a4a4a524a52a59c9cadadadbdbdbdc6c6c6bdbdbdbd'||wwv_flow.LF||
'b5bdbdbdbdc6c6c6bdbdbdadadadb5b5b5b';
    wwv_flow_api.g_varchar2_table(678) := '5b5b5adadad9c9c9ca5a5a5a5a5a5949494847b7b8c8c8c948c8c7b7b7b6b6b6b7373737373735a5a5a4a4a4a5a5a'||wwv_flow.LF||
'5a5a5';
    wwv_flow_api.g_varchar2_table(679) := 'a5a3939394242427b7b7bffffffffffffffffffffffffffffffffffffffffffcecece4a4a4a2921294a42424242424242422';
    wwv_flow_api.g_varchar2_table(680) := '12121393939393939cecece'||wwv_flow.LF||
'ffffffffffff4a4a4a313131101010313131292929292929101010212121212121212121080';
    wwv_flow_api.g_varchar2_table(681) := '8082121211818181818184a4a4affffffffffffa5a5a500000010'||wwv_flow.LF||
'101008080808080800000008080800000000000000000';
    wwv_flow_api.g_varchar2_table(682) := '00000000000000000000808080000000808080808081010100808086b6b6bffffffffffff7b7b7b1010'||wwv_flow.LF||
'101818182121211';
    wwv_flow_api.g_varchar2_table(683) := '81818212121212121212121181818292929292929313131181818313131393939ffffffffffffefefef39393942424221212';
    wwv_flow_api.g_varchar2_table(684) := '14a4a4a424242'||wwv_flow.LF||
'4a4a4a292121524a524a4a4a525252292929525252524a525252522921295a52525252525252523131315';
    wwv_flow_api.g_varchar2_table(685) := 'a5a5a5252525a5a5a3129295a5a5a5a5a5a5a5a5a31'||wwv_flow.LF||
'3131635a5a5a5a5a5252523939395a5a5a5a5252524a4a3939395a5';
    wwv_flow_api.g_varchar2_table(686) := '2525252524242424242429c9c9cffffffffffffffffffffffffffffffffffffffffffbdb5'||wwv_flow.LF||
'bd4a4a4a2921294a424a4a4a4';
    wwv_flow_api.g_varchar2_table(687) := 'a424242292929393939424242a5a5a5ffffffffffff7b7b7b313131181818292929313131292929181818212121212121212';
    wwv_flow_api.g_varchar2_table(688) := '121'||wwv_flow.LF||
'101010181818212121181818313131ffffffffffffb5b5b508080808080810101008080808080808080808080800000';
    wwv_flow_api.g_varchar2_table(689) := '000000000000000000000000000000008'||wwv_flow.LF||
'08080000000808080808081010107b7b7bffffffffffff6b6b6b1010101818186';
    wwv_flow_api.g_varchar2_table(690) := 'b6b6b949494181818212121cecece1818182121215a5a5aadadad2121212929'||wwv_flow.LF||
'29525252ffffffffffffbdbdbd393939393';
    wwv_flow_api.g_varchar2_table(691) := '9392921214242424242424242422929294a4a4a4a4a4a5a5a5a636363847b84948c949494948c8c8ca59c9cadadad'||wwv_flow.LF||
'adada';
    wwv_flow_api.g_varchar2_table(692) := 'dadadad7373735a5a5a5a52523131315252525a5a5a5a52523939395a5a5a5a5a5a524a4a3939395a5a5a5a5a5a4a4242424';
    wwv_flow_api.g_varchar2_table(693) := '2425252525a52523939396b'||wwv_flow.LF||
'6b6bf7f7f7ffffffffffffffffffffffffffffffffffffffffff8c8c8c4a4a4a2921214a4a4';
    wwv_flow_api.g_varchar2_table(694) := 'a424242424242212121424242393939847b7bffffffffffff9c9c'||wwv_flow.LF||
'9c3131311818182929299494947b7b7b101010313131b';
    wwv_flow_api.g_varchar2_table(695) := 'dbdbd212121080808737373848484181818101010ffffffffffffd6d6d6080808101010080808080808'||wwv_flow.LF||
'000000080808000';
    wwv_flow_api.g_varchar2_table(696) := '000000000000000000000000000000000080808000000080808080808101010080808949494ffffffffffff5252521010101';
    wwv_flow_api.g_varchar2_table(697) := '81818292929c6'||wwv_flow.LF||
'c6c6848484212121cecece101010424242d6d6d65a5a5a1818183131316b6b6bffffffffffffada5a5423';
    wwv_flow_api.g_varchar2_table(698) := '9394242422121214242424242424a4a4a292121524a'||wwv_flow.LF||
'4a4a4a4a8c8c8cfffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(699) := 'fffffffffffffffffffb5b5b56b6b6b3131315a5a5a5a5a5a525252393131635a5a5a5a5a'||wwv_flow.LF||
'5a5252393939635a5a5a5a5a4';
    wwv_flow_api.g_varchar2_table(700) := 'a4a4a4242425a5a5a737373c6c6c6ffffffffffffffffffffffffffffffffffffffffffffffffffffff635a634a4a4a29292';
    wwv_flow_api.g_varchar2_table(701) := '94a'||wwv_flow.LF||
'4a4a4a4a4a424242292929423939424242636363ffffffffffffb5b5b5313131212121292929424242dedede5a5a5a3';
    wwv_flow_api.g_varchar2_table(702) := '13131bdbdbd2121214a4a4acecece3939'||wwv_flow.LF||
'39181818101010f7f7f7ffffffefefef080808080808101010080808080808080';
    wwv_flow_api.g_varchar2_table(703) := '808080808000000000000000000000000000000000000080808000000080808'||wwv_flow.LF||
'080808101010a5a5a5ffffffffffff42424';
    wwv_flow_api.g_varchar2_table(704) := '2101010212121181818212121b5b5b5636363a5a5a5292929b5b5b54a4a4a292929212121292929848484ffffffff'||wwv_flow.LF||
'ffff9';
    wwv_flow_api.g_varchar2_table(705) := '494944239393939392121214242424242424242422929294a4a4a524a52525252fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(706) := 'fffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffd6d6d6adadad8484846363633939395a5a5a636363524a4a393939635a5a7';
    wwv_flow_api.g_varchar2_table(707) := '36b6b847b7ba5a5a5e7e7e7ffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffdedede4a4a4a524';
    wwv_flow_api.g_varchar2_table(708) := 'a4a2121214a4a4a424242424242212121424242393939525252ffffffffffffcecece31313110101031'||wwv_flow.LF||
'313129292942424';
    wwv_flow_api.g_varchar2_table(709) := '2c6c6c64a4a4aa5a5a5424242b5b5b5292929181818181818080808efefefffffffffffff000000080808080808080808000';
    wwv_flow_api.g_varchar2_table(710) := '0000808080000'||wwv_flow.LF||
'00000000000000000000000000000000080808000000080808080808101010080808b5b5b5fffffffffff';
    wwv_flow_api.g_varchar2_table(711) := 'f393939181818101010212121101010212121b5b5b5'||wwv_flow.LF||
'bdbdbd9c9c9c393939292929292929181818313131949494fffffff';
    wwv_flow_api.g_varchar2_table(712) := 'fffff8c84843939394242422121214a4a4a4242424a4a4a2929294a4a4a4a4a4a525252bd'||wwv_flow.LF||
'bdbdfffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(713) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f7f7f7f7efefefefefefefefeff';
    wwv_flow_api.g_varchar2_table(714) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff949494524';
    wwv_flow_api.g_varchar2_table(715) := 'a52524a4a2929294a4a4a4a4a4a424242'||wwv_flow.LF||
'292929424242424242424242ffffffffffffdedede31313121212129292931313';
    wwv_flow_api.g_varchar2_table(716) := '1292929292929bdbdbdbdbdbd949494181818181818212121181818080808de'||wwv_flow.LF||
'dedeffffffffffff1010100808081010100';
    wwv_flow_api.g_varchar2_table(717) := '80808080808080808080808000000000000000000000000000000000000080808000000080808080808101010adad'||wwv_flow.LF||
'adfff';
    wwv_flow_api.g_varchar2_table(718) := 'fffffffff393939101010212121181818181818181818313131efefef5a5a5a212121292929292929212121292929949494f';
    wwv_flow_api.g_varchar2_table(719) := 'fffffffffff7b7b7b393939'||wwv_flow.LF||
'3939392921214242424242424242422929294a4a4a4a4a4a4a4a52525252fffffffffffffff';
    wwv_flow_api.g_varchar2_table(720) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffff7f7f7d6d6d6b5adadadadadc6bdbde7e7e';
    wwv_flow_api.g_varchar2_table(721) := '7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffff7eff75';
    wwv_flow_api.g_varchar2_table(722) := '24a524a4a4a4a4a4a2929294a4a4a424242424242212121424242393939424242ffffffffffffdedede31313118181829292';
    wwv_flow_api.g_varchar2_table(723) := '9292929292929'||wwv_flow.LF||
'101010525252efefef4a4a4a101010181818181818181818080808d6d6d6ffffffffffff1010101010100';
    wwv_flow_api.g_varchar2_table(724) := '8080808080800000008080800000000000000000000'||wwv_flow.LF||
'0000000000000000080808000000080808080808101010080808b5b';
    wwv_flow_api.g_varchar2_table(725) := '5b5ffffffffffff393939101010181818212121212121b5b5b5b5b5b57b7b7bcecece8484'||wwv_flow.LF||
'8429292929292918181831313';
    wwv_flow_api.g_varchar2_table(726) := '1949494ffffffffffff7b7b7b4239394242422121214242424242424a4a4a2929294a4a524a4a4a525252292929cececefff';
    wwv_flow_api.g_varchar2_table(727) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffefefefd6d6d6b5b5b5a59c9c6363636b6b6b5a5a5a5a5a5a393939636363635a5';
    wwv_flow_api.g_varchar2_table(728) := 'a5a5252737373f7f7f7ffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8';
    wwv_flow_api.g_varchar2_table(729) := '47b844a4a4a524a4a4a4a4a2929294a4a4a4a4a4a4242422929294239394242'||wwv_flow.LF||
'42423939ffffffffffffdedede313131181';
    wwv_flow_api.g_varchar2_table(730) := '818313131292929424242bdbdbd9c9c9c7b7b7bdedede5a5a5a181818181818181818101010d6d6d6ffffffffffff'||wwv_flow.LF||
'18181';
    wwv_flow_api.g_varchar2_table(731) := '8080808101010080808080808080808080808000000000000000000000000000000000000080808000000080808080808101';
    wwv_flow_api.g_varchar2_table(732) := '010adadadffffffffffff39'||wwv_flow.LF||
'3939101010181818181818848484e7e7e7949494d6d6d65a5a5ae7e7e78c8c8c29292918181';
    wwv_flow_api.g_varchar2_table(733) := '83131318c8c8cffffffffffff8484844242423939392121214242'||wwv_flow.LF||
'424242424242422929294a4a4a4a4a524a4a4a2929296';
    wwv_flow_api.g_varchar2_table(734) := '36363ffffffffffffffffffffffffffffffc6c6c69c9c9cb5b5b5cec6c6cec6c6cececed6d6d6e7e7e7'||wwv_flow.LF||
'dededed6d6d6b5b';
    wwv_flow_api.g_varchar2_table(735) := '5b55a5a5a524a4a4242426b6b6bc6c6c6fff7f7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe';
    wwv_flow_api.g_varchar2_table(736) := '7dee73129314a'||wwv_flow.LF||
'4a4a4a4a4a4a4a4a2921214a4a4a4242424a42422121214239393939394a4242ffffffffffffd6d6d6313';
    wwv_flow_api.g_varchar2_table(737) := '1311818183131313131319c9c9cf7f7f78c8c8cd6d6'||wwv_flow.LF||
'd6636363efefef636363181818212121080808dededefffffffffff';
    wwv_flow_api.g_varchar2_table(738) := 'f080808080808080808080808000000080808000000000000000000000000000000000000'||wwv_flow.LF||
'0808080000000808080808081';
    wwv_flow_api.g_varchar2_table(739) := '01010080808adadadffffffffffff393939181818101010525252848484737373949494ffffffadadad4a4a4adedede94949';
    wwv_flow_api.g_varchar2_table(740) := '418'||wwv_flow.LF||
'1818313131848484ffffffffffff9494943939394242422121214242424242424a4a4a2929294a4a524a4a4a524a522';
    wwv_flow_api.g_varchar2_table(741) := '92929525252949494ffffffffffffffff'||wwv_flow.LF||
'ffffffffc6c6c69494949c9c9c8c8c8c8484846363638484847b73737b7b7b636';
    wwv_flow_api.g_varchar2_table(742) := '3637373736363635252523939395a5a5a5a5a5a524a4a6363639494949c9c9c'||wwv_flow.LF||
'a5a5a59c9c9ca5a5a59c9c9c8484848c848';
    wwv_flow_api.g_varchar2_table(743) := '48c8c8c635a633131314a424a4a4a4a524a523129294a42424a4a4a4a4a4a212121424242423939525252ffffffff'||wwv_flow.LF||
'ffffc';
    wwv_flow_api.g_varchar2_table(744) := 'ecece3131312121212929296b6b6b8c8c8c5a5a5ab5b5b5ffffff8c8c8c4a4a4ae7e7e76b6b6b181818101010e7e7e7fffff';
    wwv_flow_api.g_varchar2_table(745) := 'fffffff0808080808081010'||wwv_flow.LF||
'100808080808080000000808080000000000000000000000000000000000000808080000000';
    wwv_flow_api.g_varchar2_table(746) := '808080808081010108c8c8cffffffffffff525252101010181818'||wwv_flow.LF||
'212121313131181818848484ffffffa5a5a5212121292';
    wwv_flow_api.g_varchar2_table(747) := '9294a4a4a212121292929737373ffffffffffffa5a5a539393939393929212142424242424242424229'||wwv_flow.LF||
'29294a424a4a4a4';
    wwv_flow_api.g_varchar2_table(748) := 'a4a4a4a2929294a4a4a4a4a4abdbdbdffffffffffffffffffcececeb5b5b5c6c6c6c6c6c6c6c6c6c6bdbdc6c6c6cececec6c';
    wwv_flow_api.g_varchar2_table(749) := '6c6c6c6c6b5ad'||wwv_flow.LF||
'ad5a52524a4a4a4242425a52525a5a5a4a4a4a4242425252525a5a5a4242424a4a4a5252524a4a4a39393';
    wwv_flow_api.g_varchar2_table(750) := '94a4242524a4a524a523129314a4a4a4a4a4a4a4a4a'||wwv_flow.LF||
'2121214a4a4a424242424242292121424242393939636363fffffff';
    wwv_flow_api.g_varchar2_table(751) := 'fffffb5b5b5313131181818313131393939393939101010adadadffffff8c8c8c10101021'||wwv_flow.LF||
'2121313131181818080808f7f';
    wwv_flow_api.g_varchar2_table(752) := '7f7ffffffefefef0808081010100808080808080000000808080000000000000000000000000000000000000808080808080';
    wwv_flow_api.g_varchar2_table(753) := '808'||wwv_flow.LF||
'08080808101010080808848484ffffffffffff636363101010181818181818181818181818313131e7e7e7424242292';
    wwv_flow_api.g_varchar2_table(754) := '929292929313131181818313131525252'||wwv_flow.LF||
'ffffffffffffc6c6c63939394239392121214242424242424a4a4a2929294a4a4';
    wwv_flow_api.g_varchar2_table(755) := 'a4a4a4a5252522929294a4a52524a5252525ac6c6c6fffffffffffff7f7f7d6'||wwv_flow.LF||
'd6d6d6d6d6c6c6c6c6c6c6a5a5a5adadada';
    wwv_flow_api.g_varchar2_table(756) := '5a5a59c94947b7b7b8484845a5a5a5252523939395a5a5a737373adadadcec6c6efefeff7f7f7fffffff7f7f7ffff'||wwv_flow.LF||
'fff7f';
    wwv_flow_api.g_varchar2_table(757) := '7f7f7f7f78c8c8c524a52524a523131314a424a524a4a4a4a4a2929294a4a4a4a4a4a424242292929423939423939847b7bf';
    wwv_flow_api.g_varchar2_table(758) := 'fffffffffff9c9c9c313131'||wwv_flow.LF||
'1818182929292929292929291818184a4a4adedede313131101010181818212121101010181';
    wwv_flow_api.g_varchar2_table(759) := '818ffffffffffffcecece08080808080808080808080808080808'||wwv_flow.LF||
'080808080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(760) := '0080808000000080808080808080808636363ffffffffffff8484841010101818181818181010101818'||wwv_flow.LF||
'182121212121211';
    wwv_flow_api.g_varchar2_table(761) := '81818181818313131292929181818292929393939f7f7f7ffffffe7e7e74239393939392121214242424a424242424229292';
    wwv_flow_api.g_varchar2_table(762) := '94a424a524a4a'||wwv_flow.LF||
'4a4a4a292929525252524a524a4a4a313131c6c6c6ffffffcec6c69494948c84847b73736b6b6b5a5a5a8';
    wwv_flow_api.g_varchar2_table(763) := 'c84849494949c94949494949494945a5a5a52525239'||wwv_flow.LF||
'3939adadadfffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(764) := 'fffffffff8484844a4242524a52524a523131314a4a4a4a4a4a4a4a4a21212142424a4242'||wwv_flow.LF||
'424a424221212142393939393';
    wwv_flow_api.g_varchar2_table(765) := '9a5a5a5ffffffffffff7b7b7b313131181818313131292929292929101010292929212121292929080808181818101010181';
    wwv_flow_api.g_varchar2_table(766) := '818'||wwv_flow.LF||
'292929ffffffffffffbdbdbd08080808080808080808080800000008080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(767) := '008080800000008080808080810101008'||wwv_flow.LF||
'08084a4a4affffffffffff9c9c9c1010101818181818181818182121212121212';
    wwv_flow_api.g_varchar2_table(768) := '12121181818292929292929313131181818313131313131e7e7e7ffffffffff'||wwv_flow.LF||
'ff4a4a4a4242422121214a42424242424a4';
    wwv_flow_api.g_varchar2_table(769) := 'a4a2921214a4a4a4a4a4a524a52292929525252525252525252292929525252a5a5a5ffffffffffffffffffffffff'||wwv_flow.LF||
'fff7f';
    wwv_flow_api.g_varchar2_table(770) := '7d6d6d6c6bdbda5a5a5847b7b4a4a4a6b6363736b6b9c9c9cd6d6d6fffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(771) := 'ffff7f7f784848442393942'||wwv_flow.LF||
'42425252525252523129314242425252524a424229292942424a4a424242424229292939393';
    wwv_flow_api.g_varchar2_table(772) := '9423939d6ceceffffffffffff5252523131311818182929293131'||wwv_flow.LF||
'312121211010102121212929292121211010101818182';
    wwv_flow_api.g_varchar2_table(773) := '121211818184a4a4affffffffffffa5a5a5080808080808101010080808080808080808080808000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(774) := '000000000000000080808000000080808080808080808212121ffffffffffffcecece1010101818181818181010101010102';
    wwv_flow_api.g_varchar2_table(775) := '1212121212118'||wwv_flow.LF||
'1818212121292929292929181818292929313131a5a5a5ffffffffffff7b7b7b393939212121423939424';
    wwv_flow_api.g_varchar2_table(776) := '2424242422929294a42424a4a4a4a4a4a3129294a4a'||wwv_flow.LF||
'4a4a4a4a4a4a4a292929524a4a525252737373dededefffffffffff';
    wwv_flow_api.g_varchar2_table(777) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(778) := 'fffffcecece6363635252523131314a4242524a52524a4a2929294a4a4a4a424a4a4a4a21212142424a42424242424221212';
    wwv_flow_api.g_varchar2_table(779) := '142'||wwv_flow.LF||
'4242424242fffffffffffff7f7f73131313131311818183131312121212929291010102929292121212121211010101';
    wwv_flow_api.g_varchar2_table(780) := '81818181818181818737373ffffffffff'||wwv_flow.LF||
'ff7b7b7b000000101010080808080808000000080808000000000000000000000';
    wwv_flow_api.g_varchar2_table(781) := '000000000000000080808000000080808080808101010080808101010efefef'||wwv_flow.LF||
'fffffff7f7f718181818181821212110101';
    wwv_flow_api.g_varchar2_table(782) := '01818182121212929291818182121212929292929291818183131313131317b7b7bffffffffffffb5b5b542424221'||wwv_flow.LF||
'21214';
    wwv_flow_api.g_varchar2_table(783) := '242424242424a4a4a2921214a4a4a4a4a4a524a52292929524a525252525252522929295252525252525a5a5a31292994949';
    wwv_flow_api.g_varchar2_table(784) := '4e7e7e7ffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd';
    wwv_flow_api.g_varchar2_table(785) := '6d6d66b6b6b424242525252524a4a424242424242524a52524a4a'||wwv_flow.LF||
'3131314a424a524a524a4a4a2929294242424a4242423';
    wwv_flow_api.g_varchar2_table(786) := '9392929293939397b7373ffffffffffffbdbdbd31313131313118181829292931313121212118181821'||wwv_flow.LF||
'212129292918181';
    wwv_flow_api.g_varchar2_table(787) := '8101010181818181818101010adadadffffffffffff525252080808101010080808080808080808000000080808000000000';
    wwv_flow_api.g_varchar2_table(788) := '0000000000000'||wwv_flow.LF||
'00000000000000080808000000080808080808080808080808cececeffffffffffff39393918181810101';
    wwv_flow_api.g_varchar2_table(789) := '0181818181818212121212121181818212121292929'||wwv_flow.LF||
'292929181818292929313131393939fffffffffffff7f7f73939392';
    wwv_flow_api.g_varchar2_table(790) := '121213939424242424239422121214242424a4a4a4242422929314a4a4a524a524a4a4a29'||wwv_flow.LF||
'2929524a4a525252524a52312';
    wwv_flow_api.g_varchar2_table(791) := '9294a4a4a5a5a5a7b7b7badadadefefefffffffffffffffffffffffffffffffffffffffffffffffffffffffdededea5a5a56';
    wwv_flow_api.g_varchar2_table(792) := 'b6b'||wwv_flow.LF||
'6b5a525a3931314242425252525252523131314a424a4a4a4a524a4a2929294a424a4a4a4a4a424a2121214a4242393';
    wwv_flow_api.g_varchar2_table(793) := '939424242212121393939adadadffffff'||wwv_flow.LF||
'ffffff7b7b7b31313131313110101029292929292929292910101021212121212';
    wwv_flow_api.g_varchar2_table(794) := '1212121080808212121181818181818d6d6d6ffffffffffff21212100000008'||wwv_flow.LF||
'08080808080808080000000000000000000';
    wwv_flow_api.g_varchar2_table(795) := '00000000000000000000000000000080808000000080808080808101010080808101010949494ffffffffffff7373'||wwv_flow.LF||
'73181';
    wwv_flow_api.g_varchar2_table(796) := '818212121101010181818212121212121181818212121292929292929181818313131313131313131bdbdbdffffffffffff7';
    wwv_flow_api.g_varchar2_table(797) := 'b7b7b181818424242423942'||wwv_flow.LF||
'4242422121214a4a4a4a4a4a4a4a4a2929295252524a4a4a525252292929525252524a52525';
    wwv_flow_api.g_varchar2_table(798) := '2522929295252525252525252523131315a52526b636384848484'||wwv_flow.LF||
'8484fff7f7fffffff7f7f7848484847b7b635a5a4a4a4';
    wwv_flow_api.g_varchar2_table(799) := 'a3939395a525a524a52424242423942525252524a4a3939394242425252524a4a4a313131424242524a'||wwv_flow.LF||
'4a4a42422929294';
    wwv_flow_api.g_varchar2_table(800) := '242424a4a4a393939292929424242ffffffffffffffffff39393931313129292918181829292929292921212118181821212';
    wwv_flow_api.g_varchar2_table(801) := '1212121212121'||wwv_flow.LF||
'101010181818181818292929ffffffffffffe7e7e71010100808080808081010100808080808080000000';
    wwv_flow_api.g_varchar2_table(802) := '8080800000000000000000000000000000000000008'||wwv_flow.LF||
'0808000000080808080808080808080808525252ffffffffffff9c9';
    wwv_flow_api.g_varchar2_table(803) := 'c9c1818181818181010101010102121212121211818181818182929292929291818182929'||wwv_flow.LF||
'292929292929296b6b6bfffff';
    wwv_flow_api.g_varchar2_table(804) := 'fffffffcecece2121213939394242424242422121293939394a424a4a4a4a2929294a4a4a4a4a4a4a4a4a2929294a4a4a525';
    wwv_flow_api.g_varchar2_table(805) := '252'||wwv_flow.LF||
'524a52312931524a4a5252525252523131315252525a52524a4a4a313131e7e7e7ffffffdedede39393952525252525';
    wwv_flow_api.g_varchar2_table(806) := '24242423939394a4a4a52525239393942'||wwv_flow.LF||
'39424a4a4a524a523131314242424a4a4a4a4a4a2929294a42424242424a42422';
    wwv_flow_api.g_varchar2_table(807) := '121214242423939394242421818188c8c8cffffffffffffadadad3131312929'||wwv_flow.LF||
'29292929101010292929212121292929101';
    wwv_flow_api.g_varchar2_table(808) := '010212121181818212121101010181818181818525252ffffffffffffadadad080808000000080808080808080808'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(809) := '0080808000000000000000000000000000000000000080808000000080808080808101010080808101010212121fffffffff';
    wwv_flow_api.g_varchar2_table(810) := 'fffe7e7e718181818181810'||wwv_flow.LF||
'101018181821212121212118181821212121212129292918181831313129292931313121212';
    wwv_flow_api.g_varchar2_table(811) := '1e7e7e7ffffffffffff4a4a4a42424239393942424a1818214a4a'||wwv_flow.LF||
'4a4242424a4a4a292929524a4a4a4a4a5252522929295';
    wwv_flow_api.g_varchar2_table(812) := '25252524a4a525252292929525252524a4a5a52523129295252525252525252523131316b6b6badadad'||wwv_flow.LF||
'6b6b6b393131525';
    wwv_flow_api.g_varchar2_table(813) := '2525252524a4a4a3939395a525a525252423942393939525252524a4a393939424242524a524a4a4a3131314242424a4a4a4';
    wwv_flow_api.g_varchar2_table(814) := '2424229212942'||wwv_flow.LF||
'4242424242393939292929e7e7e7ffffffffffff525252313131313131292929181818292929292929212';
    wwv_flow_api.g_varchar2_table(815) := '1211818182121212121211818181010101818181818'||wwv_flow.LF||
'189c9c9cffffffffffff6b6b6b08080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(816) := '8080808000000000000000000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'080808080808000000101010c';
    wwv_flow_api.g_varchar2_table(817) := '6c6c6ffffffffffff42424218181810101010101021212118181818181818181829292921212118181821212131313129292';
    wwv_flow_api.g_varchar2_table(818) := '921'||wwv_flow.LF||
'21218c8c8cffffffffffffc6c6c639313942424239393921212142424242424242424a2921294a424a4a4a4a4a4a4a2';
    wwv_flow_api.g_varchar2_table(819) := '929294a4a4a524a524a4a4a2929294a4a'||wwv_flow.LF||
'4a525252524a52312931524a525a52524a4a4a292929525252525252423942393';
    wwv_flow_api.g_varchar2_table(820) := '9394a4a4a525252424242393939524a52525252393139423939524a52524a52'||wwv_flow.LF||
'3131314242424a4a4a4a4a4a29292942424';
    wwv_flow_api.g_varchar2_table(821) := '24242424242422121214242423939393939397b7b7bffffffffffffd6d6d610101031313129292929292910101029'||wwv_flow.LF||
'29292';
    wwv_flow_api.g_varchar2_table(822) := '12121292929101010212121181818212121080808181818101010dededeffffffffffff29292910101000000008080808080';
    wwv_flow_api.g_varchar2_table(823) := '80808080000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000808080808080808080808080808081';
    wwv_flow_api.g_varchar2_table(824) := '01010848484ffffffffffff8c8c8c181818101010181818212121'||wwv_flow.LF||
'212121101010212121212121292929181818313131292';
    wwv_flow_api.g_varchar2_table(825) := '929313131181818424242f7f7f7ffffffffffff73737339393939394221212142424242424242424229'||wwv_flow.LF||
'29294a4a4a4a4a4';
    wwv_flow_api.g_varchar2_table(826) := 'a524a52292129525252524a4a525252292929525252524a525252522929295252525252525252523131315a52524a4a4a525';
    wwv_flow_api.g_varchar2_table(827) := '2523131315a52'||wwv_flow.LF||
'52525252424242393939525252524a524239423939395252524a4a4a393139424242524a524a4a4a31293';
    wwv_flow_api.g_varchar2_table(828) := '14239424a4a4a424242292129423942424242424242'||wwv_flow.LF||
'efefefffffffffffff6b6b6b2121212929293131312929291818182';
    wwv_flow_api.g_varchar2_table(829) := '92929292929212121101010212121212121181818101010181818424242ffffffffffffce'||wwv_flow.LF||
'cece101010080808080808080';
    wwv_flow_api.g_varchar2_table(830) := '8080808080000000000000000000000000000000000000000000000000000000000000000000000000808080808080808080';
    wwv_flow_api.g_varchar2_table(831) := '808'||wwv_flow.LF||
'08101010313131ffffffffffffdedede181818101010101010181818181818181818181818212121212121181818292';
    wwv_flow_api.g_varchar2_table(832) := '929292929292929181818313131848484'||wwv_flow.LF||
'ffffffffffffe7e7e742424239393921212139393942424242424229212942424';
    wwv_flow_api.g_varchar2_table(833) := '24a4a4a4a4a4a2929294a4a4a524a4a4a4a4a292929524a4a524a4a4a4a4a31'||wwv_flow.LF||
'2931524a525252524a424a312931524a4a5';
    wwv_flow_api.g_varchar2_table(834) := '252524a42423931394a4a4a525252423942393939524a4a524a523939393939394a4a4a524a4a3131314242424a42'||wwv_flow.LF||
'424a4';
    wwv_flow_api.g_varchar2_table(835) := 'a4a292929424242423942424242211821424242313131adadadffffffffffffc6c6c63131311010103131312929292929291';
    wwv_flow_api.g_varchar2_table(836) := '01010292929212121212121'||wwv_flow.LF||
'1010102121211818181818180808081818188c8c8cffffffffffff848484080808101010000';
    wwv_flow_api.g_varchar2_table(837) := '00008080808080800000000000008080800000000000000000000'||wwv_flow.LF||
'000000000000000008080800000008080800000008080';
    wwv_flow_api.g_varchar2_table(838) := '8080808080808101010101010d6d6d6ffffffffffff5252521010101818181818182121211010102121'||wwv_flow.LF||
'212121212929291';
    wwv_flow_api.g_varchar2_table(839) := '81818292929292929313131181818313131313131dededeffffffffffffadadad39394221212142424239393942424a21212';
    wwv_flow_api.g_varchar2_table(840) := '94a4a4a4a424a'||wwv_flow.LF||
'524a4a292129524a4a4a4a4a5252522929295252524a4a4a525252292929525252524a4a524a523129315';
    wwv_flow_api.g_varchar2_table(841) := '252524a4a4a4a4a4a313131525252524a524a424a39'||wwv_flow.LF||
'31395252524a4a4a423942423942524a524a4a4a3939394239424a4';
    wwv_flow_api.g_varchar2_table(842) := 'a4a4a42422929294239394242424239422121214239396b6b6bffffffffffffffffff5252'||wwv_flow.LF||
'5231313118181829292931313';
    wwv_flow_api.g_varchar2_table(843) := '1292929181818292929292929212121101010212121212121181818101010181818efefefffffffffffff313131101010080';
    wwv_flow_api.g_varchar2_table(844) := '808'||wwv_flow.LF||
'08080800000008080800000008080800000000000000000000000000000000000000000000000000000000000008080';
    wwv_flow_api.g_varchar2_table(845) := '800000008080808080810101008080873'||wwv_flow.LF||
'7373ffffffffffffa5a5a51010101010101818181818181010101818182121212';
    wwv_flow_api.g_varchar2_table(846) := '12121181818212121292929292929181818292929313131525252ffffffffff'||wwv_flow.LF||
'ffffffff737373212121393939424242393';
    wwv_flow_api.g_varchar2_table(847) := '9392121214242424a42424242422929294a4a4a524a4a4a4a4a3129294a4a4a524a524a4a4a3129294a4a4a525252'||wwv_flow.LF||
'4a424';
    wwv_flow_api.g_varchar2_table(848) := 'a3129314a4a4a524a524242423131314a4a4a5252524239423931394a4a4a5252523939393939394a4a4a4a4a4a313131424';
    wwv_flow_api.g_varchar2_table(849) := '24242424242424229212142'||wwv_flow.LF||
'4242423939423939212121524a4aefefefffffffffffff9c9c9c31313131313110101031313';
    wwv_flow_api.g_varchar2_table(850) := '12929292929291010102121212121212121211010101818181818'||wwv_flow.LF||
'181818180808085a5a5affffffffffffc6c6c61010100';
    wwv_flow_api.g_varchar2_table(851) := '80808080808000000080808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000080';
    wwv_flow_api.g_varchar2_table(852) := '808000000080808080808080808080808101010181818ffffffffffffffffff2929291818181818182121211010102121212';
    wwv_flow_api.g_varchar2_table(853) := '1212129292910'||wwv_flow.LF||
'1010292929292929292929181818393939292929313131848484ffffffffffffffffff424242424242393';
    wwv_flow_api.g_varchar2_table(854) := '9394242422121214a42424242424a4a4a2921214a4a'||wwv_flow.LF||
'4a4a4a4a4a4a4a292929524a524a4a4a524a52292929524a52524a4';
    wwv_flow_api.g_varchar2_table(855) := 'a4a4a4a292929525252524a4a4a4a4a313131525252524a4a4242423931315252524a4a4a'||wwv_flow.LF||
'393939393939524a4a4a4a4a3';
    wwv_flow_api.g_varchar2_table(856) := '131313939394a4a4a4a4a4a292929393939424242424242292929d6d6d6ffffffffffffcecece31313131313129292918181';
    wwv_flow_api.g_varchar2_table(857) := '829'||wwv_flow.LF||
'2929292929292929181818212121292929212121101010181818212121181818101010c6c6c6ffffffffffff6363631';
    wwv_flow_api.g_varchar2_table(858) := '010101010100808080808080000000808'||wwv_flow.LF||
'08000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(859) := '000000000000000000000080808000000101010080808101010949494ffffff'||wwv_flow.LF||
'ffffff8c8c8c10101018181818181818181';
    wwv_flow_api.g_varchar2_table(860) := '8181818181818212121181818212121292929292929181818292929313131313131212121bdbdbdffffffffffffef'||wwv_flow.LF||
'efef4';
    wwv_flow_api.g_varchar2_table(861) := 'a4a4a4242423939392121214239394242424242423129293939394a4a4a4a4a4a2929294a424a4a4a4a4a4a4a3129294a424';
    wwv_flow_api.g_varchar2_table(862) := 'a524a4a4a424a3129314a4a'||wwv_flow.LF||
'4a524a4a4242423131314a4a4a4a4a4a4239393931394a4a4a4a4a4a3931313939394a42424';
    wwv_flow_api.g_varchar2_table(863) := 'a4a4a292929393939424242423939292929393939393131424242'||wwv_flow.LF||
'bdbdbdffffffffffffefefef313131313131292929313';
    wwv_flow_api.g_varchar2_table(864) := '131101010292929212121292929101010212121212121212121101010212121181818181818393939ff'||wwv_flow.LF||
'ffffffffffefefe';
    wwv_flow_api.g_varchar2_table(865) := 'f101010080808080808080808000000080808000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(866) := '0000000000000'||wwv_flow.LF||
'00000000080808080808080808080808101010080808313131ffffffffffffffffff31313110101021212';
    wwv_flow_api.g_varchar2_table(867) := '1101010181818181818292929101010292929212121'||wwv_flow.LF||
'292929101010313131313131313131101010424242dededefffffff';
    wwv_flow_api.g_varchar2_table(868) := 'fffffefefef5252524242422121214242424239394242422121214a4a4a4242424a4a4a29'||wwv_flow.LF||
'29294a4a4a4a424a524a4a292';
    wwv_flow_api.g_varchar2_table(869) := '9294a4a4a4a4a4a4a4a4a292929524a524a4a4a4a4a4a313131524a4a4a4a4a4242423131314a4a4a4a4a4a3939393939394';
    wwv_flow_api.g_varchar2_table(870) := 'a4a'||wwv_flow.LF||
'4a4242423131313939394a4242424242292929393939424242bdbdbdffffffffffffffffff636363212121313131313';
    wwv_flow_api.g_varchar2_table(871) := '131292929181818292929292929212121'||wwv_flow.LF||
'181818212121212121181818101010181818212121101010bdbdbdfffffffffff';
    wwv_flow_api.g_varchar2_table(872) := 'f84848408080808080810101008080808080800000008080800000008080800'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(873) := '00000000000000000000000000000000000080808000000101010080808080808080808b5b5b5ffffffffffff8c8c'||wwv_flow.LF||
'8c181';
    wwv_flow_api.g_varchar2_table(874) := '818101010101010181818212121181818101010212121292929212121181818292929292929292929181818313131424242e';
    wwv_flow_api.g_varchar2_table(875) := '7e7e7ffffffffffffefefef'||wwv_flow.LF||
'5a5a5a2121213939394242424239392121214242424a4a4a4239392921214242424a4a4a424';
    wwv_flow_api.g_varchar2_table(876) := '2422929294a42424a4a4a4242422929294a4a4a4a4a4a42424231'||wwv_flow.LF||
'31314a4a4a4a4a4a3939393931314242424a4a4a31313';
    wwv_flow_api.g_varchar2_table(877) := '1313131424242424242292929393939393131424242212121424242cec6c6ffffffffffffffffff7373'||wwv_flow.LF||
'733131311818183';
    wwv_flow_api.g_varchar2_table(878) := '131312929293131311010102929292121212929291010102121212121212121210808081818181010104a4a4afffffffffff';
    wwv_flow_api.g_varchar2_table(879) := 'fefefef181818'||wwv_flow.LF||
'0000001010100808080808080000000808080000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(880) := '0000000000000000000000000000000000008080800'||wwv_flow.LF||
'0000080808080808101010080808101010313131fffffffffffffff';
    wwv_flow_api.g_varchar2_table(881) := 'fff3131311818181010101818181818182121211010102121212121212929291010102929'||wwv_flow.LF||
'2929292931313118181831313';
    wwv_flow_api.g_varchar2_table(882) := '13131314a4a4ae7e7e7ffffffffffffffffff6b6b6b4239394239394242422121214242424242424a4a4a2921214a4a4a424';
    wwv_flow_api.g_varchar2_table(883) := '242'||wwv_flow.LF||
'4a4a4a2921214a4a4a4a42424a4a4a2929294a4a4a4a42424242423129294a4a4a4a42424239393131314a4a4a42424';
    wwv_flow_api.g_varchar2_table(884) := '23931313131314a424242424229292931'||wwv_flow.LF||
'31314a42423939394a4242dededeffffffffffffffffff7b73733131313131312';
    wwv_flow_api.g_varchar2_table(885) := '121212929293131312929291010102929292929292121211010102121212121'||wwv_flow.LF||
'21181818101010181818181818cececefff';
    wwv_flow_api.g_varchar2_table(886) := 'fffffffff848484101010080808080808080808080808080808000000080808000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(887) := '0000000000000000000000000000000000000000000000000080808000000080808080808080808000000080808a5a5a5fff';
    wwv_flow_api.g_varchar2_table(888) := 'fffffffffb5b5b518181810'||wwv_flow.LF||
'101010101021212118181818181818181821212121212118181829292929292921212121212';
    wwv_flow_api.g_varchar2_table(889) := '1292929313131292929313131d6d6d6ffffffffffffffffffadad'||wwv_flow.LF||
'ad4242423939392121214239394242424239392121214';
    wwv_flow_api.g_varchar2_table(890) := '239394242424242422929294242424242424242422929294242424a4242393939312929424242424242'||wwv_flow.LF||
'393131313131423';
    wwv_flow_api.g_varchar2_table(891) := '939424242313131393131424242424242292121393939393939847b7bfff7f7ffffffffffffffffff5a5a5a3931312929293';
    wwv_flow_api.g_varchar2_table(892) := '1313110101031'||wwv_flow.LF||
'3131292929292929101010292929212121212121101010212121181818181818080808212121636363fff';
    wwv_flow_api.g_varchar2_table(893) := 'fffffffffe7e7e71818181010100000001010100000'||wwv_flow.LF||
'0008080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(894) := '0000000000000000000000000000000000000000000000000080808000000080808080808'||wwv_flow.LF||
'1010100808080808081010102';
    wwv_flow_api.g_varchar2_table(895) := '12121f7f7f7ffffffffffff63636310101018181818181821212110101021212118181829292918181829292929292931313';
    wwv_flow_api.g_varchar2_table(896) := '110'||wwv_flow.LF||
'1010313131313131313131181818393939bdbdbdffffffffffffffffffe7e7e77b73732121214239394239394242422';
    wwv_flow_api.g_varchar2_table(897) := '121214242424242424a42422121214a42'||wwv_flow.LF||
'424242424242422921214a42424242424242422929294a4242424242393939313';
    wwv_flow_api.g_varchar2_table(898) := '1314a42424242423131313131314242423939393131314a4a4acececeffffff'||wwv_flow.LF||
'ffffffffffffefefef5a5a5a21212131313';
    wwv_flow_api.g_varchar2_table(899) := '131313129292918181829292929292929292918181821212121212121212110101018181821212118181810101021'||wwv_flow.LF||
'2121e';
    wwv_flow_api.g_varchar2_table(900) := 'fefefffffffffffff63636310101008080808080808080808080800000008080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(901) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000808080000000808080000000';
    wwv_flow_api.g_varchar2_table(902) := '80808101010737373ffffffffffffe7e7e7212121101010181818'||wwv_flow.LF||
'181818101010181818212121212121101010212121292';
    wwv_flow_api.g_varchar2_table(903) := '9292121211818182929293131312929291818183131313131318c8c8cffffffffffffffffffffffffc6'||wwv_flow.LF||
'c6c663636339393';
    wwv_flow_api.g_varchar2_table(904) := '93939392121213939394242424239392121214242424a4242393939292929424242424242393131312929424242424242313';
    wwv_flow_api.g_varchar2_table(905) := '1313131313939'||wwv_flow.LF||
'39393939292929313131393939525252a5a5a5ffffffffffffffffffffffffc6c6c642424231313118181';
    wwv_flow_api.g_varchar2_table(906) := '8313131292929292929101010292929212121292929'||wwv_flow.LF||
'101010292929212121212121080808181818181818181818080808a';
    wwv_flow_api.g_varchar2_table(907) := 'dadadffffffffffffbdbdbd10101008080810101000000008080800000008080800000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(908) := '0000000000000000000000000000000000000000000000000000000000000000000000000000808080808080808080808080';
    wwv_flow_api.g_varchar2_table(909) := '808'||wwv_flow.LF||
'08101010101010101010cececeffffffffffffadadad181818181818181818101010212121212121292929101010292';
    wwv_flow_api.g_varchar2_table(910) := '929292929212121101010292929313131'||wwv_flow.LF||
'313131181818424242dedede737373424242d6d6d6fffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(911) := 'fcecece7b7b7b21212142424239393942393921212142393942393942424221'||wwv_flow.LF||
'21214242424242423939392929294239394';
    wwv_flow_api.g_varchar2_table(912) := '23939393131292929424242393939313131525252b5b5b5ffffffffffffffffffffffffefefef7373732929293131'||wwv_flow.LF||
'31313';
    wwv_flow_api.g_varchar2_table(913) := '1312121213131313131312929291818182929292929292121211010101818182121212121211010101818181818181818186';
    wwv_flow_api.g_varchar2_table(914) := '36363fffffffffffff7f7f7'||wwv_flow.LF||
'313131101010101010080808080808080808080808000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(915) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000008080800000';
    wwv_flow_api.g_varchar2_table(916) := '0080808000000080808080808080808313131f7f7f7ffffffffffff6b6b6b1818181818180808081818'||wwv_flow.LF||
'181818182121211';
    wwv_flow_api.g_varchar2_table(917) := '010102121212121212121211818182929292929292929291818189c9c9cffffff6b6b6b393939636363848484e7e7e7fffff';
    wwv_flow_api.g_varchar2_table(918) := 'fffffffffffff'||wwv_flow.LF||
'fffffff7f7f7b5b5b57b7b7b4a4a4a2921213931313939393931312921213939393939393939392929293';
    wwv_flow_api.g_varchar2_table(919) := '93939424242313131313131636363a5a5a5dededeff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffa5a5a56b6b6bcececeffffffc6c';
    wwv_flow_api.g_varchar2_table(920) := '6c64242421010102929292929292929291010102929292121212121211010102121211818'||wwv_flow.LF||
'1818181810101018181818181';
    wwv_flow_api.g_varchar2_table(921) := '8313131efefefffffffffffff7b7b7b000000101010080808080808000000080808000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(922) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(923) := '008080800000008080808080808080808'||wwv_flow.LF||
'08080808086b6b6bffffffffffffffffff4242421818181010101818182121212';
    wwv_flow_api.g_varchar2_table(924) := '12121080808212121212121292929101010292929212121313131393939ffff'||wwv_flow.LF||
'ffd6d6d6393939d6d6d6ffffff7b7b7b393';
    wwv_flow_api.g_varchar2_table(925) := '939848484efefefffffffffffffffffffffffffffffffffffffe7e7e7cec6c6a59c9c949494736b6b7b7b7b7b7373'||wwv_flow.LF||
'7b7b7';
    wwv_flow_api.g_varchar2_table(926) := 'b7b7b7ba5a5a5b5b5b5dededefffffffffffffffffffffffffffffffffffff7f7f7adadad4242425a5a5affffffffffffe7e';
    wwv_flow_api.g_varchar2_table(927) := '7e7ffffffd6d6d621212129'||wwv_flow.LF||
'292929292921212118181821212129292921212118181818181821212118181810101018181';
    wwv_flow_api.g_varchar2_table(928) := '8212121d6d6d6ffffffffffffc6c6c60808080808080808081010'||wwv_flow.LF||
'100000000808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(929) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(930) := '000000000000000080808080808101010080808080808080808101010a5a5a5ffffffffffffefefef2929290808081010101';
    wwv_flow_api.g_varchar2_table(931) := '8181818181810'||wwv_flow.LF||
'1010181818212121181818101010212121292929212121c6c6c6ffffff5a5a5ab5b5b5ffffffffffff4a4';
    wwv_flow_api.g_varchar2_table(932) := 'a4aa5a5a59c9c9c393939737373bdbdbdffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(933) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffdedede848484424242'||wwv_flow.LF||
'212121292929949494ffffff8';
    wwv_flow_api.g_varchar2_table(934) := '48484292929bdbdbdffffff73737321212121212129292910101021212121212121212108080818181818181821212108080';
    wwv_flow_api.g_varchar2_table(935) := '818'||wwv_flow.LF||
'1818adadadffffffffffffefefef2121211010100808080808080808080808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(936) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(937) := '000080808000000000000080808080808000000080808080808101010101010'||wwv_flow.LF||
'181818d6d6d6ffffffffffffd6d6d618181';
    wwv_flow_api.g_varchar2_table(938) := '8181818181818181818101010212121181818292929101010292929212121636363ffffffb5b5b5949494ffffffff'||wwv_flow.LF||
'ffffc';
    wwv_flow_api.g_varchar2_table(939) := 'ecece525252ffffffe7e7e7393939313131313131292929737373adadaddededefffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(940) := 'fffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffe7e7e7bdbdbd848484424242212121393939313131212121292929848484f';
    wwv_flow_api.g_varchar2_table(941) := 'fffffadadad2929294a4a4afffffff7f7f7393939292929212121'||wwv_flow.LF||
'181818181818212121212121101010212121181818181';
    wwv_flow_api.g_varchar2_table(942) := '818101010949494ffffffffffffffffff42424210101010101008080808080808080808080808080800'||wwv_flow.LF||
'000008080800000';
    wwv_flow_api.g_varchar2_table(943) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(944) := '0000000000000'||wwv_flow.LF||
'00080808000000000000000000080808080808080808080808080808101010292929efefeffffffffffff';
    wwv_flow_api.g_varchar2_table(945) := 'fc6c6c6181818181818181818101010181818181818'||wwv_flow.LF||
'212121101010212121292929d6d6d6ffffff7b7b7bffffffcececef';
    wwv_flow_api.g_varchar2_table(946) := 'fffff6b6b6bcececeffffff63636329292931313131313118181831313152525284848463'||wwv_flow.LF||
'63636b6b6b6b6b6b8c8c8c8c8';
    wwv_flow_api.g_varchar2_table(947) := 'c8c9494949c9c9c9494948484847373736b6b6b3939392121217b7b7bcecece6b6b6b2121212929293131311818182929293';
    wwv_flow_api.g_varchar2_table(948) := '131'||wwv_flow.LF||
'31f7f7f7ffffff5a5a5a212121949494ffffffadadad212121181818101010212121181818212121080808181818101';
    wwv_flow_api.g_varchar2_table(949) := '010181818848484ffffffffffffffffff'||wwv_flow.LF||
'63636310101008080810101000000008080808080808080800000008080800000';
    wwv_flow_api.g_varchar2_table(950) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(951) := '000000000000000000000000000000000000000000808080000000808080808080808080808081010100808084242'||wwv_flow.LF||
'42f7f';
    wwv_flow_api.g_varchar2_table(952) := '7f7ffffffffffffc6c6c62121211818181010102121211818182121211010102121217b7b7bffffffb5b5b5f7f7f7dedede9';
    wwv_flow_api.g_varchar2_table(953) := 'c9c9cf7f7f7737373ffffff'||wwv_flow.LF||
'cecece181818292929292929313131181818313131848484fffffffffffffffffff7f7f7bdb';
    wwv_flow_api.g_varchar2_table(954) := 'dbd181818313131313131313131212121949494ffffff52525221'||wwv_flow.LF||
'2121c6c6c6ffffffa5a5a521212131313129292921212';
    wwv_flow_api.g_varchar2_table(955) := '12121213131317b7b7bffffffdedede292929292929e7e7e7ffffff5252522121211010101818182121'||wwv_flow.LF||
'211818181010101';
    wwv_flow_api.g_varchar2_table(956) := '818181818187b7b7bffffffffffffffffff84848408080808080810101008080808080808080808080800000008080800000';
    wwv_flow_api.g_varchar2_table(957) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(958) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000080808000000080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(959) := '808525252f7f7f7ffffffffffffc6c6c62121211010101010101818181818181010102929'||wwv_flow.LF||
'29f7f7f7f7f7f7e7e7e7efefe';
    wwv_flow_api.g_varchar2_table(960) := 'f424242dededea5a5a5dededeffffff4a4a4a181818292929313131212121181818292929a5a5a5ffffffb5b5b5adadadd6d';
    wwv_flow_api.g_varchar2_table(961) := '6d6'||wwv_flow.LF||
'a5a5a5181818292929313131212121212121737373ffffff737373212121cececeffffffc6c6c621212129292929292';
    wwv_flow_api.g_varchar2_table(962) := '9181818292929212121292929cececeff'||wwv_flow.LF||
'ffff7b7b7b2121215a5a5affffffcecece2121210808081818181818181818180';
    wwv_flow_api.g_varchar2_table(963) := '80808181818848484ffffffffffffffffff8c8c8c1010100808080808080808'||wwv_flow.LF||
'08080808000000080808000000000000000';
    wwv_flow_api.g_varchar2_table(964) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(965) := '0000000000000000000000000000000000000000000000000000000080808000000080808000000080808080808080808000';
    wwv_flow_api.g_varchar2_table(966) := '000101010080808525252f7'||wwv_flow.LF||
'f7f7ffffffffffffdedede2121211818181818181818181010109c9c9cfffffffffffffffff';
    wwv_flow_api.g_varchar2_table(967) := 'f5a5a5a5a5a5affffffa5a5a5ffffffadadad2929291818182929'||wwv_flow.LF||
'29292929313131101010292929cececeffffff4242423';
    wwv_flow_api.g_varchar2_table(968) := '13131292929292929181818313131292929313131181818525252ffffff9c9c9c212121e7e7e7ffffff'||wwv_flow.LF||
'ffffff212121292';
    wwv_flow_api.g_varchar2_table(969) := '9292929291818182121212929292929294a4a4affffffffffff313131181818bdbdbdffffff7b7b7b1010101818182121211';
    wwv_flow_api.g_varchar2_table(970) := '010101818189c'||wwv_flow.LF||
'9c9cffffffffffffffffff949494101010080808080808101010101010080808080808000000080808000';
    wwv_flow_api.g_varchar2_table(971) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(972) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000808080000000808080';
    wwv_flow_api.g_varchar2_table(973) := '808080808080808081010101010104a4a4af7f7f7ffffffffffffefefef424242181818181818393939fffffffffffffffff';
    wwv_flow_api.g_varchar2_table(974) := 'f7b'||wwv_flow.LF||
'7b7b181818b5b5b5e7e7e7f7f7f7f7f7f7393939212121181818212121292929212121181818292929e7e7e7ffffff2';
    wwv_flow_api.g_varchar2_table(975) := '929292121212929292929291818182929'||wwv_flow.LF||
'29292929292929181818292929f7f7f7cecece212121efefefffffffffffff424';
    wwv_flow_api.g_varchar2_table(976) := '242212121292929181818212121212121212121181818a5a5a5ffffffadadad'||wwv_flow.LF||
'080808393939ffffffefefef18181818181';
    wwv_flow_api.g_varchar2_table(977) := '8101010212121bdbdbdffffffffffffffffff84848410101008080810101008080808080808080808080800000008'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(978) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(979) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000808080000000808080';
    wwv_flow_api.g_varchar2_table(980) := '00000080808000000080808080808101010080808393939efefef'||wwv_flow.LF||
'ffffffffffffffffff7b7b7b181818636363fffffffff';
    wwv_flow_api.g_varchar2_table(981) := 'fffb5b5b5101010313131ffffffffffffffffff8c8c8c18181829292910101029292929292929292910'||wwv_flow.LF||
'1010313131fffff';
    wwv_flow_api.g_varchar2_table(982) := 'fefefef181818292929212121292929101010292929212121292929181818292929d6d6d6f7f7f7212121ffffffefefeffff';
    wwv_flow_api.g_varchar2_table(983) := 'fff7373732929'||wwv_flow.LF||
'29212121181818212121212121212121181818292929f7f7f7ffffff424242212121949494ffffff63636';
    wwv_flow_api.g_varchar2_table(984) := '31818184a4a4ae7e7e7ffffffffffffffffff737373'||wwv_flow.LF||
'1010101010101010100808080808080808080808080000000808080';
    wwv_flow_api.g_varchar2_table(985) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(986) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(987) := '000'||wwv_flow.LF||
'00000000080808080808080808101010080808080808080808292929cececeffffffffffffffffffb5b5b5292929313';
    wwv_flow_api.g_varchar2_table(988) := '1319494941818181010107b7b7bffffff'||wwv_flow.LF||
'ffffffe7e7e72121212929291818181818182121212121212121211010104a4a4';
    wwv_flow_api.g_varchar2_table(989) := 'affffffffffffffffffd6d6d65a5a5a21212118181821212129292921212118'||wwv_flow.LF||
'1818212121adadadffffff4a4a4affffffb';
    wwv_flow_api.g_varchar2_table(990) := '5b5b5ffffff9c9c9c212121292929101010212121212121212121101010181818848484ffffffcecece1818182121'||wwv_flow.LF||
'214a4';
    wwv_flow_api.g_varchar2_table(991) := 'a4a1010107b7b7bfffffffffffffffffff7f7f75252521010100000000808080808080808080000000808080000000808080';
    wwv_flow_api.g_varchar2_table(992) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(993) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(994) := '0000000000000080808080808000000080808080808080808080808101010101010181818a5a5a5ffff'||wwv_flow.LF||
'ffffffffffffffe';
    wwv_flow_api.g_varchar2_table(995) := 'fefef636363181818181818080808dededeffffffffffff63636321212118181821212110101029292921212129292910101';
    wwv_flow_api.g_varchar2_table(996) := '0737373ffffff'||wwv_flow.LF||
'dededec6c6c6f7f7f75252522929291010102929292929292121211818182929297b7b7bffffff8c8c8cf';
    wwv_flow_api.g_varchar2_table(997) := 'fffff737373ffffffc6c6c621212121212118181818'||wwv_flow.LF||
'1818212121212121101010181818181818d6d6d6f7f7f7313131181';
    wwv_flow_api.g_varchar2_table(998) := '818393939cececeffffffffffffffffffd6d6d63131311010101010100808080808080808'||wwv_flow.LF||
'0808080800000000000008080';
    wwv_flow_api.g_varchar2_table(999) := '8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1000) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(1001) := '000000000000000000000000000000000'||wwv_flow.LF||
'0000000000080808080808080808080808101010080808080808636363f7f7f7f';
    wwv_flow_api.g_varchar2_table(1002) := 'fffffffffffffffffc6c6c6393939101010636363e7e7e7c6c6c61010101818'||wwv_flow.LF||
'18212121181818101010181818212121181';
    wwv_flow_api.g_varchar2_table(1003) := '8181010108c8c8cffffff848484181818212121212121181818181818212121212121181818181818212121525252'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(1004) := 'fcececeffffff5a5a5ad6d6d6efefef212121212121101010181818181818212121101010181818181818393939181818292';
    wwv_flow_api.g_varchar2_table(1005) := '9298c8c8cffffffffffffff'||wwv_flow.LF||
'ffffffffffa5a5a508080810101008080810101000000010101008080808080800000008080';
    wwv_flow_api.g_varchar2_table(1006) := '80000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1007) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1008) := '0000000000000000000000000000000000000000000000808080000000808080000000808080808080808080808081010102';
    wwv_flow_api.g_varchar2_table(1009) := '92929c6c6c6ff'||wwv_flow.LF||
'ffffffffffffffffffffffa5a5a5313131181818393939101010181818181818212121101010181818181';
    wwv_flow_api.g_varchar2_table(1010) := '818212121101010b5b5b5ffffff6363631010102121'||wwv_flow.LF||
'2121212121212110101021212121212121212118181821212129292';
    wwv_flow_api.g_varchar2_table(1011) := '9ffffffffffffffffff525252adadadffffff313131181818101010181818212121181818'||wwv_flow.LF||
'1818181010101818181818187';
    wwv_flow_api.g_varchar2_table(1012) := 'b7b7befefefffffffffffffffffffe7e7e75a5a5a08080810101008080810101008080808080808080808080800000008080';
    wwv_flow_api.g_varchar2_table(1013) := '800'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1014) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1015) := '000000000000000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'00000008080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1016) := '8080808080808080808636363efefefffffffffffffffffffffffffa5a5a531313110101018181818181818181810'||wwv_flow.LF||
'10101';
    wwv_flow_api.g_varchar2_table(1017) := '81818212121181818101010cececeffffff39393910101018181818181818181810101018181818181818181810101018181';
    wwv_flow_api.g_varchar2_table(1018) := '8212121d6d6d6ffffffffff'||wwv_flow.LF||
'ff3939397b7b7bffffff5a5a5a2121211010101818181818181818181010101818187b7b7be';
    wwv_flow_api.g_varchar2_table(1019) := 'fefefffffffffffffffffffffffff949494181818101010101010'||wwv_flow.LF||
'000000080808080808080808000000080808000000080';
    wwv_flow_api.g_varchar2_table(1020) := '80800000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1021) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1022) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000008080800000008080800000008080808080808080';
    wwv_flow_api.g_varchar2_table(1023) := '8000000080808101010101010080808212121949494'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffb5b5b56363631818181818181';
    wwv_flow_api.g_varchar2_table(1024) := '01010181818181818212121080808f7f7f7ffffffffffffdededebdbdbd42424218181810'||wwv_flow.LF||
'1010212121181818181818101';
    wwv_flow_api.g_varchar2_table(1025) := '010212121181818b5b5b5ffffffffffff292929525252ffffff8484841818181010101818181818183939399c9c9cf7f7f7f';
    wwv_flow_api.g_varchar2_table(1026) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffc6c6c6313131101010080808101010080808080808080808101010080808080808000000080';
    wwv_flow_api.g_varchar2_table(1027) := '808000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1028) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1029) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00080';
    wwv_flow_api.g_varchar2_table(1030) := '8080000000808080808080808081010100808080808081010102929299c9c9cf7f7f7fffffffffffffffffffffffff7f7f79';
    wwv_flow_api.g_varchar2_table(1031) := 'c9c9c4a4a4a181818181818'||wwv_flow.LF||
'1010101818187b7b7ba5a5a5c6c6c6f7f7f7ffffff393939181818101010101010181818181';
    wwv_flow_api.g_varchar2_table(1032) := '818101010101010212121848484dededea5a5a518181818181829'||wwv_flow.LF||
'2929181818181818313131848484d6d6d6fffffffffff';
    wwv_flow_api.g_varchar2_table(1033) := 'fffffffffffffffffffc6c6c64a4a4a0808081010100808080808080808080808080000000808080000'||wwv_flow.LF||
'000808080000000';
    wwv_flow_api.g_varchar2_table(1034) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1035) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1036) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000080';
    wwv_flow_api.g_varchar2_table(1037) := '8080808080808080000000808080808080808080808081010100808081010100808082929'||wwv_flow.LF||
'298c8c8cefefeffffffffffff';
    wwv_flow_api.g_varchar2_table(1038) := 'fffffffffffffffffffffffffb5b5b5848484424242212121101010181818080808212121181818181818101010181818101';
    wwv_flow_api.g_varchar2_table(1039) := '010'||wwv_flow.LF||
'181818101010181818181818181818101010181818181818393939636363a5a5a5e7e7e7fffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1040) := 'fffffffffffffb5b5b542424208080810'||wwv_flow.LF||
'10101010100808080808080808081010100000000808080808080808080000000';
    wwv_flow_api.g_varchar2_table(1041) := '808080000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1042) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1043) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1044) := '00000000000000000000000'||wwv_flow.LF||
'00000808081010100808080808080000001010100000000808080808081010101010105a5a5';
    wwv_flow_api.g_varchar2_table(1045) := 'ab5b5b5ffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffdededeadadad9c9c9c7373736363635252524242424';
    wwv_flow_api.g_varchar2_table(1046) := '242424242424242425252525a5a5a737373848484a5a5a5cececef7f7f7ffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(1047) := 'fffdedede7b7b7b2929290808081010100808080808080808081010100808080808080000000808080000000808080000000';
    wwv_flow_api.g_varchar2_table(1048) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1049) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1050) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1051) := '0000000000008080800000008080800000008080800000008080800000010101008080810101000000010101008080810101';
    wwv_flow_api.g_varchar2_table(1052) := '008'||wwv_flow.LF||
'0808101010212121737373b5b5b5fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1053) := 'fffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffcecece848';
    wwv_flow_api.g_varchar2_table(1054) := '484393939101010080808080808101010080808080808080808101010080808'||wwv_flow.LF||
'00000000000010101008080800000000000';
    wwv_flow_api.g_varchar2_table(1055) := '008080800000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1056) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1057) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1058) := '00000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'000000080808000000080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1059) := '8080808080808080808080808080808080808081010104a4a4a7b7b7bb5b5b5dededeffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(1060) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffefefefbdbdbd949494525252212121080';
    wwv_flow_api.g_varchar2_table(1061) := '8081010100808'||wwv_flow.LF||
'0810101000000008080808080808080800000008080808080808080800000008080800000000000000000';
    wwv_flow_api.g_varchar2_table(1062) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1063) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1064) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1065) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000080808000000080808080808080';
    wwv_flow_api.g_varchar2_table(1066) := '808080808101010080808101010080808'||wwv_flow.LF||
'10101000000010101008080810101008080810101010101039393952525273737';
    wwv_flow_api.g_varchar2_table(1067) := '38484849c9c9c9c9c9ca5a5a5a5a5a5a5a5a59c9c9c8c8c8c73737363636342'||wwv_flow.LF||
'42422121211010101010100808081010101';
    wwv_flow_api.g_varchar2_table(1068) := '010100808080808081010100808080808080808080808080808080808080808080808080808080808080808080808'||wwv_flow.LF||
'08000';
    wwv_flow_api.g_varchar2_table(1069) := '0000808080000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1070) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1071) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1072) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000808080000000';
    wwv_flow_api.g_varchar2_table(1073) := '8080800000008080800000008080808080808080808080808080808080810101008080808080808080810101008080808080';
    wwv_flow_api.g_varchar2_table(1074) := '8080808101010'||wwv_flow.LF||
'0808080808080808081010100808080808080808081010100808080808080808081010100808080808080';
    wwv_flow_api.g_varchar2_table(1075) := '8080808080808080808080808080808080800000008'||wwv_flow.LF||
'0808080808080808000000080808000000080808000000000000000';
    wwv_flow_api.g_varchar2_table(1076) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1077) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1078) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1079) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000808080000000';
    wwv_flow_api.g_varchar2_table(1080) := '808080000000808080808080808080000000808080808080808080000001010'||wwv_flow.LF||
'10080808101010080808101010080808101';
    wwv_flow_api.g_varchar2_table(1081) := '010080808101010080808101010080808101010080808101010080808101010080808101010080808101010080808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(1082) := '8080808101010080808080808080808101010080808080808000000080808000000080808000000080808000000000000000';
    wwv_flow_api.g_varchar2_table(1083) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1084) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(1085) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1086) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1087) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000080808000000080808000000080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1088) := '8080808080808080808080808080808080808080808'||wwv_flow.LF||
'0808080808080808080808080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1089) := '8000000080808080808080808000000080808000000080808000000080808000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1090) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1091) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1092) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1093) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1094) := '000000000000000000000000000000000000008080800000008080800000008080800000008080808080808080800'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1095) := '8080808080808080800000008080808080808080800000008080808080808080808080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1096) := '80808080808080000000808'||wwv_flow.LF||
'080000000808080000000808080000000808080000000808080000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1097) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1098) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1099) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1100) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1101) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000808080000000';
    wwv_flow_api.g_varchar2_table(1102) := '0000000000008080800000000000008080808080800000008080800000008080800000008'||wwv_flow.LF||
'0808000000080808000000080';
    wwv_flow_api.g_varchar2_table(1103) := '8080000000808080000000000000000000808080000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1104) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1105) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1106) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1107) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1108) := '0000000000000000000000000000000000000000000000000000000000000000808080000000808080000000808080000000';
    wwv_flow_api.g_varchar2_table(1109) := '80808000000080808000000'||wwv_flow.LF||
'080808000000080808000000080808000000080808080808080808000000080808080808080';
    wwv_flow_api.g_varchar2_table(1110) := '80800000008080800000008080800000008080800000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1111) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1112) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1113) := '0080808000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1114) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1115) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1116) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1117) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1118) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1119) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1120) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1121) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1122) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000008080800000';
    wwv_flow_api.g_varchar2_table(1123) := '00000000000000808080000000000000000000808080000000808'||wwv_flow.LF||
'080000000808080000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1124) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1125) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1126) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1127) := '000000000000000000000080808212121000000040000002701ffff030000000000}\par}}}{\rtlch\fcs1 \af0\afs18 \';
    wwv_flow_api.g_varchar2_table(1128) := 'ltrch\fcs0 \b\fs18\insrsid1643773               \tab \tab }'||wwv_flow.LF||
'{\field{\*\fldinst {\rtlch\fcs1 \af0\af';
    wwv_flow_api.g_varchar2_table(1129) := 's18 \ltrch\fcs0 \b\fs18\insrsid1643773\charrsid6776828  DATE \\@ "MMMM d, yyyy" }}{\fldrslt {\rtlch\';
    wwv_flow_api.g_varchar2_table(1130) := 'fcs1 \af0\afs18 \ltrch\fcs0 \b\fs18\lang1024\langfe1024\noproof\insrsid14502514 September 18, 2021}}';
    wwv_flow_api.g_varchar2_table(1131) := '}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectdefaultcl\sftnbj {\rtlch\fcs1 \af0\afs32 \ltrch\fcs0 \b\fs32\';
    wwv_flow_api.g_varchar2_table(1132) := 'insrsid5065116 '||wwv_flow.LF||
'\par }\pard \ltrpar\s16\qc \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wrapdefault\asp';
    wwv_flow_api.g_varchar2_table(1133) := 'alpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid1643773 {\rtlch\fcs1 \af0\afs32 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(1134) := '\b\fs32\insrsid1643773 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af0\afs32 \ltrch\fcs0 \b\fs32\insrsid14755898\charrsid1';
    wwv_flow_api.g_varchar2_table(1135) := '4755898 Restaurant Management System'||wwv_flow.LF||
'\par }\pard \ltrpar\s16\qc \li0\ri0\sl276\slmult1\widctlpar\tq';
    wwv_flow_api.g_varchar2_table(1136) := 'c\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid1643773 {';
    wwv_flow_api.g_varchar2_table(1137) := '\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs24\insrsid14755898\charrsid14755898 '||wwv_flow.LF||
'286/E, Mogbazar, Dhaka-1';
    wwv_flow_api.g_varchar2_table(1138) := '271}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs24\insrsid14755898 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af0\afs40 \ltrch';
    wwv_flow_api.g_varchar2_table(1139) := '\fcs0 \b\fs40\cf19\insrsid14755898\charrsid14755898 Daily Sales Report }{\rtlch\fcs1 \af0\afs18 \ltr';
    wwv_flow_api.g_varchar2_table(1140) := 'ch\fcs0 \b\fs18\cf19\insrsid6776828 '||wwv_flow.LF||
'\par }\pard \ltrpar\s16\qc \li0\ri0\widctlpar\tqc\tx4680\tqr\t';
    wwv_flow_api.g_varchar2_table(1141) := 'x9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid6776828 {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1142) := 'f0\afs18 \ltrch\fcs0 \b\fs18\cf19\insrsid6776828\charrsid6776828 '||wwv_flow.LF||
'\par }}{\footerr \ltrpar \pard\pl';
    wwv_flow_api.g_varchar2_table(1143) := 'ain \ltrpar\s18\ql \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjus';
    wwv_flow_api.g_varchar2_table(1144) := 'tright\rin0\lin0\itap0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe10';
    wwv_flow_api.g_varchar2_table(1145) := '33\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \fs18\insrsid8723429\charrsid87';
    wwv_flow_api.g_varchar2_table(1146) := '23429 Developed By: Kazi Oliur Rahman}{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8723429 \tab Page }{\fie';
    wwv_flow_api.g_varchar2_table(1147) := 'ld{\*\fldinst {'||wwv_flow.LF||
'\rtlch\fcs1 \ab\af0 \ltrch\fcs0 \b\insrsid8723429  PAGE }}{\fldrslt {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1148) := 'b\af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid7297683 1}}}\sectd \ltrsect\linex0\endnhere\';
    wwv_flow_api.g_varchar2_table(1149) := 'sectdefaultcl\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8723429  of }'||wwv_flow.LF||
'{\field{\*\fldinst {\rtlch';
    wwv_flow_api.g_varchar2_table(1150) := '\fcs1 \ab\af0 \ltrch\fcs0 \b\insrsid8723429  NUMPAGES  }}{\fldrslt {\rtlch\fcs1 \ab\af0 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(1151) := '\b\lang1024\langfe1024\noproof\insrsid7297683 1}}}\sectd \ltrsect\linex0\endnhere\sectdefaultcl\sftn';
    wwv_flow_api.g_varchar2_table(1152) := 'bj {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \insrsid8723429 '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par }}{\*\pnseclvl1\pnucrm\pnstart1\pni';
    wwv_flow_api.g_varchar2_table(1153) := 'ndent720\pnhang {\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnsecl';
    wwv_flow_api.g_varchar2_table(1154) := 'vl3\pndec\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang ';
    wwv_flow_api.g_varchar2_table(1155) := '{\pntxta )}}'||wwv_flow.LF||
'{\*\pnseclvl5\pndec\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl6\p';
    wwv_flow_api.g_varchar2_table(1156) := 'nlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\';
    wwv_flow_api.g_varchar2_table(1157) := 'pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl8'||wwv_flow.LF||
'\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxt';
    wwv_flow_api.g_varchar2_table(1158) := 'a )}}{\*\pnseclvl9\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}\pard\plain \ltrpar'||wwv_flow.LF||
'\q';
    wwv_flow_api.g_varchar2_table(1159) := 'j \li0\ri0\sa200\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid36';
    wwv_flow_api.g_varchar2_table(1160) := '74752 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033';
    wwv_flow_api.g_varchar2_table(1161) := '\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid13575715\charrsid13575715 Date:}{';
    wwv_flow_api.g_varchar2_table(1162) := '\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid13575715  {\*\bkmkstart Text1}}{\field\flddirty{\*';
    wwv_flow_api.g_varchar2_table(1163) := '\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid13575715\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \';
    wwv_flow_api.g_varchar2_table(1164) := 'af0 '||wwv_flow.LF||
'\ltrch\fcs0 \b\insrsid13575715\charrsid10036636 {\*\datafield 8001000000000000055465787431000a';
    wwv_flow_api.g_varchar2_table(1165) := '4f524445525f4441544500000000000e3c3f4f524445525f444154453f3e0000000000}{\*\formfield{\fftype0\ffownh';
    wwv_flow_api.g_varchar2_table(1166) := 'elp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext '||wwv_flow.LF||
'ORDER_DATE}{\*\ffstattext <?ORDER_DATE?>}}}';
    wwv_flow_api.g_varchar2_table(1167) := '}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid13575715\charrsid100';
    wwv_flow_api.g_varchar2_table(1168) := '36636 ORDER_DATE}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrs';
    wwv_flow_api.g_varchar2_table(1169) := 'id6776828\sftnbj {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid4291205 {\*\bkmkend Text1}'||wwv_flow.LF||
'\par';
    wwv_flow_api.g_varchar2_table(1170) := ' \ltrrow}\trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trrh432\trleft-108\trhdr\trbrdrt\brdrs\brdrw1';
    wwv_flow_api.g_varchar2_table(1171) := '0 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrd';
    wwv_flow_api.g_varchar2_table(1172) := 'rv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3';
    wwv_flow_api.g_varchar2_table(1173) := '\trpaddft3\trpaddfb3\trpaddfr3\tblrsid10036636\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tbli';
    wwv_flow_api.g_varchar2_table(1174) := 'ndtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\br';
    wwv_flow_api.g_varchar2_table(1175) := 'drs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth4068\clcbpatraw17 \cellx3960\clvertalc\clbrdrt\b';
    wwv_flow_api.g_varchar2_table(1176) := 'rdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxl';
    wwv_flow_api.g_varchar2_table(1177) := 'rtb\clftsWidth3\clwWidth1440\clcbpatraw17 \cellx5400\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\';
    wwv_flow_api.g_varchar2_table(1178) := 'brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1800\c';
    wwv_flow_api.g_varchar2_table(1179) := 'lcbpatraw17 \cellx7200\clvertalc'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(1180) := '10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2268\clcbpatraw17 \cellx9468\pard\';
    wwv_flow_api.g_varchar2_table(1181) := 'plain \ltrpar'||wwv_flow.LF||
'\qc \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0';
    wwv_flow_api.g_varchar2_table(1182) := '\pararsid10036636\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe103';
    wwv_flow_api.g_varchar2_table(1183) := '3\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid3674752 Food Me';
    wwv_flow_api.g_varchar2_table(1184) := 'nu Name}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid3674752\charrsid3674752 \cell }{\rtlch\fc';
    wwv_flow_api.g_varchar2_table(1185) := 's1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid3674752 Quantity}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\f';
    wwv_flow_api.g_varchar2_table(1186) := 's24\insrsid3674752\charrsid3674752 \cell }{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid3674752';
    wwv_flow_api.g_varchar2_table(1187) := ' Price}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid3674752\charrsid3674752 \cell }{\rtlch\fcs';
    wwv_flow_api.g_varchar2_table(1188) := '1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid3674752 '||wwv_flow.LF||
'Unit Total}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\';
    wwv_flow_api.g_varchar2_table(1189) := 'fs24\insrsid3674752\charrsid3674752 \cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widct';
    wwv_flow_api.g_varchar2_table(1190) := 'lpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025';
    wwv_flow_api.g_varchar2_table(1191) := ' '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs2';
    wwv_flow_api.g_varchar2_table(1192) := '4 \ltrch\fcs0 \b\fs24\insrsid3674752 \trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trrh432\trleft-10';
    wwv_flow_api.g_varchar2_table(1193) := '8\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10';
    wwv_flow_api.g_varchar2_table(1194) := ' \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\t';
    wwv_flow_api.g_varchar2_table(1195) := 'rpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid10036636\tbllkhdrrows\tbllkhdrco';
    wwv_flow_api.g_varchar2_table(1196) := 'ls\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrd';
    wwv_flow_api.g_varchar2_table(1197) := 'rb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth4068\clcbpatraw17 ';
    wwv_flow_api.g_varchar2_table(1198) := '\cellx3960\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\br';
    wwv_flow_api.g_varchar2_table(1199) := 'drs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1440\clcbpatraw17 \cellx5400\clvertalc\clbrdrt';
    wwv_flow_api.g_varchar2_table(1200) := '\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxl';
    wwv_flow_api.g_varchar2_table(1201) := 'rtb\clftsWidth3\clwWidth1800\clcbpatraw17 \cellx7200\clvertalc'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdr';
    wwv_flow_api.g_varchar2_table(1202) := 's\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2268';
    wwv_flow_api.g_varchar2_table(1203) := '\clcbpatraw17 \cellx9468\row \ltrrow}\trowd \irow1\irowband1\ltrrow\ts15\trgaph108\trrh346\trleft-10';
    wwv_flow_api.g_varchar2_table(1204) := '8\trbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbr';
    wwv_flow_api.g_varchar2_table(1205) := 'drh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl';
    wwv_flow_api.g_varchar2_table(1206) := '108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid8811083\tbllkhdrrows\tbllkhdrcols\tbll';
    wwv_flow_api.g_varchar2_table(1207) := 'knocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\br';
    wwv_flow_api.g_varchar2_table(1208) := 'drs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth4068\clshdrawnil \cellx3960\clverta';
    wwv_flow_api.g_varchar2_table(1209) := 'lc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxl';
    wwv_flow_api.g_varchar2_table(1210) := 'rtb\clftsWidth3\clwWidth1440\clshdrawnil \cellx5400'||wwv_flow.LF||
'\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs';
    wwv_flow_api.g_varchar2_table(1211) := '\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1800\clshdrawni';
    wwv_flow_api.g_varchar2_table(1212) := 'l \cellx7200\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr';
    wwv_flow_api.g_varchar2_table(1213) := ''||wwv_flow.LF||
'\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2268\clshdrawnil \cellx9468\pard\plain \ltrpar\ql \li0';
    wwv_flow_api.g_varchar2_table(1214) := '\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid8811083\yts15 ';
    wwv_flow_api.g_varchar2_table(1215) := '\rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\lan';
    wwv_flow_api.g_varchar2_table(1216) := 'gfenp1033 {\*\bkmkstart Text2}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid';
    wwv_flow_api.g_varchar2_table(1217) := '3674752\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\insrsid3674752\charrsid1003';
    wwv_flow_api.g_varchar2_table(1218) := '6636 {\*\datafield 8001000000000000055465787432000246200000000000183c3f666f722d656163683a524f5753455';
    wwv_flow_api.g_varchar2_table(1219) := '4335f524f573f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\';
    wwv_flow_api.g_varchar2_table(1220) := 'ffdeftext F }'||wwv_flow.LF||
'{\*\ffstattext <?for-each:ROWSET3_ROW?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \';
    wwv_flow_api.g_varchar2_table(1221) := 'cf9\lang1024\langfe1024\noproof\insrsid3674752\charrsid10036636 F }}}\sectd \ltrsect\linex0\headery4';
    wwv_flow_api.g_varchar2_table(1222) := '32\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj '||wwv_flow.LF||
'{\*\bkmkstart Text3}{\*\bkmkend T';
    wwv_flow_api.g_varchar2_table(1223) := 'ext2}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636  FOR';
    wwv_flow_api.g_varchar2_table(1224) := 'MTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636 {\*\datafield '||wwv_flow.LF||
'80010000000000';
    wwv_flow_api.g_varchar2_table(1225) := '00055465787433000e464f4f445f4d454e555f4e414d450000000000123c3f464f4f445f4d454e555f4e414d453f3e000000';
    wwv_flow_api.g_varchar2_table(1226) := '0000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text3}{\*\ffdeftext FOOD_MENU_N';
    wwv_flow_api.g_varchar2_table(1227) := 'AME}{\*\ffstattext <?FOOD_MENU_NAME?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe';
    wwv_flow_api.g_varchar2_table(1228) := '1024\noproof\insrsid3674752\charrsid10036636 FOOD_MENU_NAME}}}\sectd \ltrsect\linex0\headery432\endn';
    wwv_flow_api.g_varchar2_table(1229) := 'here\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid36';
    wwv_flow_api.g_varchar2_table(1230) := '74752\charrsid10036636 {\*\bkmkend Text3}\cell }\pard \ltrpar\qc \li0\ri0\widctlpar\intbl\wrapdefaul';
    wwv_flow_api.g_varchar2_table(1231) := 't\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid8811083\yts15 {\*\bkmkstart Text4}{\field\fld';
    wwv_flow_api.g_varchar2_table(1232) := 'dirty{\*\fldinst {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \insrsid3674752\charrsid10036636  FORMTEXT }{\rtlch';
    wwv_flow_api.g_varchar2_table(1233) := '\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636 {\*\datafield 800100000000000005546578743400';
    wwv_flow_api.g_varchar2_table(1234) := '085155414e5449545900000000000c3c3f5155414e544954593f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\';
    wwv_flow_api.g_varchar2_table(1235) := 'ffownstat\fftypetxt0{\*\ffname Text4}{\*\ffdeftext QUANTITY}{\*\ffstattext <?QUANTITY?>}}}}}{\fldrsl';
    wwv_flow_api.g_varchar2_table(1236) := 't {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid3674752\charrsid10036636 QUANTIT';
    wwv_flow_api.g_varchar2_table(1237) := 'Y}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnb';
    wwv_flow_api.g_varchar2_table(1238) := 'j {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636 {\*\bkmkend Text4}\cell }\pard \ltr';
    wwv_flow_api.g_varchar2_table(1239) := 'par'||wwv_flow.LF||
'\qr \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid1';
    wwv_flow_api.g_varchar2_table(1240) := '0036636\yts15 {\*\bkmkstart Text5}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid';
    wwv_flow_api.g_varchar2_table(1241) := '3674752\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \insrsid3674752\charrsid10036636';
    wwv_flow_api.g_varchar2_table(1242) := ' {\*\datafield 8001000000000000055465787435000550524943450000000000093c3f50524943453f3e0000000000}{\';
    wwv_flow_api.g_varchar2_table(1243) := '*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text5}{\*\ffdeftext PRICE}{\*\ffstatte';
    wwv_flow_api.g_varchar2_table(1244) := 'xt '||wwv_flow.LF||
'<?PRICE?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid36747';
    wwv_flow_api.g_varchar2_table(1245) := '52\charrsid10036636 PRICE}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl';
    wwv_flow_api.g_varchar2_table(1246) := '\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid3674752\charrsid10036636 {\*\bkmkend';
    wwv_flow_api.g_varchar2_table(1247) := ' Text5}\cell {\*\bkmkstart Text6}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid';
    wwv_flow_api.g_varchar2_table(1248) := '3674752\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636 ';
    wwv_flow_api.g_varchar2_table(1249) := ''||wwv_flow.LF||
'{\*\datafield 8001000000000000055465787436000a554e49545f544f54414c00000000000e3c3f554e49545f544f544';
    wwv_flow_api.g_varchar2_table(1250) := '14c3f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftex';
    wwv_flow_api.g_varchar2_table(1251) := 't UNIT_TOTAL}{\*\ffstattext <?UNIT_TOTAL?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\l';
    wwv_flow_api.g_varchar2_table(1252) := 'angfe1024\noproof\insrsid3674752\charrsid10036636 UNIT_TOTAL}}}\sectd \ltrsect\linex0\headery432\end';
    wwv_flow_api.g_varchar2_table(1253) := 'nhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {\*\bkmkstart Text7}{\*\bkmkend Text6}'||wwv_flow.LF||
'{';
    wwv_flow_api.g_varchar2_table(1254) := '\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid3674752\charrsid10036636  FORMT';
    wwv_flow_api.g_varchar2_table(1255) := 'EXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid3674752\charrsid10036636 {\*\datafield '||wwv_flow.LF||
'800100000000';
    wwv_flow_api.g_varchar2_table(1256) := '0000055465787437000220450000000000103c3f656e6420666f722d656163683f3e0000000000}{\*\formfield{\fftype';
    wwv_flow_api.g_varchar2_table(1257) := '0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text7}{\*\ffdeftext  E}{\*\ffstattext <?end for-each?>}}}';
    wwv_flow_api.g_varchar2_table(1258) := '}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\lang1024\langfe1024\noproof\insrsid3674752\charrsid';
    wwv_flow_api.g_varchar2_table(1259) := '10036636  E}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid67768';
    wwv_flow_api.g_varchar2_table(1260) := '28\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3674752\charrsid10036636 {\*\bkmkend Text7}\cell '||wwv_flow.LF||
'}';
    wwv_flow_api.g_varchar2_table(1261) := '\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faau';
    wwv_flow_api.g_varchar2_table(1262) := 'to\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe10';
    wwv_flow_api.g_varchar2_table(1263) := '33\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \insrsid3674752\charrsid10036636 \t';
    wwv_flow_api.g_varchar2_table(1264) := 'rowd \irow1\irowband1\ltrrow\ts15\trgaph108\trrh346\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\';
    wwv_flow_api.g_varchar2_table(1265) := 'brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 ';
    wwv_flow_api.g_varchar2_table(1266) := ''||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpadd';
    wwv_flow_api.g_varchar2_table(1267) := 'fb3\trpaddfr3\tblrsid8811083\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc';
    wwv_flow_api.g_varchar2_table(1268) := '\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxl';
    wwv_flow_api.g_varchar2_table(1269) := 'rtb\clftsWidth3\clwWidth4068\clshdrawnil \cellx3960\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\b';
    wwv_flow_api.g_varchar2_table(1270) := 'rdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1440\clshdrawnil ';
    wwv_flow_api.g_varchar2_table(1271) := '\cellx5400'||wwv_flow.LF||
'\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\';
    wwv_flow_api.g_varchar2_table(1272) := 'brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1800\clshdrawnil \cellx7200\clvertalc\clbrdrt\brdrs\brdr';
    wwv_flow_api.g_varchar2_table(1273) := 'w10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clw';
    wwv_flow_api.g_varchar2_table(1274) := 'Width2268\clshdrawnil \cellx9468\row \ltrrow}\trowd \irow2\irowband2\ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432';
    wwv_flow_api.g_varchar2_table(1275) := '\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddf';
    wwv_flow_api.g_varchar2_table(1276) := 't3\trpaddfb3\trpaddfr3\tblrsid9524954\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \';
    wwv_flow_api.g_varchar2_table(1277) := 'clvertalc\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3';
    wwv_flow_api.g_varchar2_table(1278) := '\clwWidth7488\clshdrawnil \cellx7380\clvertalc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \cl';
    wwv_flow_api.g_varchar2_table(1279) := 'brdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2088\clshdrawnil \cellx9468'||wwv_flow.LF||
'\pard\plain \ltrpar\qr \li0';
    wwv_flow_api.g_varchar2_table(1280) := '\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid10036636\yts15';
    wwv_flow_api.g_varchar2_table(1281) := ' \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\lang';
    wwv_flow_api.g_varchar2_table(1282) := 'fenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af0\afs24 \ltrch\fcs0 \b\fs24\insrsid10036636 Gross Sales:\cell {\*\bkmksta';
    wwv_flow_api.g_varchar2_table(1283) := 'rt Text8}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid10036';
    wwv_flow_api.g_varchar2_table(1284) := '636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid10036636 {\*\datafield 800';
    wwv_flow_api.g_varchar2_table(1285) := '1000000000000055465787438000b544f54414c5f505249434500000000000f3c3f544f54414c5f50524943453f3e0000000';
    wwv_flow_api.g_varchar2_table(1286) := '000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text8}{\*\ffdeftext TOTAL_PRICE}';
    wwv_flow_api.g_varchar2_table(1287) := ''||wwv_flow.LF||
'{\*\ffstattext <?TOTAL_PRICE?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\';
    wwv_flow_api.g_varchar2_table(1288) := 'noproof\insrsid10036636\charrsid10036636 TOTAL_PRICE}}}\sectd \ltrsect\linex0\headery432\endnhere\se';
    wwv_flow_api.g_varchar2_table(1289) := 'ctlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid1003663';
    wwv_flow_api.g_varchar2_table(1290) := '6\charrsid10036636 {\*\bkmkend Text8}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widc';
    wwv_flow_api.g_varchar2_table(1291) := 'tlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang102';
    wwv_flow_api.g_varchar2_table(1292) := '5 '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs';
    wwv_flow_api.g_varchar2_table(1293) := '24 \ltrch\fcs0 \b\fs24\insrsid10036636 \trowd \irow2\irowband2\ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432\trlef';
    wwv_flow_api.g_varchar2_table(1294) := 't-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trp';
    wwv_flow_api.g_varchar2_table(1295) := 'addfb3\trpaddfr3\tblrsid9524954\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvert';
    wwv_flow_api.g_varchar2_table(1296) := 'alc\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_api.g_varchar2_table(1297) := 'dth7488\clshdrawnil \cellx7380\clvertalc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\';
    wwv_flow_api.g_varchar2_table(1298) := 'brdrtbl \cltxlrtb\clftsWidth3\clwWidth2088\clshdrawnil \cellx9468\row \ltrrow'||wwv_flow.LF||
'}\pard\plain \ltrpar\';
    wwv_flow_api.g_varchar2_table(1299) := 'qr \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid1003663';
    wwv_flow_api.g_varchar2_table(1300) := '6\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp10';
    wwv_flow_api.g_varchar2_table(1301) := '33\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af0\afs24 \ltrch\fcs0 \b\fs24\insrsid10036636 Discount:\cell {\*\bkm';
    wwv_flow_api.g_varchar2_table(1302) := 'kstart Text9}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid1';
    wwv_flow_api.g_varchar2_table(1303) := '0036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid10036636 '||wwv_flow.LF||
'{\*\datafield';
    wwv_flow_api.g_varchar2_table(1304) := ' 80010000000000000554657874390008444953434f554e5400000000000c3c3f444953434f554e543f3e0000000000}{\*\';
    wwv_flow_api.g_varchar2_table(1305) := 'formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text9}{\*\ffdeftext DISCOUNT}{\*\ffstatt';
    wwv_flow_api.g_varchar2_table(1306) := 'ext <?DISCOUNT?>}}}}}{\fldrslt {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsi';
    wwv_flow_api.g_varchar2_table(1307) := 'd10036636\charrsid10036636 DISCOUNT}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sec';
    wwv_flow_api.g_varchar2_table(1308) := 'tdefaultcl\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid1003663';
    wwv_flow_api.g_varchar2_table(1309) := '6 {\*\bkmkend Text9}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapd';
    wwv_flow_api.g_varchar2_table(1310) := 'efault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(1311) := 'f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b';
    wwv_flow_api.g_varchar2_table(1312) := '\fs24\insrsid10036636 \trowd \irow3\irowband3\ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432\trleft-108\trftsWidth1';
    wwv_flow_api.g_varchar2_table(1313) := '\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\';
    wwv_flow_api.g_varchar2_table(1314) := 'tblrsid9524954\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrt';
    wwv_flow_api.g_varchar2_table(1315) := 'bl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth7488\clshdrawn';
    wwv_flow_api.g_varchar2_table(1316) := 'il \cellx7380\clvertalc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb';
    wwv_flow_api.g_varchar2_table(1317) := '\clftsWidth3\clwWidth2088\clshdrawnil \cellx9468\row \ltrrow'||wwv_flow.LF||
'}\pard\plain \ltrpar\qr \li0\ri0\widct';
    wwv_flow_api.g_varchar2_table(1318) := 'lpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid10036636\yts15 \rtlch\fc';
    wwv_flow_api.g_varchar2_table(1319) := 's1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {';
    wwv_flow_api.g_varchar2_table(1320) := '\rtlch\fcs1 '||wwv_flow.LF||
'\af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid10036636\charrsid9704800 Net Sales:\cell {\';
    wwv_flow_api.g_varchar2_table(1321) := '*\bkmkstart Text10}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\cha';
    wwv_flow_api.g_varchar2_table(1322) := 'rrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid10036636 {\*\dat';
    wwv_flow_api.g_varchar2_table(1323) := 'afield 80010000000000000654657874313000094e45545f53414c455300000000000d3c3f4e45545f53414c45533f3e000';
    wwv_flow_api.g_varchar2_table(1324) := '0000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text10}{\*\ffdeftext NET_SAL';
    wwv_flow_api.g_varchar2_table(1325) := 'ES}'||wwv_flow.LF||
'{\*\ffstattext <?NET_SALES?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024';
    wwv_flow_api.g_varchar2_table(1326) := '\noproof\insrsid10036636\charrsid10036636 NET_SALES}}}\sectd \ltrsect\linex0\headery432\endnhere\sec';
    wwv_flow_api.g_varchar2_table(1327) := 'tlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636';
    wwv_flow_api.g_varchar2_table(1328) := '\charrsid10036636 {\*\bkmkend Text10}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widc';
    wwv_flow_api.g_varchar2_table(1329) := 'tlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang102';
    wwv_flow_api.g_varchar2_table(1330) := '5 '||wwv_flow.LF||
'\ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs';
    wwv_flow_api.g_varchar2_table(1331) := '24 \ltrch\fcs0 \b\fs24\insrsid10036636 \trowd \irow4\irowband4\ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432\trlef';
    wwv_flow_api.g_varchar2_table(1332) := 't-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trp';
    wwv_flow_api.g_varchar2_table(1333) := 'addfb3\trpaddfr3\tblrsid9524954\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvert';
    wwv_flow_api.g_varchar2_table(1334) := 'alc\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_api.g_varchar2_table(1335) := 'dth7488\clshdrawnil \cellx7380\clvertalc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\';
    wwv_flow_api.g_varchar2_table(1336) := 'brdrtbl \cltxlrtb\clftsWidth3\clwWidth2088\clshdrawnil \cellx9468\row \ltrrow'||wwv_flow.LF||
'}\pard\plain \ltrpar\';
    wwv_flow_api.g_varchar2_table(1337) := 'qr \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid1003663';
    wwv_flow_api.g_varchar2_table(1338) := '6\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp10';
    wwv_flow_api.g_varchar2_table(1339) := '33\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af0\afs24 \ltrch\fcs0 \b\fs24\insrsid10036636 Vat Received:\cell {\*';
    wwv_flow_api.g_varchar2_table(1340) := '\bkmkstart Text11}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\char';
    wwv_flow_api.g_varchar2_table(1341) := 'rsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid10036636 {\*\data';
    wwv_flow_api.g_varchar2_table(1342) := 'field 80010000000000000654657874313100035641540000000000073c3f5641543f3e0000000000}{\*\formfield{\ff';
    wwv_flow_api.g_varchar2_table(1343) := 'type0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text11}{\*\ffdeftext VAT}{\*\ffstattext <?VAT?>}}}}}{';
    wwv_flow_api.g_varchar2_table(1344) := '\fldrslt {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid10036636\charrsid1003';
    wwv_flow_api.g_varchar2_table(1345) := '6636 VAT}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\';
    wwv_flow_api.g_varchar2_table(1346) := 'sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid10036636 {\*\bkmkend Text11}\cell ';
    wwv_flow_api.g_varchar2_table(1347) := '}\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faa';
    wwv_flow_api.g_varchar2_table(1348) := 'uto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langf';
    wwv_flow_api.g_varchar2_table(1349) := 'e1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid10036636 \tro';
    wwv_flow_api.g_varchar2_table(1350) := 'wd \irow5\irowband5\ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3';
    wwv_flow_api.g_varchar2_table(1351) := '\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid9524954\tbllkhdrrow';
    wwv_flow_api.g_varchar2_table(1352) := 's\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clb';
    wwv_flow_api.g_varchar2_table(1353) := 'rdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth7488\clshdrawnil \cellx7380\clvertalc\cl';
    wwv_flow_api.g_varchar2_table(1354) := 'brdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2088\';
    wwv_flow_api.g_varchar2_table(1355) := 'clshdrawnil \cellx9468\row \ltrrow'||wwv_flow.LF||
'}\pard\plain \ltrpar\qr \li0\ri0\widctlpar\intbl\wrapdefault\asp';
    wwv_flow_api.g_varchar2_table(1356) := 'alpha\aspnum\faauto\adjustright\rin0\lin0\pararsid10036636\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \l';
    wwv_flow_api.g_varchar2_table(1357) := 'trch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 '||wwv_flow.LF||
'\af0\afs24 \';
    wwv_flow_api.g_varchar2_table(1358) := 'ltrch\fcs0 \b\fs24\insrsid10036636 Gross Received:\cell {\*\bkmkstart Text12}}{\field\flddirty{\*\fl';
    wwv_flow_api.g_varchar2_table(1359) := 'dinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0';
    wwv_flow_api.g_varchar2_table(1360) := ' \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid10036636\charrsid10036636 {\*\datafield 800100000000000006546578743132000e4';
    wwv_flow_api.g_varchar2_table(1361) := '7524f53535f52454345495645440000000000123c3f47524f53535f52454345495645443f3e0000000000}{\*\formfield{';
    wwv_flow_api.g_varchar2_table(1362) := '\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text12}'||wwv_flow.LF||
'{\*\ffdeftext GROSS_RECEIVED}{\*\ffstatte';
    wwv_flow_api.g_varchar2_table(1363) := 'xt <?GROSS_RECEIVED?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\ins';
    wwv_flow_api.g_varchar2_table(1364) := 'rsid10036636\charrsid10036636 GROSS_RECEIVED}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\headery432\endnhere\sectline';
    wwv_flow_api.g_varchar2_table(1365) := 'grid360\sectdefaultcl\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrs';
    wwv_flow_api.g_varchar2_table(1366) := 'id10036636 {\*\bkmkend Text12}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar';
    wwv_flow_api.g_varchar2_table(1367) := '\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \lt';
    wwv_flow_api.g_varchar2_table(1368) := 'rch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltr';
    wwv_flow_api.g_varchar2_table(1369) := 'ch\fcs0 \b\fs24\insrsid10036636 '||wwv_flow.LF||
'\trowd \irow6\irowband6\ltrrow\ts15\trgaph108\trrh432\trleft-108\t';
    wwv_flow_api.g_varchar2_table(1370) := 'rftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\';
    wwv_flow_api.g_varchar2_table(1371) := 'trpaddfr3\tblrsid9524954\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 '||wwv_flow.LF||
'\clvertalc\c';
    wwv_flow_api.g_varchar2_table(1372) := 'lbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth7488';
    wwv_flow_api.g_varchar2_table(1373) := '\clshdrawnil \cellx7380\clvertalc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl';
    wwv_flow_api.g_varchar2_table(1374) := ' '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2088\clshdrawnil \cellx9468\row \ltrrow}\pard\plain \ltrpar\qr \li0';
    wwv_flow_api.g_varchar2_table(1375) := '\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid10036636\yts15';
    wwv_flow_api.g_varchar2_table(1376) := ' \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\la';
    wwv_flow_api.g_varchar2_table(1377) := 'ngfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid10036636\charrsid9704800 Cash to ';
    wwv_flow_api.g_varchar2_table(1378) := 'Account:\cell {\*\bkmkstart Text13}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\i';
    wwv_flow_api.g_varchar2_table(1379) := 'nsrsid10036636\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid';
    wwv_flow_api.g_varchar2_table(1380) := '10036636 {\*\datafield 800100000000000006546578743133000e47524f53535f52454345495645440000000000123c3';
    wwv_flow_api.g_varchar2_table(1381) := 'f47524f53535f52454345495645443f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{';
    wwv_flow_api.g_varchar2_table(1382) := '\*\ffname Text13}{\*\ffdeftext GROSS_RECEIVED}{\*\ffstattext <?GROSS_RECEIVED?>}}}}}{\fldrslt {\rtlc';
    wwv_flow_api.g_varchar2_table(1383) := 'h\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid10036636\charrsid10036636 '||wwv_flow.LF||
'GROSS_RECE';
    wwv_flow_api.g_varchar2_table(1384) := 'IVED}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftn';
    wwv_flow_api.g_varchar2_table(1385) := 'bj {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid10036636\charrsid10036636 {\*\bkmkend Text13}\cell }\pard';
    wwv_flow_api.g_varchar2_table(1386) := '\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\';
    wwv_flow_api.g_varchar2_table(1387) := 'adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\';
    wwv_flow_api.g_varchar2_table(1388) := 'cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid10036636 \trowd \';
    wwv_flow_api.g_varchar2_table(1389) := 'irow7\irowband7\lastrow \ltrrow'||wwv_flow.LF||
'\ts15\trgaph108\trrh432\trleft-108\trftsWidth1\trftsWidthB3\trftsWi';
    wwv_flow_api.g_varchar2_table(1390) := 'dthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid9524954\tbllkh';
    wwv_flow_api.g_varchar2_table(1391) := 'drrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl';
    wwv_flow_api.g_varchar2_table(1392) := ' \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth7488\clshdrawnil \cellx7380\clverta';
    wwv_flow_api.g_varchar2_table(1393) := 'lc\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth';
    wwv_flow_api.g_varchar2_table(1394) := '2088\clshdrawnil \cellx9468\row '||wwv_flow.LF||
'}\pard \ltrpar\qc \li0\ri0\sa200\widctlpar\wrapdefault\aspalpha\as';
    wwv_flow_api.g_varchar2_table(1395) := 'pnum\faauto\adjustright\rin0\lin0\itap0\pararsid5922837 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\';
    wwv_flow_api.g_varchar2_table(1396) := 'insrsid10036636 '||wwv_flow.LF||
'\par }\pard \ltrpar\qc \fi720\li0\ri0\sa200\widctlpar\wrapdefault\aspalpha\aspnum\';
    wwv_flow_api.g_varchar2_table(1397) := 'faauto\adjustright\rin0\lin0\itap0\pararsid5922837 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrs';
    wwv_flow_api.g_varchar2_table(1398) := 'id10036636 Settlement'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trrh432\trleft2052';
    wwv_flow_api.g_varchar2_table(1399) := '\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \t';
    wwv_flow_api.g_varchar2_table(1400) := 'rbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpa';
    wwv_flow_api.g_varchar2_table(1401) := 'ddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid7297683\tbllkhdrrows\tbllkhdrcols\t';
    wwv_flow_api.g_varchar2_table(1402) := 'bllknocolband\tblind2160\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdr';
    wwv_flow_api.g_varchar2_table(1403) := 'b'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2808\clcbpatraw17 \';
    wwv_flow_api.g_varchar2_table(1404) := 'cellx4860\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brd';
    wwv_flow_api.g_varchar2_table(1405) := 'rs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2232\clcbpatraw17 \cellx7092\pard\plain \ltrpar';
    wwv_flow_api.g_varchar2_table(1406) := '\qc \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid729768';
    wwv_flow_api.g_varchar2_table(1407) := '3\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp';
    wwv_flow_api.g_varchar2_table(1408) := '1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683 Payment Mode}{\rtlch\fcs1 \af0 \lt';
    wwv_flow_api.g_varchar2_table(1409) := 'rch\fcs0 \b\insrsid7297683\charrsid7297683 \cell }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683 To';
    wwv_flow_api.g_varchar2_table(1410) := 'tal Amount'||wwv_flow.LF||
'}{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683\charrsid7297683 \cell }\pard\plain \ltr';
    wwv_flow_api.g_varchar2_table(1411) := 'par\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\r';
    wwv_flow_api.g_varchar2_table(1412) := 'in0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langn';
    wwv_flow_api.g_varchar2_table(1413) := 'p1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683 \trowd \irow0\irowband0\ltrrow\ts';
    wwv_flow_api.g_varchar2_table(1414) := '15\trgaph108\trrh432\trleft2052\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\br';
    wwv_flow_api.g_varchar2_table(1415) := 'drw10 '||wwv_flow.LF||
'\trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWid';
    wwv_flow_api.g_varchar2_table(1416) := 'thB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid72';
    wwv_flow_api.g_varchar2_table(1417) := '97683\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind2160\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(1418) := '10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsW';
    wwv_flow_api.g_varchar2_table(1419) := 'idth3\clwWidth2808\clcbpatraw17 \cellx4860\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \c';
    wwv_flow_api.g_varchar2_table(1420) := 'lbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2232\clcbpatra';
    wwv_flow_api.g_varchar2_table(1421) := 'w17 \cellx7092\row \ltrrow}\trowd \irow1\irowband1\lastrow \ltrrow\ts15\trgaph108\trrh346\trleft2052';
    wwv_flow_api.g_varchar2_table(1422) := '\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh';
    wwv_flow_api.g_varchar2_table(1423) := ''||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 \trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108';
    wwv_flow_api.g_varchar2_table(1424) := '\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid7297683\tbllkhdrrows\tbllkhdrcols\tbllkno';
    wwv_flow_api.g_varchar2_table(1425) := 'colband\tblind2160\tblindtype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\br';
    wwv_flow_api.g_varchar2_table(1426) := 'drs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2808\clshdrawnil \cellx4860\clverta';
    wwv_flow_api.g_varchar2_table(1427) := 'lc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clt';
    wwv_flow_api.g_varchar2_table(1428) := 'xlrtb\clftsWidth3\clwWidth2232\clshdrawnil \cellx7092\pard\plain \ltrpar\ql \li0\ri0\widctlpar\intbl';
    wwv_flow_api.g_varchar2_table(1429) := '\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid7297683\yts15 \rtlch\fcs1 \af0\afs';
    wwv_flow_api.g_varchar2_table(1430) := '22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\*\bkmkst';
    wwv_flow_api.g_varchar2_table(1431) := 'art Text14}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf9\insrsid7297683\charrsid7';
    wwv_flow_api.g_varchar2_table(1432) := '297683  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\cf9\insrsid7297683\charrsid7297683 {\*\datafiel';
    wwv_flow_api.g_varchar2_table(1433) := 'd 800100000000000006546578743134000246200000000000183c3f666f722d656163683a524f57534554325f524f573f3e';
    wwv_flow_api.g_varchar2_table(1434) := '0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text14}{\*\ffdeftext F }';
    wwv_flow_api.g_varchar2_table(1435) := ''||wwv_flow.LF||
'{\*\ffstattext <?for-each:ROWSET2_ROW?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf9\lang1024';
    wwv_flow_api.g_varchar2_table(1436) := '\langfe1024\noproof\insrsid7297683\charrsid7297683 F }}}\sectd \ltrsect\linex0\headery432\endnhere\s';
    wwv_flow_api.g_varchar2_table(1437) := 'ectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj '||wwv_flow.LF||
'{\*\bkmkstart Text15}{\*\bkmkend Text14}{\fiel';
    wwv_flow_api.g_varchar2_table(1438) := 'd\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683\charrsid7297683  FORMTEXT }{\r';
    wwv_flow_api.g_varchar2_table(1439) := 'tlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid7297683\charrsid7297683 {\*\datafield '||wwv_flow.LF||
'80010000000000000654657';
    wwv_flow_api.g_varchar2_table(1440) := '8743135000c5041594d454e545f4d4f44450000000000103c3f5041594d454e545f4d4f44453f3e0000000000}{\*\formfi';
    wwv_flow_api.g_varchar2_table(1441) := 'eld{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text15}{\*\ffdeftext PAYMENT_MODE}{\*\ffstatte';
    wwv_flow_api.g_varchar2_table(1442) := 'xt <?PAYMENT_MODE?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\ins';
    wwv_flow_api.g_varchar2_table(1443) := 'rsid7297683\charrsid7297683 PAYMENT_MODE}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid36';
    wwv_flow_api.g_varchar2_table(1444) := '0\sectdefaultcl\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid7297683 {\*\bkmkend';
    wwv_flow_api.g_varchar2_table(1445) := ' Text15}\cell }\pard \ltrpar\qr \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_api.g_varchar2_table(1446) := 'ght\rin0\lin0\pararsid7297683\yts15 {\*\bkmkstart Text16}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1447) := 'f0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid7297683\charrsid7297683  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrs';
    wwv_flow_api.g_varchar2_table(1448) := 'id7297683\charrsid7297683 {\*\datafield 800100000000000006546578743136000c544f54414c5f414d4f554e5400';
    wwv_flow_api.g_varchar2_table(1449) := '00000000103c3f544f54414c5f414d4f554e543f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\ff';
    wwv_flow_api.g_varchar2_table(1450) := 'typetxt0{\*\ffname Text16}{\*\ffdeftext TOTAL_AMOUNT}{\*\ffstattext <?TOTAL_AMOUNT?>}}}}}{\fldrslt {';
    wwv_flow_api.g_varchar2_table(1451) := '\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid7297683\charrsid7297683 TOTAL_AMO';
    wwv_flow_api.g_varchar2_table(1452) := 'UNT}}}'||wwv_flow.LF||
'\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sft';
    wwv_flow_api.g_varchar2_table(1453) := 'nbj {\*\bkmkstart Text17}{\*\bkmkend Text16}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs';
    wwv_flow_api.g_varchar2_table(1454) := '0 \b\cf9\insrsid7297683\charrsid7297683  FORMTEXT }{'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf9\insrsid729';
    wwv_flow_api.g_varchar2_table(1455) := '7683\charrsid7297683 {\*\datafield 800100000000000006546578743137000220450000000000103c3f656e6420666';
    wwv_flow_api.g_varchar2_table(1456) := 'f722d656163683f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text17}';
    wwv_flow_api.g_varchar2_table(1457) := ''||wwv_flow.LF||
'{\*\ffdeftext  E}{\*\ffstattext <?end for-each?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\cf9';
    wwv_flow_api.g_varchar2_table(1458) := '\lang1024\langfe1024\noproof\insrsid7297683\charrsid7297683  E}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\headery432';
    wwv_flow_api.g_varchar2_table(1459) := '\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insr';
    wwv_flow_api.g_varchar2_table(1460) := 'sid7297683 {\*\bkmkend Text17}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar';
    wwv_flow_api.g_varchar2_table(1461) := '\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \lt';
    wwv_flow_api.g_varchar2_table(1462) := 'rch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs';
    wwv_flow_api.g_varchar2_table(1463) := '0 \b\insrsid7297683 '||wwv_flow.LF||
'\trowd \irow1\irowband1\lastrow \ltrrow\ts15\trgaph108\trrh346\trleft2052\trbr';
    wwv_flow_api.g_varchar2_table(1464) := 'drt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdr';
    wwv_flow_api.g_varchar2_table(1465) := 's\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpa';
    wwv_flow_api.g_varchar2_table(1466) := 'ddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid7297683\tbllkhdrrows\tbllkhdrcols\tbllknocolba';
    wwv_flow_api.g_varchar2_table(1467) := 'nd\tblind2160\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\b';
    wwv_flow_api.g_varchar2_table(1468) := 'rdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2808\clshdrawnil \cellx4860\clvertalc\cl';
    wwv_flow_api.g_varchar2_table(1469) := 'brdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\c';
    wwv_flow_api.g_varchar2_table(1470) := 'lftsWidth3\clwWidth2232\clshdrawnil \cellx7092'||wwv_flow.LF||
'\row }\pard \ltrpar\ql \fi720\li2160\ri0\widctlpar\w';
    wwv_flow_api.g_varchar2_table(1471) := 'rapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin2160\itap0\pararsid11543638 {\rtlch\fcs1 \af0 ';
    wwv_flow_api.g_varchar2_table(1472) := '\ltrch\fcs0 \b\insrsid6705959 Total: }{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b';
    wwv_flow_api.g_varchar2_table(1473) := '\insrsid6705959\charrsid10036636  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid6705959\charrsid';
    wwv_flow_api.g_varchar2_table(1474) := '10036636 {\*\datafield 800100000000000006546578743133000e47524f53535f52454345495645440000000000123c3';
    wwv_flow_api.g_varchar2_table(1475) := 'f47524f53535f52454345495645443f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{';
    wwv_flow_api.g_varchar2_table(1476) := '\*\ffname Text13}{\*\ffdeftext GROSS_RECEIVED}{\*\ffstattext <?GROSS_RECEIVED?>}}}}}{\fldrslt {\rtlc';
    wwv_flow_api.g_varchar2_table(1477) := 'h\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid6705959\charrsid10036636 GROSS_RECEIVE';
    wwv_flow_api.g_varchar2_table(1478) := 'D'||wwv_flow.LF||
'}}}\sectd \ltrsect\linex0\headery432\endnhere\sectlinegrid360\sectdefaultcl\sectrsid6776828\sftnb';
    wwv_flow_api.g_varchar2_table(1479) := 'j {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid6705959 '||wwv_flow.LF||
'\par }\pard \ltrpar\qj \li0\ri0\widct';
    wwv_flow_api.g_varchar2_table(1480) := 'lpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8811083 {\rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(1481) := '0\afs24 \ltrch\fcs0 \b\fs24\insrsid9524954 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrs';
    wwv_flow_api.g_varchar2_table(1482) := 'id8811083 '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par }\pard \ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faau';
    wwv_flow_api.g_varchar2_table(1483) := 'to\adjustright\rin0\lin0\itap0\pararsid6705959 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\lang1024\';
    wwv_flow_api.g_varchar2_table(1484) := 'langfe1024\noproof\insrsid9704800 '||wwv_flow.LF||
'{\shp{\*\shpinst\shpleft-420\shptop23\shpright1800\shpbottom68\s';
    wwv_flow_api.g_varchar2_table(1485) := 'hpfhdr0\shpbxcolumn\shpbxignore\shpbypara\shpbyignore\shpwr3\shpwrk0\shpfblwtxt0\shpz0\shplid1027{\s';
    wwv_flow_api.g_varchar2_table(1486) := 'p{\sn shapeType}{\sv 32}}{\sp{\sn fFlipH}{\sv 0}}{\sp{\sn fFlipV}{\sv 0}}'||wwv_flow.LF||
'{\sp{\sn lineColor}{\sv 0';
    wwv_flow_api.g_varchar2_table(1487) := '}{\*\hsv \ctextone\ctint255\cshade255}}{\sp{\sn lineWidth}{\sv 12700}}{\sp{\sn fLine}{\sv 1}}{\sp{\s';
    wwv_flow_api.g_varchar2_table(1488) := 'n shadowType}{\sv 2}}{\sp{\sn shadowColor}{\sv 8355711}{\*\hsv \cmainlightone\ctint255\cshade127}}'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1489) := '{\sp{\sn shadowOpacity}{\sv 32768}}{\sp{\sn shadowOffsetX}{\sv 12700}}{\sp{\sn shadowSecondOffsetX}{';
    wwv_flow_api.g_varchar2_table(1490) := '\sv -12700}}{\sp{\sn f3D}{\sv 0}}{\sp{\sn cxstyle}{\sv 0}}'||wwv_flow.LF||
'{\sp{\sn dhgt}{\sv 251658240}}{\sp{\sn f';
    wwv_flow_api.g_varchar2_table(1491) := 'LayoutInCell}{\sv 1}}}{\shprslt{\*\do\dobxcolumn\dobypara\dodhgt8192\dppolyline\dppolycount2\dpptx0\';
    wwv_flow_api.g_varchar2_table(1492) := 'dppty0\dpptx2220\dppty45\dpx-420\dpy23\dpxsize2220\dpysize45'||wwv_flow.LF||
'\dpfillfgcr255\dpfillfgcg255\dpfillfgc';
    wwv_flow_api.g_varchar2_table(1493) := 'b255\dpfillbgcr255\dpfillbgcg255\dpfillbgcb255\dpfillpat0\dplinew20\dplinecor141\dplinecog12\dplinec';
    wwv_flow_api.g_varchar2_table(1494) := 'ob0}}}}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8723429\charrsid4291205 Signature}{\rtlch\';
    wwv_flow_api.g_varchar2_table(1495) := 'fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \b\insrsid4291205\charrsid4291205 '||wwv_flow.LF||
'\par }{\*\themedata 504b0304140006000800';
    wwv_flow_api.g_varchar2_table(1496) := '00002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc';
    wwv_flow_api.g_varchar2_table(1497) := '83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3';
    wwv_flow_api.g_varchar2_table(1498) := '989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d';
    wwv_flow_api.g_varchar2_table(1499) := '8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f36';
    wwv_flow_api.g_varchar2_table(1500) := '4eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(1501) := '0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b';
    wwv_flow_api.g_varchar2_table(1502) := '030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85';
    wwv_flow_api.g_varchar2_table(1503) := 'bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e72016';
    wwv_flow_api.g_varchar2_table(1504) := '9aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc';
    wwv_flow_api.g_varchar2_table(1505) := '52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce5';
    wwv_flow_api.g_varchar2_table(1506) := '45046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b';
    wwv_flow_api.g_varchar2_table(1507) := '799616830000008a0000001c0000007468656d652f746865'||wwv_flow.LF||
'6d652f7468656d654d616e616765722e786d6c0ccc4d0ac320';
    wwv_flow_api.g_varchar2_table(1508) := '1040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd';
    wwv_flow_api.g_varchar2_table(1509) := '2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9';
    wwv_flow_api.g_varchar2_table(1510) := '246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ffff0300504b03041400060008000000210030dd4329a8060000a4';
    wwv_flow_api.g_varchar2_table(1511) := '1b0000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d65312e786d6cec594f6fdb3614bf0fd87720746f6327761a0775';
    wwv_flow_api.g_varchar2_table(1512) := '8ad8b19b2d4d1bc46e871e698996d850a240d2497d1bdae38001c3ba618715d86d87'||wwv_flow.LF||
'615b8116d8a5fb34d93a6c1dd0afb0';
    wwv_flow_api.g_varchar2_table(1513) := '475292c5585e9236d88aad3e2412f9e3fbff1e1fa9abd7eec70c1d1221294fda5efd72cd4324f1794093b0eddd1ef62fad'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1514) := '79482a9c0498f184b4bd2991deb58df7dfbb8ad755446282607d22d771db8b944ad79796a40fc3585ee62949606ecc458c15';
    wwv_flow_api.g_varchar2_table(1515) := 'bc8a702910f808e8c66c69b9565b'||wwv_flow.LF||
'5d8a314d3c94e018c8de1a8fa94fd05093f43672e23d06af89927ac06762a049136785';
    wwv_flow_api.g_varchar2_table(1516) := 'c10607758d9053d965021d62d6f6804fc08f86e4bef210c352c144dbab'||wwv_flow.LF||
'999fb7b4717509af678b985ab0b6b4ae6f7ed9ba';
    wwv_flow_api.g_varchar2_table(1517) := '6c4170b06c788a705430adf71bad2b5b057d03606a1ed7ebf5babd7a41cf00b0ef83a6569632cd467faddec9'||wwv_flow.LF||
'699640f671';
    wwv_flow_api.g_varchar2_table(1518) := '9e76b7d6ac355c7c89feca9cccad4ea7d36c65b258a206641f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8';
    wwv_flow_api.g_varchar2_table(1519) := 'e257e7f0fd2badd586'||wwv_flow.LF||
'8b37a088d1e4600ead1ddaef67d40bc898b3ed4af81ac0d76a197c86826828a24bb318f3442d8ab5';
    wwv_flow_api.g_varchar2_table(1520) := '18dfe3a20f000d6458d104a9694ac6d88728eee2782428d6'||wwv_flow.LF||
'0cf03ac1a5193be4cbb921cd0b495fd054b5bd0f530c1931a3';
    wwv_flow_api.g_varchar2_table(1521) := 'f7eaf9f7af9e3f45c70f9e1d3ff8e9f8e1c3e3073f5a42ceaa6d9c84e5552fbffdeccfc71fa33f'||wwv_flow.LF||
'9e7ef3f2d117d57859c6';
    wwv_flow_api.g_varchar2_table(1522) := 'fffac327bffcfc793510d26726ce8b2f9ffcf6ecc98baf3efdfdbb4715f04d814765f890c644a29be408edf3181433567125';
    wwv_flow_api.g_varchar2_table(1523) := '272371be'||wwv_flow.LF||
'15c308d3f28acd249438c19a4b05fd9e8a1cf4cd296699771c393ac4b5e01d01e5a30a787d72cf1178108989a2';
    wwv_flow_api.g_varchar2_table(1524) := '159c77a2d801ee72ce3a5c545a6147f32a9979'||wwv_flow.LF||
'3849c26ae66252c6ed637c58c5bb8b13c7bfbd490a75330f4b47f16e441c';
    wwv_flow_api.g_varchar2_table(1525) := '31f7184e140e494214d273fc80900aedee52ead87597fa824b3e56e82e451d4c2b4d'||wwv_flow.LF||
'32a423279a668bb6690c7e9956e90c';
    wwv_flow_api.g_varchar2_table(1526) := 'fe766cb37b077538abd27a8b1cba48c80acc2a841f12e698f13a9e281c57911ce298950d7e03aba84ac8c154f8655c4f2a'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1527) := 'f074481847bd804859b5e696007d4b4edfc150b12addbecba6b18b148a1e54d1bc81392f23b7f84137c2715a851dd0242a63';
    wwv_flow_api.g_varchar2_table(1528) := '3f900710a218ed715505dfe56e86'||wwv_flow.LF||
'e877f0034e16bafb0e258ebb4faf06b769e888340b103d331115bebc4eb813bf83291b';
    wwv_flow_api.g_varchar2_table(1529) := '63624a0d1475a756c734f9bbc2cd28546ecbe1e20a3794ca175f3fae90'||wwv_flow.LF||
'fb6d2dd99bb07b55e5ccf68942bd0877b23c77b9';
    wwv_flow_api.g_varchar2_table(1530) := '08e8db5f9db7f024d9239010f35bd4bbe2fcae387bfff9e2bc289f2fbe24cfaa301468dd8bd846dbb4ddf1c2'||wwv_flow.LF||
'ae7b4c191b';
    wwv_flow_api.g_varchar2_table(1531) := 'a8292337a469bc25ec3d411f06f53a73e224c5292c8de0516732307070a1c0660d125c7d44553488700a4d7bddd344429991';
    wwv_flow_api.g_varchar2_table(1532) := '0e254ab984c3a219ae'||wwv_flow.LF||
'a4adf1d0f82b7bd46cea4388ad1c12ab5d1ed8e1153d9c9f350a3246aad01c6873462b9ac05999ad';
    wwv_flow_api.g_varchar2_table(1533) := '5cc988826eafc3acae853a33b7ba11cd1445875ba1b236b1'||wwv_flow.LF||
'399483c90bd560b0b0263435085a21b0f22a9cf9356b38ec60';
    wwv_flow_api.g_varchar2_table(1534) := '46026d77eba3dc2dc60b17e92219e180643ed27acffba86e9c94c7ca9c225a0f1b0cfae0788ad5'||wwv_flow.LF||
'4adc5a9aec1b703b8b93';
    wwv_flow_api.g_varchar2_table(1535) := 'caec1a0bd8e5de7b132fe5113cf312503b998e2c2927274bd051db6b35979b1ef271daf6c6704e86c73805af4bdd476216c2';
    wwv_flow_api.g_varchar2_table(1536) := '6593af84'||wwv_flow.LF||
'0dfb5393d964f9cc9bad5c313709ea70f561ed3ea7b053075221d51696910d0d339585004b34272bff7213cc7a';
    wwv_flow_api.g_varchar2_table(1537) := '510a5454a3b349b1b206c1f0af490176745d4b'||wwv_flow.LF||
'c663e2abb2b34b23da76f6352ba57ca2881844c1111ab189d8c7e07e1daa';
    wwv_flow_api.g_varchar2_table(1538) := 'a04f40255c77988aa05fe06e4e5bdb4cb9c5394bbaf28d98c1d971ccd20867e556a7'||wwv_flow.LF||
'689ec9166e0a522183792b8907ba55';
    wwv_flow_api.g_varchar2_table(1539) := 'ca6e943bbf2a26e52f48957218ffcf54d1fb09dc3eac04da033e5c0d0b8c74a6b43d2e54c4a10aa511f5fb021a07533b20'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1540) := '5ae07e17a621a8e082dafc17e450ffb739676998b48643a4daa7211214f623150942f6a02c99e83b85583ddbbb2c49961132';
    wwv_flow_api.g_varchar2_table(1541) := '11551257a656ec1139246ca86be0'||wwv_flow.LF||
'aadedb3d1441a89b6a929501833b197fee7b9641a3503739e57c732a59b1f7da1cf8a7';
    wwv_flow_api.g_varchar2_table(1542) := '3b1f9bcca0945b874d4393dbbf10b1680f66bbaa5d6f96e77b6f59113d'||wwv_flow.LF||
'316bb31a795600b3d256d0cad2fe354538e7566b';
    wwv_flow_api.g_varchar2_table(1543) := '2bd69cc6cbcd5c38f0e2bcc63058344429dc2121fd07f63f2a7c66bf76e80d75c8f7a1b622f878a18941d840'||wwv_flow.LF||
'545fb28d07';
    wwv_flow_api.g_varchar2_table(1544) := 'd205d20e8ea071b283369834296bdaac75d256cb37eb0bee740bbe278cad253b8bbfcf69eca23973d939b97891c6ce2cecd8';
    wwv_flow_api.g_varchar2_table(1545) := 'da8e2d343578f6648a'||wwv_flow.LF||
'c2d0383fc818c798cf64e52f597c740f1cbd05df0c264c49134cf09d4a60e8a107260f20f92d47b3';
    wwv_flow_api.g_varchar2_table(1546) := '74e32f000000ffff0300504b030414000600080000002100'||wwv_flow.LF||
'0dd1909fb60000001b010000270000007468656d652f746865';
    wwv_flow_api.g_varchar2_table(1547) := '6d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f7'||wwv_flow.LF||
'8277086f6fd3ba109126';
    wwv_flow_api.g_varchar2_table(1548) := 'dd88d0add40384e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec8e40';
    wwv_flow_api.g_varchar2_table(1549) := '52164e89'||wwv_flow.LF||
'd93b64b060828e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8';
    wwv_flow_api.g_varchar2_table(1550) := 'bbd048f7757da0f19b017cc524bd62107bd500'||wwv_flow.LF||
'1996509affb3fd381a89672f1f165dfe514173d9850528a2c6cce0239baa';
    wwv_flow_api.g_varchar2_table(1551) := '4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0f'||wwv_flow.LF||
'bfff0000001c020000130000000000';
    wwv_flow_api.g_varchar2_table(1552) := '0000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100a5d6'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1553) := 'a7e7c0000000360100000b00000000000000000000000000300100005f72656c732f2e72656c73504b01022d001400060008';
    wwv_flow_api.g_varchar2_table(1554) := '00000021006b799616830000008a'||wwv_flow.LF||
'0000001c00000000000000000000000000190200007468656d652f7468656d652f7468';
    wwv_flow_api.g_varchar2_table(1555) := '656d654d616e616765722e786d6c504b01022d00140006000800000021'||wwv_flow.LF||
'0030dd4329a8060000a41b000016000000000000';
    wwv_flow_api.g_varchar2_table(1556) := '00000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d001400060008'||wwv_flow.LF||
'0000002100';
    wwv_flow_api.g_varchar2_table(1557) := '0dd1909fb60000001b0100002700000000000000000000000000b20900007468656d652f7468656d652f5f72656c732f7468';
    wwv_flow_api.g_varchar2_table(1558) := '656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000ad0a00000000}'||wwv_flow.LF||
'{\*\colorscheme';
    wwv_flow_api.g_varchar2_table(1559) := 'mapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e';
    wwv_flow_api.g_varchar2_table(1560) := '653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e';
    wwv_flow_api.g_varchar2_table(1561) := '786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22206267313d226c74312220747831';
    wwv_flow_api.g_varchar2_table(1562) := '3d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363'||wwv_flow.LF||
'65';
    wwv_flow_api.g_varchar2_table(1563) := '6e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220';
    wwv_flow_api.g_varchar2_table(1564) := '616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220';
    wwv_flow_api.g_varchar2_table(1565) := '666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstimax267\lsdlockeddef0\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(1566) := 'endef1\lsdunhideuseddef1\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcept \lsdsemihidden0 \lsdunhide';
    wwv_flow_api.g_varchar2_table(1567) := 'used0 \lsdqformat1 \lsdpriority0 \lsdlocked0 Normal;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \';
    wwv_flow_api.g_varchar2_table(1568) := 'lsdpriority9 \lsdlocked0 heading 1;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdqformat1 \ls';
    wwv_flow_api.g_varchar2_table(1569) := 'dpriority9 \lsdlocked0 heading 3;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdqformat1 \ls';
    wwv_flow_api.g_varchar2_table(1570) := 'dpriority9 \lsdlocked0 heading 5;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 6;\lsdqformat1 \lsdp';
    wwv_flow_api.g_varchar2_table(1571) := 'riority9 \lsdlocked0 heading 7;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdqformat1 \lsdpri';
    wwv_flow_api.g_varchar2_table(1572) := 'ority9 \lsdlocked0 heading 9;'||wwv_flow.LF||
'\lsdpriority39 \lsdlocked0 toc 1;\lsdpriority39 \lsdlocked0 toc 2;\ls';
    wwv_flow_api.g_varchar2_table(1573) := 'dpriority39 \lsdlocked0 toc 3;\lsdpriority39 \lsdlocked0 toc 4;\lsdpriority39 \lsdlocked0 toc 5;\lsd';
    wwv_flow_api.g_varchar2_table(1574) := 'priority39 \lsdlocked0 toc 6;\lsdpriority39 \lsdlocked0 toc 7;'||wwv_flow.LF||
'\lsdpriority39 \lsdlocked0 toc 8;\ls';
    wwv_flow_api.g_varchar2_table(1575) := 'dpriority39 \lsdlocked0 toc 9;\lsdqformat1 \lsdpriority35 \lsdlocked0 caption;\lsdsemihidden0 \lsdun';
    wwv_flow_api.g_varchar2_table(1576) := 'hideused0 \lsdqformat1 \lsdpriority10 \lsdlocked0 Title;\lsdpriority1 \lsdlocked0 Default Paragraph ';
    wwv_flow_api.g_varchar2_table(1577) := 'Font;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(1578) := 'en0 \lsdunhideused0 \lsdqformat1 \lsdpriority22 \lsdlocked0 Strong;\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(1579) := 'lsdqformat1 \lsdpriority20 \lsdlocked0 Emphasis;'||wwv_flow.LF||
'\lsdpriority59 \lsdlocked0 Table Grid;\lsdunhideus';
    wwv_flow_api.g_varchar2_table(1580) := 'ed0 \lsdlocked0 Placeholder Text;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority1 \lsdlock';
    wwv_flow_api.g_varchar2_table(1581) := 'ed0 No Spacing;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading;'||wwv_flow.LF||
'\lsdsemihi';
    wwv_flow_api.g_varchar2_table(1582) := 'dden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List;\lsdsemihidden0 \lsdunhideused0 \lsdprio';
    wwv_flow_api.g_varchar2_table(1583) := 'rity62 \lsdlocked0 Light Grid;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shad';
    wwv_flow_api.g_varchar2_table(1584) := 'ing 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2;\lsdsemihidden0 ';
    wwv_flow_api.g_varchar2_table(1585) := '\lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriorit';
    wwv_flow_api.g_varchar2_table(1586) := 'y66 \lsdlocked0 Medium List 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Gr';
    wwv_flow_api.g_varchar2_table(1587) := 'id 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdsemihidden0 \lsdun';
    wwv_flow_api.g_varchar2_table(1588) := 'hideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 ';
    wwv_flow_api.g_varchar2_table(1589) := '\lsdlocked0 Dark List;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading;\l';
    wwv_flow_api.g_varchar2_table(1590) := 'sdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideu';
    wwv_flow_api.g_varchar2_table(1591) := 'sed0 \lsdpriority73 \lsdlocked0 Colorful Grid;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdloc';
    wwv_flow_api.g_varchar2_table(1592) := 'ked0 Light Shading Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Ac';
    wwv_flow_api.g_varchar2_table(1593) := 'cent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(1594) := 'en0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdsemihidden0 \lsdunhideu';
    wwv_flow_api.g_varchar2_table(1595) := 'sed0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdprio';
    wwv_flow_api.g_varchar2_table(1596) := 'rity65 \lsdlocked0 Medium List 1 Accent 1;\lsdunhideused0 \lsdlocked0 Revision;\lsdsemihidden0 \lsdu';
    wwv_flow_api.g_varchar2_table(1597) := 'nhideused0 \lsdqformat1 \lsdpriority34 \lsdlocked0 List Paragraph;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1598) := '\lsdqformat1 \lsdpriority29 \lsdlocked0 Quote;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdprior';
    wwv_flow_api.g_varchar2_table(1599) := 'ity30 \lsdlocked0 Intense Quote;\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium Li';
    wwv_flow_api.g_varchar2_table(1600) := 'st 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;\l';
    wwv_flow_api.g_varchar2_table(1601) := 'sdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 1;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(1602) := 'unhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(1603) := 'priority70 \lsdlocked0 Dark List Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0';
    wwv_flow_api.g_varchar2_table(1604) := ' Colorful Shading Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List ';
    wwv_flow_api.g_varchar2_table(1605) := 'Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdsem';
    wwv_flow_api.g_varchar2_table(1606) := 'ihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 2;\lsdsemihidden0 \lsdunhid';
    wwv_flow_api.g_varchar2_table(1607) := 'eused0 \lsdpriority61 \lsdlocked0 Light List Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority';
    wwv_flow_api.g_varchar2_table(1608) := '62 \lsdlocked0 Light Grid Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium';
    wwv_flow_api.g_varchar2_table(1609) := ' Shading 1 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Acce';
    wwv_flow_api.g_varchar2_table(1610) := 'nt 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1611) := 'den0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 2;\lsdsemihidden0 \lsdunhideuse';
    wwv_flow_api.g_varchar2_table(1612) := 'd0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority6';
    wwv_flow_api.g_varchar2_table(1613) := '8 \lsdlocked0 Medium Grid 2 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medi';
    wwv_flow_api.g_varchar2_table(1614) := 'um Grid 3 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 2;'||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(1615) := 'lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 2;\lsdsemihidden0 ';
    wwv_flow_api.g_varchar2_table(1616) := '\lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 2;\lsdsemihidden0 \lsdunhideused0 \l';
    wwv_flow_api.g_varchar2_table(1617) := 'sdpriority73 \lsdlocked0 Colorful Grid Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \ls';
    wwv_flow_api.g_varchar2_table(1618) := 'dlocked0 Light Shading Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light Lis';
    wwv_flow_api.g_varchar2_table(1619) := 't Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 3;'||wwv_flow.LF||
'\lsdsemi';
    wwv_flow_api.g_varchar2_table(1620) := 'hidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdsemihidden0 \lsdunh';
    wwv_flow_api.g_varchar2_table(1621) := 'ideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(1622) := 'iority65 \lsdlocked0 Medium List 1 Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdloc';
    wwv_flow_api.g_varchar2_table(1623) := 'ked0 Medium List 2 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1';
    wwv_flow_api.g_varchar2_table(1624) := ' Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 3;'||wwv_flow.LF||
'\lsdse';
    wwv_flow_api.g_varchar2_table(1625) := 'mihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(1626) := 'deused0 \lsdpriority70 \lsdlocked0 Dark List Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71';
    wwv_flow_api.g_varchar2_table(1627) := ' \lsdlocked0 Colorful Shading Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 ';
    wwv_flow_api.g_varchar2_table(1628) := 'Colorful List Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Acce';
    wwv_flow_api.g_varchar2_table(1629) := 'nt 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 4;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1630) := 'den0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1631) := '\lsdpriority62 \lsdlocked0 Light Grid Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlo';
    wwv_flow_api.g_varchar2_table(1632) := 'cked0 Medium Shading 1 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium ';
    wwv_flow_api.g_varchar2_table(1633) := 'Shading 2 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 4';
    wwv_flow_api.g_varchar2_table(1634) := ';\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0';
    wwv_flow_api.g_varchar2_table(1635) := ' \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(1636) := 'lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsd';
    wwv_flow_api.g_varchar2_table(1637) := 'locked0 Medium Grid 3 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark Lis';
    wwv_flow_api.g_varchar2_table(1638) := 't Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsd';
    wwv_flow_api.g_varchar2_table(1639) := 'semihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(1640) := 'unhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(1641) := 'iority60 \lsdlocked0 Light Shading Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocke';
    wwv_flow_api.g_varchar2_table(1642) := 'd0 Light List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accen';
    wwv_flow_api.g_varchar2_table(1643) := 't 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1644) := 'den0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(1645) := 'deused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriori';
    wwv_flow_api.g_varchar2_table(1646) := 'ty66 \lsdlocked0 Medium List 2 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 M';
    wwv_flow_api.g_varchar2_table(1647) := 'edium Grid 1 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Acc';
    wwv_flow_api.g_varchar2_table(1648) := 'ent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(1649) := 'en0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1650) := '\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 ';
    wwv_flow_api.g_varchar2_table(1651) := '\lsdlocked0 Colorful List Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorf';
    wwv_flow_api.g_varchar2_table(1652) := 'ul Grid Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 6';
    wwv_flow_api.g_varchar2_table(1653) := ';\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(1654) := 'unhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpri';
    wwv_flow_api.g_varchar2_table(1655) := 'ority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdloc';
    wwv_flow_api.g_varchar2_table(1656) := 'ked0 Medium Shading 2 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium Lis';
    wwv_flow_api.g_varchar2_table(1657) := 't 1 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 6;\ls';
    wwv_flow_api.g_varchar2_table(1658) := 'dsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdsemihidden0 \lsdu';
    wwv_flow_api.g_varchar2_table(1659) := 'nhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdp';
    wwv_flow_api.g_varchar2_table(1660) := 'riority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlock';
    wwv_flow_api.g_varchar2_table(1661) := 'ed0 Dark List Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading A';
    wwv_flow_api.g_varchar2_table(1662) := 'ccent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 6;\lsdsemi';
    wwv_flow_api.g_varchar2_table(1663) := 'hidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdsemihidden0 \lsdunhide';
    wwv_flow_api.g_varchar2_table(1664) := 'used0 \lsdqformat1 \lsdpriority19 \lsdlocked0 Subtle Emphasis;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(1665) := 'qformat1 \lsdpriority21 \lsdlocked0 Intense Emphasis;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \l';
    wwv_flow_api.g_varchar2_table(1666) := 'sdpriority31 \lsdlocked0 Subtle Reference;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriorit';
    wwv_flow_api.g_varchar2_table(1667) := 'y32 \lsdlocked0 Intense Reference;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority33 \lsdlo';
    wwv_flow_api.g_varchar2_table(1668) := 'cked0 Book Title;\lsdpriority37 \lsdlocked0 Bibliography;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority39 \lsdlocked0 T';
    wwv_flow_api.g_varchar2_table(1669) := 'OC Heading;}}{\*\datastore 0105000002000000180000004d73786d6c322e534158584d4c5265616465722e362e30000';
    wwv_flow_api.g_varchar2_table(1670) := '000000000000000000e0000'||wwv_flow.LF||
'd0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000';
    wwv_flow_api.g_varchar2_table(1671) := '0000000000000010000000100000000000000001000000200000001000000feffffff0000000000000000fffffffffffffff';
    wwv_flow_api.g_varchar2_table(1672) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1673) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1674) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1675) := 'fffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1676) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1677) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffff';
    wwv_flow_api.g_varchar2_table(1678) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1679) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1680) := 'fffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdffffff04000000feffffff05000000fefffffffef';
    wwv_flow_api.g_varchar2_table(1681) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1682) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(1683) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1684) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1685) := 'fffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1686) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1687) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1688) := 'f'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1689) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1690) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f0';
    wwv_flow_api.g_varchar2_table(1691) := '07400200045006e0074007200790000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1692) := '0000000000000000016000500ffffffffffffffff010000000c6ad98892f1d411a65f0040963251e50000000000000000000';
    wwv_flow_api.g_varchar2_table(1693) := '00000f0c4'||wwv_flow.LF||
'03d410acd7010300000080020000000000004d0073006f004400610074006100530074006f007200650000000';
    wwv_flow_api.g_varchar2_table(1694) := '0000000000000000000000000000000000000000000000000000000000000000000000000001a000101ffffffffffffffff0';
    wwv_flow_api.g_varchar2_table(1695) := '20000000000000000000000000000000000000000000000f0c403d410acd701'||wwv_flow.LF||
'f0c403d410acd7010000000000000000000';
    wwv_flow_api.g_varchar2_table(1696) := '00000de00dd005100c100df004200d000d600d500d4005700c000c8004a004f00530042004f00d900c1004e0051003d003d0';
    wwv_flow_api.g_varchar2_table(1697) := '00000000000000000000000000000000032000101ffffffffffffffff0300000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1698) := '00000f0c403d410ac'||wwv_flow.LF||
'd701f0c403d410acd7010000000000000000000000004900740065006d00000000000000000000000';
    wwv_flow_api.g_varchar2_table(1699) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a000201f';
    wwv_flow_api.g_varchar2_table(1700) := 'fffffff04000000ffffffff000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1701) := '00000d800000000000000010000000200000003000000feffffff0500000006000000070000000800000009000000fefffff';
    wwv_flow_api.g_varchar2_table(1702) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1703) := 'fffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1704) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1705) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1706) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1707) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1708) := 'fffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1709) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1710) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffff';
    wwv_flow_api.g_varchar2_table(1711) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff3c623a536f75726365732053656c65637465645374796c6';
    wwv_flow_api.g_varchar2_table(1712) := '53d225c4150412e58534c22205374796c654e616d653d224150412220786d6c6e733a623d22687474703a2f2f736368656d6';
    wwv_flow_api.g_varchar2_table(1713) := '1732e6f70656e786d6c666f726d6174732e6f7267'||wwv_flow.LF||
'2f6f6666696365446f63756d656e742f323030362f6269626c696f677';
    wwv_flow_api.g_varchar2_table(1714) := '2617068792220786d6c6e733d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f6f666';
    wwv_flow_api.g_varchar2_table(1715) := '6696365446f63756d656e742f323030362f6269626c696f677261706879223e3c2f623a536f75726365733e00000000'||wwv_flow.LF||
'000';
    wwv_flow_api.g_varchar2_table(1716) := '0000000000000000000000000000000000000000000000000000000000000000000003c3f786d6c2076657273696f6e3d223';
    wwv_flow_api.g_varchar2_table(1717) := '12e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d226e6f223f3e0d0a3c64733a64617461737';
    wwv_flow_api.g_varchar2_table(1718) := '46f72654974656d2064733a6974656d49443d227b46433231'||wwv_flow.LF||
'443446422d333631432d343544372d413041302d393339323';
    wwv_flow_api.g_varchar2_table(1719) := '0344545363133357d2220786d6c6e733a64733d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732';
    wwv_flow_api.g_varchar2_table(1720) := 'e6f72672f6f6666696365446f63756d656e742f323030362f637573746f6d586d6c223e3c64733a736368656d61526566733';
    wwv_flow_api.g_varchar2_table(1721) := 'e3c'||wwv_flow.LF||
'64733a736368656d615265662064733a7572693d22687474703a2f2f736368656d61732e6f70656e500072006f00700';
    wwv_flow_api.g_varchar2_table(1722) := '0650072007400690065007300000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1723) := '000000000000016000200ffffffffffffffffffffffff000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1724) := '0000000000000000000040000005501000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1725) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000fffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1726) := 'fff00000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1727) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1728) := '0000000000000000000000000000000000000ffffffffffffffffffffffff0000'||wwv_flow.LF||
'000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1729) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1730) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000fffff';
    wwv_flow_api.g_varchar2_table(1731) := 'fffffffffffffffffff'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1732) := '00000000000000000786d6c666f726d6174732e6f72672f6f6666696365446f63756d656e742f323030362f6269626c696f6';
    wwv_flow_api.g_varchar2_table(1733) := '77261706879222f3e3c2f64733a736368656d61526566733e3c2f64733a6461746173746f'||wwv_flow.LF||
'72654974656d3e00000000000';
    wwv_flow_api.g_varchar2_table(1734) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1735) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1736) := '000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1737) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1738) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000';
    wwv_flow_api.g_varchar2_table(1739) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1740) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1741) := '00000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1742) := '00000000000000000000000000000000000000000000000000105000000000000}}';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_report_layout(
 p_id=>wwv_flow_api.id(34815863112965485225)
,p_report_layout_name=>'daily_sales_report_layout'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_api.g_varchar2_table
);
null;
wwv_flow_api.component_end;
end;
/
