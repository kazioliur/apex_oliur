prompt --application/shared_components/reports/report_layouts/bill
begin
--   Manifest
--     REPORT LAYOUT: bill
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
    wwv_flow_api.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff31507\deff0\stshfdbch31506\stshfloch31506\stshfhich315';
    wwv_flow_api.g_varchar2_table(2) := '06\stshfbi31507\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi';
    wwv_flow_api.g_varchar2_table(3) := ' \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f34\fbidi \froman\fcharse';
    wwv_flow_api.g_varchar2_table(4) := 't0\fprq2{\*\panose 02040503050406030204}Cambria Math;}'||wwv_flow.LF||
'{\f37\fbidi \fswiss\fcharset0\fprq2{\*\panos';
    wwv_flow_api.g_varchar2_table(5) := 'e 020f0502020204030204}Calibri;}{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 0202060305';
    wwv_flow_api.g_varchar2_table(6) := '0405020304}Times New Roman;}'||wwv_flow.LF||
'{\fdbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 020206030504';
    wwv_flow_api.g_varchar2_table(7) := '05020304}Times New Roman;}{\fhimajor\f31502\fbidi \froman\fcharset0\fprq2{\*\panose 0204050305040603';
    wwv_flow_api.g_varchar2_table(8) := '0204}Cambria;}'||wwv_flow.LF||
'{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times';
    wwv_flow_api.g_varchar2_table(9) := ' New Roman;}{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New';
    wwv_flow_api.g_varchar2_table(10) := ' Roman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New R';
    wwv_flow_api.g_varchar2_table(11) := 'oman;}{\fhiminor\f31506\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri;}'||wwv_flow.LF||
'{\fb';
    wwv_flow_api.g_varchar2_table(12) := 'iminor\f31507\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f285\f';
    wwv_flow_api.g_varchar2_table(13) := 'bidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f286\fbidi \froman\fcharset204\fprq2 Times New ';
    wwv_flow_api.g_varchar2_table(14) := 'Roman Cyr;}'||wwv_flow.LF||
'{\f288\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f289\fbidi \froman\fcha';
    wwv_flow_api.g_varchar2_table(15) := 'rset162\fprq2 Times New Roman Tur;}{\f290\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}';
    wwv_flow_api.g_varchar2_table(16) := '{\f291\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f292\fbidi \froman\fcharset186\';
    wwv_flow_api.g_varchar2_table(17) := 'fprq2 Times New Roman Baltic;}{\f293\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{';
    wwv_flow_api.g_varchar2_table(18) := '\f625\fbidi \froman\fcharset238\fprq2 Cambria Math CE;}{\f626\fbidi \froman\fcharset204\fprq2 Cambri';
    wwv_flow_api.g_varchar2_table(19) := 'a Math Cyr;}'||wwv_flow.LF||
'{\f628\fbidi \froman\fcharset161\fprq2 Cambria Math Greek;}{\f629\fbidi \froman\fchars';
    wwv_flow_api.g_varchar2_table(20) := 'et162\fprq2 Cambria Math Tur;}{\f632\fbidi \froman\fcharset186\fprq2 Cambria Math Baltic;}{\f633\fbi';
    wwv_flow_api.g_varchar2_table(21) := 'di \froman\fcharset163\fprq2 Cambria Math (Vietnamese);}'||wwv_flow.LF||
'{\f655\fbidi \fswiss\fcharset238\fprq2 Cal';
    wwv_flow_api.g_varchar2_table(22) := 'ibri CE;}{\f656\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}{\f658\fbidi \fswiss\fcharset161\fprq2 ';
    wwv_flow_api.g_varchar2_table(23) := 'Calibri Greek;}{\f659\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\f660\fbidi \fswiss\fcharset17';
    wwv_flow_api.g_varchar2_table(24) := '7\fprq2 Calibri (Hebrew);}{\f661\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\f662\fbidi \fsw';
    wwv_flow_api.g_varchar2_table(25) := 'iss\fcharset186\fprq2 Calibri Baltic;}{\f663\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}';
    wwv_flow_api.g_varchar2_table(26) := ''||wwv_flow.LF||
'{\flomajor\f31508\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flomajor\f31509\fbidi \from';
    wwv_flow_api.g_varchar2_table(27) := 'an\fcharset204\fprq2 Times New Roman Cyr;}{\flomajor\f31511\fbidi \froman\fcharset161\fprq2 Times Ne';
    wwv_flow_api.g_varchar2_table(28) := 'w Roman Greek;}'||wwv_flow.LF||
'{\flomajor\f31512\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flomajor\f';
    wwv_flow_api.g_varchar2_table(29) := '31513\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\flomajor\f31514\fbidi \froman\fcha';
    wwv_flow_api.g_varchar2_table(30) := 'rset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\flomajor\f31515\fbidi \froman\fcharset186\fprq2 Times Ne';
    wwv_flow_api.g_varchar2_table(31) := 'w Roman Baltic;}{\flomajor\f31516\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fd';
    wwv_flow_api.g_varchar2_table(32) := 'bmajor\f31518\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fdbmajor\f31519\fbidi \froman\';
    wwv_flow_api.g_varchar2_table(33) := 'fcharset204\fprq2 Times New Roman Cyr;}{\fdbmajor\f31521\fbidi \froman\fcharset161\fprq2 Times New R';
    wwv_flow_api.g_varchar2_table(34) := 'oman Greek;}{\fdbmajor\f31522\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fdbmajor\f315';
    wwv_flow_api.g_varchar2_table(35) := '23\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbmajor\f31524\fbidi \froman\fcharse';
    wwv_flow_api.g_varchar2_table(36) := 't178\fprq2 Times New Roman (Arabic);}{\fdbmajor\f31525\fbidi \froman\fcharset186\fprq2 Times New Rom';
    wwv_flow_api.g_varchar2_table(37) := 'an Baltic;}'||wwv_flow.LF||
'{\fdbmajor\f31526\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhima';
    wwv_flow_api.g_varchar2_table(38) := 'jor\f31528\fbidi \froman\fcharset238\fprq2 Cambria CE;}{\fhimajor\f31529\fbidi \froman\fcharset204\f';
    wwv_flow_api.g_varchar2_table(39) := 'prq2 Cambria Cyr;}'||wwv_flow.LF||
'{\fhimajor\f31531\fbidi \froman\fcharset161\fprq2 Cambria Greek;}{\fhimajor\f315';
    wwv_flow_api.g_varchar2_table(40) := '32\fbidi \froman\fcharset162\fprq2 Cambria Tur;}{\fhimajor\f31535\fbidi \froman\fcharset186\fprq2 Ca';
    wwv_flow_api.g_varchar2_table(41) := 'mbria Baltic;}'||wwv_flow.LF||
'{\fhimajor\f31536\fbidi \froman\fcharset163\fprq2 Cambria (Vietnamese);}{\fbimajor\f';
    wwv_flow_api.g_varchar2_table(42) := '31538\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbimajor\f31539\fbidi \froman\fcharset20';
    wwv_flow_api.g_varchar2_table(43) := '4\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\fbimajor\f31541\fbidi \froman\fcharset161\fprq2 Times New Roman Gre';
    wwv_flow_api.g_varchar2_table(44) := 'ek;}{\fbimajor\f31542\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbimajor\f31543\fbidi \';
    wwv_flow_api.g_varchar2_table(45) := 'froman\fcharset177\fprq2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fbimajor\f31544\fbidi \froman\fcharset178\fpr';
    wwv_flow_api.g_varchar2_table(46) := 'q2 Times New Roman (Arabic);}{\fbimajor\f31545\fbidi \froman\fcharset186\fprq2 Times New Roman Balti';
    wwv_flow_api.g_varchar2_table(47) := 'c;}{\fbimajor\f31546\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\flominor\f315';
    wwv_flow_api.g_varchar2_table(48) := '48\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flominor\f31549\fbidi \froman\fcharset204\f';
    wwv_flow_api.g_varchar2_table(49) := 'prq2 Times New Roman Cyr;}{\flominor\f31551\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}';
    wwv_flow_api.g_varchar2_table(50) := ''||wwv_flow.LF||
'{\flominor\f31552\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flominor\f31553\fbidi \fro';
    wwv_flow_api.g_varchar2_table(51) := 'man\fcharset177\fprq2 Times New Roman (Hebrew);}{\flominor\f31554\fbidi \froman\fcharset178\fprq2 Ti';
    wwv_flow_api.g_varchar2_table(52) := 'mes New Roman (Arabic);}'||wwv_flow.LF||
'{\flominor\f31555\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}';
    wwv_flow_api.g_varchar2_table(53) := '{\flominor\f31556\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fdbminor\f31558\fb';
    wwv_flow_api.g_varchar2_table(54) := 'idi \froman\fcharset238\fprq2 Times New Roman CE;}'||wwv_flow.LF||
'{\fdbminor\f31559\fbidi \froman\fcharset204\fprq';
    wwv_flow_api.g_varchar2_table(55) := '2 Times New Roman Cyr;}{\fdbminor\f31561\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fd';
    wwv_flow_api.g_varchar2_table(56) := 'bminor\f31562\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fdbminor\f31563\fbidi \froman';
    wwv_flow_api.g_varchar2_table(57) := '\fcharset177\fprq2 Times New Roman (Hebrew);}{\fdbminor\f31564\fbidi \froman\fcharset178\fprq2 Times';
    wwv_flow_api.g_varchar2_table(58) := ' New Roman (Arabic);}{\fdbminor\f31565\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\f';
    wwv_flow_api.g_varchar2_table(59) := 'dbminor\f31566\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhiminor\f31568\fbidi';
    wwv_flow_api.g_varchar2_table(60) := ' \fswiss\fcharset238\fprq2 Calibri CE;}{\fhiminor\f31569\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr';
    wwv_flow_api.g_varchar2_table(61) := ';}'||wwv_flow.LF||
'{\fhiminor\f31571\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\fhiminor\f31572\fbidi \fswiss';
    wwv_flow_api.g_varchar2_table(62) := '\fcharset162\fprq2 Calibri Tur;}{\fhiminor\f31573\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}';
    wwv_flow_api.g_varchar2_table(63) := ''||wwv_flow.LF||
'{\fhiminor\f31574\fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\fhiminor\f31575\fbidi \fswis';
    wwv_flow_api.g_varchar2_table(64) := 's\fcharset186\fprq2 Calibri Baltic;}{\fhiminor\f31576\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietn';
    wwv_flow_api.g_varchar2_table(65) := 'amese);}'||wwv_flow.LF||
'{\fbiminor\f31578\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbiminor\f31579\fb';
    wwv_flow_api.g_varchar2_table(66) := 'idi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbiminor\f31581\fbidi \froman\fcharset161\fprq2';
    wwv_flow_api.g_varchar2_table(67) := ' Times New Roman Greek;}'||wwv_flow.LF||
'{\fbiminor\f31582\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\f';
    wwv_flow_api.g_varchar2_table(68) := 'biminor\f31583\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\fbiminor\f31584\fbidi \fr';
    wwv_flow_api.g_varchar2_table(69) := 'oman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fbiminor\f31585\fbidi \froman\fcharset186\fprq2';
    wwv_flow_api.g_varchar2_table(70) := ' Times New Roman Baltic;}{\fbiminor\f31586\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietname';
    wwv_flow_api.g_varchar2_table(71) := 'se);}}{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\blue255;\red0\green255\blue0';
    wwv_flow_api.g_varchar2_table(72) := ';'||wwv_flow.LF||
'\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red255\green255\blue255;\red0';
    wwv_flow_api.g_varchar2_table(73) := '\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;\red128\green0\blue128;\red128\green0\bl';
    wwv_flow_api.g_varchar2_table(74) := 'ue0;\red128\green128\blue0;\red128\green128\blue128;'||wwv_flow.LF||
'\red192\green192\blue192;\red231\green243\blue';
    wwv_flow_api.g_varchar2_table(75) := '253;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa200\sl276\slmult1\widctlpar\wrapdefault\aspa';
    wwv_flow_api.g_varchar2_table(76) := 'lpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa200\sl276\s';
    wwv_flow_api.g_varchar2_table(77) := 'lmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af315';
    wwv_flow_api.g_varchar2_table(78) := '07\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext';
    wwv_flow_api.g_varchar2_table(79) := '0 \sqformat \spriority0 Normal;}{\*\cs10 \additive '||wwv_flow.LF||
'\ssemihidden \sunhideused \spriority1 Default P';
    wwv_flow_api.g_varchar2_table(80) := 'aragraph Font;}{\*\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpa';
    wwv_flow_api.g_varchar2_table(81) := 'ddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbr';
    wwv_flow_api.g_varchar2_table(82) := 'drv '||wwv_flow.LF||
'\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0';
    wwv_flow_api.g_varchar2_table(83) := '\lin0\itap0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\';
    wwv_flow_api.g_varchar2_table(84) := 'langnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused '||wwv_flow.LF||
'Normal Table;}{\*\ts15\tsrowd\trbrdrt\b';
    wwv_flow_api.g_varchar2_table(85) := 'rdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brd';
    wwv_flow_api.g_varchar2_table(86) := 'rw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpa';
    wwv_flow_api.g_varchar2_table(87) := 'ddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbr';
    wwv_flow_api.g_varchar2_table(88) := 'drv '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\f';
    wwv_flow_api.g_varchar2_table(89) := 'cs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1';
    wwv_flow_api.g_varchar2_table(90) := '033 '||wwv_flow.LF||
'\sbasedon11 \snext15 \sunhideused \spriority59 \styrsid13592754 Table Grid;}}{\*\rsidtbl \rsid';
    wwv_flow_api.g_varchar2_table(91) := '1784634\rsid3433759\rsid13592754}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\ml';
    wwv_flow_api.g_varchar2_table(92) := 'Margin0\mrMargin0\mdefJc1\mwrapIndent1440\mintLim0\mnaryLim1}'||wwv_flow.LF||
'{\info{\author oliur}{\operator oliur';
    wwv_flow_api.g_varchar2_table(93) := '}{\creatim\yr2021\mo9\dy13\hr11\min56}{\revtim\yr2021\mo9\dy13\hr11\min56}{\version2}{\edmins0}{\nof';
    wwv_flow_api.g_varchar2_table(94) := 'pages1}{\nofwords54}{\nofchars313}{\nofcharsws366}{\vern49247}}{\*\xmlnstbl {\xmlns1 http://schemas.';
    wwv_flow_api.g_varchar2_table(95) := 'microsoft.com/offi'||wwv_flow.LF||
'ce/word/2003/wordml}}\paperw12240\paperh15840\margl1440\margr1440\margt1440\marg';
    wwv_flow_api.g_varchar2_table(96) := 'b1440\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\trackmoves0\trackformatting1\donotembedsysfont1\rel';
    wwv_flow_api.g_varchar2_table(97) := 'yonvml0\donotembedlingdata0\grfdocevents0\validatexml1\showplaceholdtext0\ignoremixedcontent0\savein';
    wwv_flow_api.g_varchar2_table(98) := 'validxml0\showxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\expshrtn\noultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc';
    wwv_flow_api.g_varchar2_table(99) := '\dgmargin\dghspace180\dgvspace180\dghorigin1440\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\';
    wwv_flow_api.g_varchar2_table(100) := 'viewscale100\pgbrdrhead\pgbrdrfoot\splytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\';
    wwv_flow_api.g_varchar2_table(101) := 'lytcalctblwd\lyttblrtgr\lnbrkrule\nobrkwrptbl\snaptogridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkr';
    wwv_flow_api.g_varchar2_table(102) := 'ule\rsidroot1784634\newtblstyruls\nogrowautofit\usenormstyforlist\noindnmbrts\felnbrelev\nocxsptable';
    wwv_flow_api.g_varchar2_table(103) := '\indrlsweleven\noafcnsttbl\afelev\utinl\hwelev\spltpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsn';
    wwv_flow_api.g_varchar2_table(104) := 'et\cachedcolbal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wgrffmtfilter 2450}\nofeaturethrottle1\ilfomacatclnup0\ltrpar';
    wwv_flow_api.g_varchar2_table(105) := ' \sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\*\pnseclvl1\pnucrm\pnstart1\';
    wwv_flow_api.g_varchar2_table(106) := 'pnindent720\pnhang {\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang '||wwv_flow.LF||
'{\pntxta .}}{\*\p';
    wwv_flow_api.g_varchar2_table(107) := 'nseclvl3\pndec\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pn';
    wwv_flow_api.g_varchar2_table(108) := 'hang {\pntxta )}}{\*\pnseclvl5\pndec\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl';
    wwv_flow_api.g_varchar2_table(109) := '6\pnlcltr\pnstart1\pnindent720\pnhang '||wwv_flow.LF||
'{\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pninden';
    wwv_flow_api.g_varchar2_table(110) := 't720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pn';
    wwv_flow_api.g_varchar2_table(111) := 'txta )}}{\*\pnseclvl9\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}\ltrrow'||wwv_flow.LF||
'\trowd \iro';
    wwv_flow_api.g_varchar2_table(112) := 'w0\irowband0\ltrrow\ts15\trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \tr';
    wwv_flow_api.g_varchar2_table(113) := 'brdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWid';
    wwv_flow_api.g_varchar2_table(114) := 'th1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid135';
    wwv_flow_api.g_varchar2_table(115) := '92754\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 ';
    wwv_flow_api.g_varchar2_table(116) := '\clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidt';
    wwv_flow_api.g_varchar2_table(117) := 'h3\clwWidth957\clcbpatraw17 \cellx646\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdr';
    wwv_flow_api.g_varchar2_table(118) := 'b\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth957\clcbpatraw17 '||wwv_flow.LF||
'\c';
    wwv_flow_api.g_varchar2_table(119) := 'ellx1775\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdr';
    wwv_flow_api.g_varchar2_table(120) := 's\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth957\clcbpatraw17 \cellx2864\clvertalt\clbrdrt\brdr';
    wwv_flow_api.g_varchar2_table(121) := 's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb';
    wwv_flow_api.g_varchar2_table(122) := '\clftsWidth3\clwWidth957\clcbpatraw17 \cellx3760\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdr';
    wwv_flow_api.g_varchar2_table(123) := 'w10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcb';
    wwv_flow_api.g_varchar2_table(124) := 'patraw17 \cellx4235\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \c';
    wwv_flow_api.g_varchar2_table(125) := 'lbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx5403\clvertalt\c';
    wwv_flow_api.g_varchar2_table(126) := 'lbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat';
    wwv_flow_api.g_varchar2_table(127) := '17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx6977\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl';
    wwv_flow_api.g_varchar2_table(128) := '\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_api.g_varchar2_table(129) := 'dth958\clcbpatraw17 \cellx7865\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs';
    wwv_flow_api.g_varchar2_table(130) := '\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx8450\';
    wwv_flow_api.g_varchar2_table(131) := 'clvertalt\clbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(132) := '10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx9468\pard\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\';
    wwv_flow_api.g_varchar2_table(133) := 'ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\yts15 \rtlch\fcs1 \af31';
    wwv_flow_api.g_varchar2_table(134) := '507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtl';
    wwv_flow_api.g_varchar2_table(135) := 'ch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid13592754 Invoice}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid';
    wwv_flow_api.g_varchar2_table(136) := '13592754\charrsid13592754 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid13592754 Guest Name}{\r';
    wwv_flow_api.g_varchar2_table(137) := 'tlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 \cell }{\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltr';
    wwv_flow_api.g_varchar2_table(138) := 'ch\fcs0 \b\insrsid13592754 Order Date}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid135';
    wwv_flow_api.g_varchar2_table(139) := '92754 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid13592754 Discount}{\rtlch\fcs1 \af31507 \lt';
    wwv_flow_api.g_varchar2_table(140) := 'rch\fcs0 '||wwv_flow.LF||
'\insrsid13592754\charrsid13592754 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid1359';
    wwv_flow_api.g_varchar2_table(141) := '2754 Vat}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 \cell }{\rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(142) := '31507 \ltrch\fcs0 \b\insrsid13592754 Grant Total}{\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \insrsid1359275';
    wwv_flow_api.g_varchar2_table(143) := '4\charrsid13592754 \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid13592754 Food Menu Name}{\rtlc';
    wwv_flow_api.g_varchar2_table(144) := 'h\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 \cell }{\rtlch\fcs1 \af31507 \ltrch\fc';
    wwv_flow_api.g_varchar2_table(145) := 's0 '||wwv_flow.LF||
'\b\insrsid13592754 Quantity}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754';
    wwv_flow_api.g_varchar2_table(146) := ' \cell }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \b\insrsid13592754 Price}{\rtlch\fcs1 \af31507 \ltrch\fcs0';
    wwv_flow_api.g_varchar2_table(147) := ' \insrsid13592754\charrsid13592754 \cell }{\rtlch\fcs1 '||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \b\insrsid13592754 Uni';
    wwv_flow_api.g_varchar2_table(148) := 't Tatal}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 \cell }\pard\plain \ltrp';
    wwv_flow_api.g_varchar2_table(149) := 'ar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\ri';
    wwv_flow_api.g_varchar2_table(150) := 'n0\lin0 '||wwv_flow.LF||
'\rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_api.g_varchar2_table(151) := 'ngnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754 \trowd \irow0\irowband0\ltr';
    wwv_flow_api.g_varchar2_table(152) := 'row\ts15\trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\br';
    wwv_flow_api.g_varchar2_table(153) := 'drw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidth';
    wwv_flow_api.g_varchar2_table(154) := 'B3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid13592754\tbllkhdr';
    wwv_flow_api.g_varchar2_table(155) := 'rows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs';
    wwv_flow_api.g_varchar2_table(156) := '\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth957';
    wwv_flow_api.g_varchar2_table(157) := '\clcbpatraw17 \cellx646\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw1';
    wwv_flow_api.g_varchar2_table(158) := '0 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth957\clcbpatraw17 '||wwv_flow.LF||
'\cellx1775\clver';
    wwv_flow_api.g_varchar2_table(159) := 'talt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clc';
    wwv_flow_api.g_varchar2_table(160) := 'bpat17\cltxlrtb\clftsWidth3\clwWidth957\clcbpatraw17 \cellx2864\clvertalt\clbrdrt\brdrs\brdrw10 \clb';
    wwv_flow_api.g_varchar2_table(161) := 'rdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\c';
    wwv_flow_api.g_varchar2_table(162) := 'lwWidth957\clcbpatraw17 \cellx3760\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\b';
    wwv_flow_api.g_varchar2_table(163) := 'rdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cell';
    wwv_flow_api.g_varchar2_table(164) := 'x4235\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\b';
    wwv_flow_api.g_varchar2_table(165) := 'rdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx5403\clvertalt\clbrdrt'||wwv_flow.LF||
'\brdrs';
    wwv_flow_api.g_varchar2_table(166) := '\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\cl';
    wwv_flow_api.g_varchar2_table(167) := 'ftsWidth3\clwWidth958\clcbpatraw17 \cellx6977\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10';
    wwv_flow_api.g_varchar2_table(168) := ' \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpat';
    wwv_flow_api.g_varchar2_table(169) := 'raw17 \cellx7865\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbr';
    wwv_flow_api.g_varchar2_table(170) := 'drr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx8450\clvertalt\clbr';
    wwv_flow_api.g_varchar2_table(171) := 'drt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\';
    wwv_flow_api.g_varchar2_table(172) := 'cltxlrtb\clftsWidth3\clwWidth958\clcbpatraw17 \cellx9468\row \ltrrow}\trowd \irow1\irowband1\lastrow';
    wwv_flow_api.g_varchar2_table(173) := ' \ltrrow\ts15\trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brd';
    wwv_flow_api.g_varchar2_table(174) := 'rw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB';
    wwv_flow_api.g_varchar2_table(175) := '3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid13592754\tbllkhdrr';
    wwv_flow_api.g_varchar2_table(176) := 'ows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\';
    wwv_flow_api.g_varchar2_table(177) := 'brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth957\clshdrawni';
    wwv_flow_api.g_varchar2_table(178) := 'l \cellx646\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\b';
    wwv_flow_api.g_varchar2_table(179) := 'rdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth957\clshdrawnil \cellx1775\clvertalt\clbrdrt'||wwv_flow.LF||
'\brdrs\brdr';
    wwv_flow_api.g_varchar2_table(180) := 'w10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWi';
    wwv_flow_api.g_varchar2_table(181) := 'dth957\clshdrawnil \cellx2864\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\';
    wwv_flow_api.g_varchar2_table(182) := 'brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth957\clshdrawnil \cellx3760\clvertalt\';
    wwv_flow_api.g_varchar2_table(183) := 'clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb';
    wwv_flow_api.g_varchar2_table(184) := '\clftsWidth3\clwWidth958\clshdrawnil \cellx4235\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brd';
    wwv_flow_api.g_varchar2_table(185) := 'rw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \ce';
    wwv_flow_api.g_varchar2_table(186) := 'llx5403\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs';
    wwv_flow_api.g_varchar2_table(187) := '\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cellx6977\clvertalt\clbrdrt\brdrs\brdrw10 ';
    wwv_flow_api.g_varchar2_table(188) := '\clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth9';
    wwv_flow_api.g_varchar2_table(189) := '58\clshdrawnil \cellx7865\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\br';
    wwv_flow_api.g_varchar2_table(190) := 'drw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cellx8450\clvertalt\clbr';
    wwv_flow_api.g_varchar2_table(191) := 'drt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\c';
    wwv_flow_api.g_varchar2_table(192) := 'lftsWidth3\clwWidth958\clshdrawnil \cellx9468\pard\plain \ltrpar\ql \li0\ri0\widctlpar\intbl\wrapdef';
    wwv_flow_api.g_varchar2_table(193) := 'ault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid13592754\yts15 \rtlch\fcs1 \af31507\afs22\';
    wwv_flow_api.g_varchar2_table(194) := 'alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\*\bkmkstart';
    wwv_flow_api.g_varchar2_table(195) := ' Text1}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid13592754\charrsid13';
    wwv_flow_api.g_varchar2_table(196) := '592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\cf9\insrsid13592754\charrsid13592754 {\*\data';
    wwv_flow_api.g_varchar2_table(197) := 'field 8001000000000000055465787431000246200000000000103c3f666f722d656163683a524f573f3e0000000000}{\*';
    wwv_flow_api.g_varchar2_table(198) := '\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext F }{\*\ffstattext ';
    wwv_flow_api.g_varchar2_table(199) := ''||wwv_flow.LF||
'<?for-each:ROW?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\i';
    wwv_flow_api.g_varchar2_table(200) := 'nsrsid13592754\charrsid13592754 F }}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\s';
    wwv_flow_api.g_varchar2_table(201) := 'ftnbj {\*\bkmkstart Text2}{\*\bkmkend Text1}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltr';
    wwv_flow_api.g_varchar2_table(202) := 'ch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592';
    wwv_flow_api.g_varchar2_table(203) := '754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874320007494e564f49434500000000000b3c3f4';
    wwv_flow_api.g_varchar2_table(204) := '94e564f4943453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\';
    wwv_flow_api.g_varchar2_table(205) := '*\ffdeftext INVOICE}{\*\ffstattext <?INVOICE?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \la';
    wwv_flow_api.g_varchar2_table(206) := 'ng1024\langfe1024\noproof\insrsid13592754\charrsid13592754 INVOICE}}}\sectd \ltrsect\linex0\endnhere';
    wwv_flow_api.g_varchar2_table(207) := '\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754 {\*\bkmkend';
    wwv_flow_api.g_varchar2_table(208) := ' Text2}\cell }\pard \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustr';
    wwv_flow_api.g_varchar2_table(209) := 'ight\rin0\lin0\yts15 {\*\bkmkstart Text3}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fc';
    wwv_flow_api.g_varchar2_table(210) := 's0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid13592754';
    wwv_flow_api.g_varchar2_table(211) := '\charrsid13592754 {\*\datafield 8001000000000000055465787433000a47554553545f4e414d4500000000000e3c3f';
    wwv_flow_api.g_varchar2_table(212) := '47554553545f4e414d453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname T';
    wwv_flow_api.g_varchar2_table(213) := 'ext3}{\*\ffdeftext GUEST_NAME}'||wwv_flow.LF||
'{\*\ffstattext <?GUEST_NAME?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \l';
    wwv_flow_api.g_varchar2_table(214) := 'trch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 GUEST_NAME}}}\sectd \ltrsect';
    wwv_flow_api.g_varchar2_table(215) := '\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \insrsid13';
    wwv_flow_api.g_varchar2_table(216) := '592754 {\*\bkmkend Text3}\cell {\*\bkmkstart Text4}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af3150';
    wwv_flow_api.g_varchar2_table(217) := '7 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsi';
    wwv_flow_api.g_varchar2_table(218) := 'd13592754\charrsid13592754 '||wwv_flow.LF||
'{\*\datafield 8001000000000000055465787434000a4f524445525f4441544500000';
    wwv_flow_api.g_varchar2_table(219) := '000000e3c3f4f524445525f444154453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{';
    wwv_flow_api.g_varchar2_table(220) := '\*\ffname Text4}{\*\ffdeftext ORDER_DATE}{\*\ffstattext <?ORDER_DATE?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 ';
    wwv_flow_api.g_varchar2_table(221) := '\af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 ORDER_DATE}}}\sec';
    wwv_flow_api.g_varchar2_table(222) := 'td \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \';
    wwv_flow_api.g_varchar2_table(223) := 'insrsid13592754 '||wwv_flow.LF||
'{\*\bkmkend Text4}\cell {\*\bkmkstart Text5}}{\field\flddirty{\*\fldinst {\rtlch\f';
    wwv_flow_api.g_varchar2_table(224) := 'cs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\f';
    wwv_flow_api.g_varchar2_table(225) := 'cs0 \insrsid13592754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874350008444953434f554e';
    wwv_flow_api.g_varchar2_table(226) := '5400000000000c3c3f444953434f554e543f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetx';
    wwv_flow_api.g_varchar2_table(227) := 't0{\*\ffname Text5}{\*\ffdeftext DISCOUNT}{\*\ffstattext <?DISCOUNT?>}}}}}{\fldrslt {\rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(228) := '31507 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 DISCOUNT}}}\sectd ';
    wwv_flow_api.g_varchar2_table(229) := '\ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \ins';
    wwv_flow_api.g_varchar2_table(230) := 'rsid13592754 {\*\bkmkend Text5}\cell {\*\bkmkstart Text6}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1';
    wwv_flow_api.g_varchar2_table(231) := ' \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0';
    wwv_flow_api.g_varchar2_table(232) := ' \insrsid13592754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'8001000000000000055465787436000356415400000000000';
    wwv_flow_api.g_varchar2_table(233) := '73c3f5641543f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\';
    wwv_flow_api.g_varchar2_table(234) := 'ffdeftext VAT}{\*\ffstattext <?VAT?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\lang1024\lan';
    wwv_flow_api.g_varchar2_table(235) := 'gfe1024\noproof\insrsid13592754\charrsid13592754 VAT}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid3';
    wwv_flow_api.g_varchar2_table(236) := '60\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754 {\*\bkmkend Text6}\cell {';
    wwv_flow_api.g_varchar2_table(237) := '\*\bkmkstart Text7}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754';
    wwv_flow_api.g_varchar2_table(238) := '\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 {\*';
    wwv_flow_api.g_varchar2_table(239) := '\datafield '||wwv_flow.LF||
'8001000000000000055465787437000b4752414e545f544f54414c00000000000f3c3f4752414e545f544f5';
    wwv_flow_api.g_varchar2_table(240) := '4414c3f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text7}{\*\ffdeft';
    wwv_flow_api.g_varchar2_table(241) := 'ext GRANT_TOTAL}{\*\ffstattext <?GRANT_TOTAL?>}}}}}{\fldrslt {'||wwv_flow.LF||
'\rtlch\fcs1 \af31507 \ltrch\fcs0 \la';
    wwv_flow_api.g_varchar2_table(242) := 'ng1024\langfe1024\noproof\insrsid13592754\charrsid13592754 GRANT_TOTAL}}}\sectd \ltrsect\linex0\endn';
    wwv_flow_api.g_varchar2_table(243) := 'here\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754 {\*\bkm';
    wwv_flow_api.g_varchar2_table(244) := 'kend Text7}\cell '||wwv_flow.LF||
'{\*\bkmkstart Text8}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs';
    wwv_flow_api.g_varchar2_table(245) := '0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\ch';
    wwv_flow_api.g_varchar2_table(246) := 'arrsid13592754 {\*\datafield '||wwv_flow.LF||
'8001000000000000055465787438000e464f4f445f4d454e555f4e414d45000000000';
    wwv_flow_api.g_varchar2_table(247) := '0123c3f464f4f445f4d454e555f4e414d453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypet';
    wwv_flow_api.g_varchar2_table(248) := 'xt0{\*\ffname Text8}{\*\ffdeftext FOOD_MENU_NAME}{\*\ffstattext <?FOOD_MENU_NAME?>}}}}'||wwv_flow.LF||
'}{\fldrslt {';
    wwv_flow_api.g_varchar2_table(249) := '\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 FOOD_';
    wwv_flow_api.g_varchar2_table(250) := 'MENU_NAME}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af315';
    wwv_flow_api.g_varchar2_table(251) := '07 \ltrch\fcs0 \insrsid13592754 '||wwv_flow.LF||
'{\*\bkmkend Text8}\cell {\*\bkmkstart Text9}}{\field\flddirty{\*\f';
    wwv_flow_api.g_varchar2_table(252) := 'ldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \';
    wwv_flow_api.g_varchar2_table(253) := 'af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'800100000000000005546578743900';
    wwv_flow_api.g_varchar2_table(254) := '085155414e5449545900000000000c3c3f5155414e544954593f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ff';
    wwv_flow_api.g_varchar2_table(255) := 'ownstat\fftypetxt0{\*\ffname Text9}{\*\ffdeftext QUANTITY}{\*\ffstattext <?QUANTITY?>}}}}}{\fldrslt ';
    wwv_flow_api.g_varchar2_table(256) := '{\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 QU';
    wwv_flow_api.g_varchar2_table(257) := 'ANTITY}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 ';
    wwv_flow_api.g_varchar2_table(258) := '\ltrch\fcs0 \insrsid13592754 {\*\bkmkend Text9}\cell {\*\bkmkstart Text10}}'||wwv_flow.LF||
'{\field\flddirty{\*\fld';
    wwv_flow_api.g_varchar2_table(259) := 'inst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(260) := '31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'80010000000000000654657874313000';
    wwv_flow_api.g_varchar2_table(261) := '0550524943450000000000093c3f50524943453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\ffty';
    wwv_flow_api.g_varchar2_table(262) := 'petxt0{\*\ffname Text10}{\*\ffdeftext PRICE}{\*\ffstattext <?PRICE?>}}}}}{\fldrslt {\rtlch\fcs1 \af3';
    wwv_flow_api.g_varchar2_table(263) := '1507 \ltrch\fcs0 '||wwv_flow.LF||
'\lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754 PRICE}}}\sectd \ltr';
    wwv_flow_api.g_varchar2_table(264) := 'sect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid';
    wwv_flow_api.g_varchar2_table(265) := '13592754 {\*\bkmkend Text10}\cell }\pard \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\wrapdefault\aspalpha\';
    wwv_flow_api.g_varchar2_table(266) := 'aspnum\faauto\adjustright\rin0\lin0\pararsid13592754\yts15 {\*\bkmkstart Text11}{\field\flddirty{\*\';
    wwv_flow_api.g_varchar2_table(267) := 'fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 ';
    wwv_flow_api.g_varchar2_table(268) := ''||wwv_flow.LF||
'\af31507 \ltrch\fcs0 \insrsid13592754\charrsid13592754 {\*\datafield 80010000000000000654657874313';
    wwv_flow_api.g_varchar2_table(269) := '1000a554e49545f544154414c00000000000e3c3f554e49545f544154414c3f3e0000000000}{\*\formfield{\fftype0\f';
    wwv_flow_api.g_varchar2_table(270) := 'fownhelp\ffownstat\fftypetxt0{\*\ffname Text11}'||wwv_flow.LF||
'{\*\ffdeftext UNIT_TATAL}{\*\ffstattext <?UNIT_TATA';
    wwv_flow_api.g_varchar2_table(271) := 'L?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid13592754\cha';
    wwv_flow_api.g_varchar2_table(272) := 'rrsid13592754 UNIT_TATAL}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sftnbj '||wwv_flow.LF||
'{\';
    wwv_flow_api.g_varchar2_table(273) := '*\bkmkstart Text12}{\*\bkmkend Text11}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af31507 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(274) := '\cf9\insrsid13592754\charrsid13592754  FORMTEXT }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \cf9\insrsid13592';
    wwv_flow_api.g_varchar2_table(275) := '754\charrsid13592754 {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743132000220450000000000103c3f656e64206';
    wwv_flow_api.g_varchar2_table(276) := '66f722d656163683f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text12';
    wwv_flow_api.g_varchar2_table(277) := '}{\*\ffdeftext  E}{\*\ffstattext <?end for-each?>}}}}}{\fldrslt {\rtlch\fcs1 \af31507 '||wwv_flow.LF||
'\ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(278) := '\cf9\lang1024\langfe1024\noproof\insrsid13592754\charrsid13592754  E}}}\sectd \ltrsect\linex0\endnhe';
    wwv_flow_api.g_varchar2_table(279) := 're\sectlinegrid360\sectdefaultcl\sftnbj {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid13592754 {\*\bkmke';
    wwv_flow_api.g_varchar2_table(280) := 'nd Text12}\cell }\pard\plain \ltrpar'||wwv_flow.LF||
'\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\a';
    wwv_flow_api.g_varchar2_table(281) := 'spalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af31507\afs22\alang1025 \ltrch\fcs0 \f31506';
    wwv_flow_api.g_varchar2_table(282) := '\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af31507 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid';
    wwv_flow_api.g_varchar2_table(283) := '13592754 \trowd \irow1\irowband1\lastrow \ltrrow\ts15\trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \tr';
    wwv_flow_api.g_varchar2_table(284) := 'brdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\br';
    wwv_flow_api.g_varchar2_table(285) := 'drs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddf';
    wwv_flow_api.g_varchar2_table(286) := 'b3\trpaddfr3\tblrsid13592754\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt';
    wwv_flow_api.g_varchar2_table(287) := '\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrr\brdrs\brdrw10 \cltxl';
    wwv_flow_api.g_varchar2_table(288) := 'rtb\clftsWidth3\clwWidth957\clshdrawnil \cellx646\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brd';
    wwv_flow_api.g_varchar2_table(289) := 'rw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth957\clshdrawnil \ce';
    wwv_flow_api.g_varchar2_table(290) := 'llx1775\clvertalt\clbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brd';
    wwv_flow_api.g_varchar2_table(291) := 'rs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth957\clshdrawnil \cellx2864\clvertalt\clbrdrt\brdrs\brdrw10 ';
    wwv_flow_api.g_varchar2_table(292) := '\clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidt';
    wwv_flow_api.g_varchar2_table(293) := 'h957\clshdrawnil \cellx3760\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\br';
    wwv_flow_api.g_varchar2_table(294) := 'drw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cellx4235\clvertalt\clbr';
    wwv_flow_api.g_varchar2_table(295) := 'drt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\c';
    wwv_flow_api.g_varchar2_table(296) := 'lftsWidth3\clwWidth958\clshdrawnil \cellx5403\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10';
    wwv_flow_api.g_varchar2_table(297) := ' \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cell';
    wwv_flow_api.g_varchar2_table(298) := 'x6977\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\b';
    wwv_flow_api.g_varchar2_table(299) := 'rdrw10 \cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cellx7865\clvertalt\clbrdrt\brdrs\brdrw10 \clb';
    wwv_flow_api.g_varchar2_table(300) := 'rdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth958';
    wwv_flow_api.g_varchar2_table(301) := '\clshdrawnil \cellx8450\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw1';
    wwv_flow_api.g_varchar2_table(302) := '0 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth958\clshdrawnil \cellx9468\row }\pard \ltrp';
    wwv_flow_api.g_varchar2_table(303) := 'ar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin';
    wwv_flow_api.g_varchar2_table(304) := '0\itap0 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid3433759 '||wwv_flow.LF||
'\par }{\*\themedata 504b0304140006000800';
    wwv_flow_api.g_varchar2_table(305) := '00002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc';
    wwv_flow_api.g_varchar2_table(306) := '83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3';
    wwv_flow_api.g_varchar2_table(307) := '989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'5689811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d';
    wwv_flow_api.g_varchar2_table(308) := '8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f36';
    wwv_flow_api.g_varchar2_table(309) := '4eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(310) := '0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b';
    wwv_flow_api.g_varchar2_table(311) := '030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85';
    wwv_flow_api.g_varchar2_table(312) := 'bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e72016';
    wwv_flow_api.g_varchar2_table(313) := '9aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc';
    wwv_flow_api.g_varchar2_table(314) := '52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce5';
    wwv_flow_api.g_varchar2_table(315) := '45046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b';
    wwv_flow_api.g_varchar2_table(316) := '799616830000008a0000001c0000007468656d652f746865'||wwv_flow.LF||
'6d652f7468656d654d616e616765722e786d6c0ccc4d0ac320';
    wwv_flow_api.g_varchar2_table(317) := '1040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd';
    wwv_flow_api.g_varchar2_table(318) := '2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9';
    wwv_flow_api.g_varchar2_table(319) := '246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010000ffff0300504b03041400060008000000210030dd4329a8060000a4';
    wwv_flow_api.g_varchar2_table(320) := '1b0000160000007468656d652f7468656d652f'||wwv_flow.LF||
'7468656d65312e786d6cec594f6fdb3614bf0fd87720746f6327761a0775';
    wwv_flow_api.g_varchar2_table(321) := '8ad8b19b2d4d1bc46e871e698996d850a240d2497d1bdae38001c3ba618715d86d87'||wwv_flow.LF||
'615b8116d8a5fb34d93a6c1dd0afb0';
    wwv_flow_api.g_varchar2_table(322) := '475292c5585e9236d88aad3e2412f9e3fbff1e1fa9abd7eec70c1d1221294fda5efd72cd4324f1794093b0eddd1ef62fad'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(323) := '79482a9c0498f184b4bd2991deb58df7dfbb8ad755446282607d22d771db8b944ad79796a40fc3585ee62949606ecc458c15';
    wwv_flow_api.g_varchar2_table(324) := 'bc8a702910f808e8c66c69b9565b'||wwv_flow.LF||
'5d8a314d3c94e018c8de1a8fa94fd05093f43672e23d06af89927ac06762a049136785';
    wwv_flow_api.g_varchar2_table(325) := 'c10607758d9053d965021d62d6f6804fc08f86e4bef210c352c144dbab'||wwv_flow.LF||
'999fb7b4717509af678b985ab0b6b4ae6f7ed9ba';
    wwv_flow_api.g_varchar2_table(326) := '6c4170b06c788a705430adf71bad2b5b057d03606a1ed7ebf5babd7a41cf00b0ef83a6569632cd467faddec9'||wwv_flow.LF||
'699640f671';
    wwv_flow_api.g_varchar2_table(327) := '9e76b7d6ac355c7c89feca9cccad4ea7d36c65b258a206641f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8';
    wwv_flow_api.g_varchar2_table(328) := 'e257e7f0fd2badd586'||wwv_flow.LF||
'8b37a088d1e4600ead1ddaef67d40bc898b3ed4af81ac0d76a197c86826828a24bb318f3442d8ab5';
    wwv_flow_api.g_varchar2_table(329) := '18dfe3a20f000d6458d104a9694ac6d88728eee2782428d6'||wwv_flow.LF||
'0cf03ac1a5193be4cbb921cd0b495fd054b5bd0f530c1931a3';
    wwv_flow_api.g_varchar2_table(330) := 'f7eaf9f7af9e3f45c70f9e1d3ff8e9f8e1c3e3073f5a42ceaa6d9c84e5552fbffdeccfc71fa33f'||wwv_flow.LF||
'9e7ef3f2d117d57859c6';
    wwv_flow_api.g_varchar2_table(331) := 'fffac327bffcfc793510d26726ce8b2f9ffcf6ecc98baf3efdfdbb4715f04d814765f890c644a29be408edf3181433567125';
    wwv_flow_api.g_varchar2_table(332) := '272371be'||wwv_flow.LF||
'15c308d3f28acd249438c19a4b05fd9e8a1cf4cd296699771c393ac4b5e01d01e5a30a787d72cf1178108989a2';
    wwv_flow_api.g_varchar2_table(333) := '159c77a2d801ee72ce3a5c545a6147f32a9979'||wwv_flow.LF||
'3849c26ae66252c6ed637c58c5bb8b13c7bfbd490a75330f4b47f16e441c';
    wwv_flow_api.g_varchar2_table(334) := '31f7184e140e494214d273fc80900aedee52ead87597fa824b3e56e82e451d4c2b4d'||wwv_flow.LF||
'32a423279a668bb6690c7e9956e90c';
    wwv_flow_api.g_varchar2_table(335) := 'fe766cb37b077538abd27a8b1cba48c80acc2a841f12e698f13a9e281c57911ce298950d7e03aba84ac8c154f8655c4f2a'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(336) := 'f074481847bd804859b5e696007d4b4edfc150b12addbecba6b18b148a1e54d1bc81392f23b7f84137c2715a851dd0242a63';
    wwv_flow_api.g_varchar2_table(337) := '3f900710a218ed715505dfe56e86'||wwv_flow.LF||
'e877f0034e16bafb0e258ebb4faf06b769e888340b103d331115bebc4eb813bf83291b';
    wwv_flow_api.g_varchar2_table(338) := '63624a0d1475a756c734f9bbc2cd28546ecbe1e20a3794ca175f3fae90'||wwv_flow.LF||
'fb6d2dd99bb07b55e5ccf68942bd0877b23c77b9';
    wwv_flow_api.g_varchar2_table(339) := '08e8db5f9db7f024d9239010f35bd4bbe2fcae387bfff9e2bc289f2fbe24cfaa301468dd8bd846dbb4ddf1c2'||wwv_flow.LF||
'ae7b4c191b';
    wwv_flow_api.g_varchar2_table(340) := 'a8292337a469bc25ec3d411f06f53a73e224c5292c8de0516732307070a1c0660d125c7d44553488700a4d7bddd344429991';
    wwv_flow_api.g_varchar2_table(341) := '0e254ab984c3a219ae'||wwv_flow.LF||
'a4adf1d0f82b7bd46cea4388ad1c12ab5d1ed8e1153d9c9f350a3246aad01c6873462b9ac05999ad';
    wwv_flow_api.g_varchar2_table(342) := '5cc988826eafc3acae853a33b7ba11cd1445875ba1b236b1'||wwv_flow.LF||
'399483c90bd560b0b0263435085a21b0f22a9cf9356b38ec60';
    wwv_flow_api.g_varchar2_table(343) := '46026d77eba3dc2dc60b17e92219e180643ed27acffba86e9c94c7ca9c225a0f1b0cfae0788ad5'||wwv_flow.LF||
'4adc5a9aec1b703b8b93';
    wwv_flow_api.g_varchar2_table(344) := 'caec1a0bd8e5de7b132fe5113cf312503b998e2c2927274bd051db6b35979b1ef271daf6c6704e86c73805af4bdd476216c2';
    wwv_flow_api.g_varchar2_table(345) := '6593af84'||wwv_flow.LF||
'0dfb5393d964f9cc9bad5c313709ea70f561ed3ea7b053075221d51696910d0d339585004b34272bff7213cc7a';
    wwv_flow_api.g_varchar2_table(346) := '510a5454a3b349b1b206c1f0af490176745d4b'||wwv_flow.LF||
'c663e2abb2b34b23da76f6352ba57ca2881844c1111ab189d8c7e07e1daa';
    wwv_flow_api.g_varchar2_table(347) := 'a04f40255c77988aa05fe06e4e5bdb4cb9c5394bbaf28d98c1d971ccd20867e556a7'||wwv_flow.LF||
'689ec9166e0a522183792b8907ba55';
    wwv_flow_api.g_varchar2_table(348) := 'ca6e943bbf2a26e52f48957218ffcf54d1fb09dc3eac04da033e5c0d0b8c74a6b43d2e54c4a10aa511f5fb021a07533b20'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(349) := '5ae07e17a621a8e082dafc17e450ffb739676998b48643a4daa7211214f623150942f6a02c99e83b85583ddbbb2c49961132';
    wwv_flow_api.g_varchar2_table(350) := '11551257a656ec1139246ca86be0'||wwv_flow.LF||
'aadedb3d1441a89b6a929501833b197fee7b9641a3503739e57c732a59b1f7da1cf8a7';
    wwv_flow_api.g_varchar2_table(351) := '3b1f9bcca0945b874d4393dbbf10b1680f66bbaa5d6f96e77b6f59113d'||wwv_flow.LF||
'316bb31a795600b3d256d0cad2fe354538e7566b';
    wwv_flow_api.g_varchar2_table(352) := '2bd69cc6cbcd5c38f0e2bcc63058344429dc2121fd07f63f2a7c66bf76e80d75c8f7a1b622f878a18941d840'||wwv_flow.LF||
'545fb28d07';
    wwv_flow_api.g_varchar2_table(353) := 'd205d20e8ea071b283369834296bdaac75d256cb37eb0bee740bbe278cad253b8bbfcf69eca23973d939b97891c6ce2cecd8';
    wwv_flow_api.g_varchar2_table(354) := 'da8e2d343578f6648a'||wwv_flow.LF||
'c2d0383fc818c798cf64e52f597c740f1cbd05df0c264c49134cf09d4a60e8a107260f20f92d47b3';
    wwv_flow_api.g_varchar2_table(355) := '74e32f000000ffff0300504b030414000600080000002100'||wwv_flow.LF||
'0dd1909fb60000001b010000270000007468656d652f746865';
    wwv_flow_api.g_varchar2_table(356) := '6d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f7'||wwv_flow.LF||
'8277086f6fd3ba109126';
    wwv_flow_api.g_varchar2_table(357) := 'dd88d0add40384e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec8e40';
    wwv_flow_api.g_varchar2_table(358) := '52164e89'||wwv_flow.LF||
'd93b64b060828e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8';
    wwv_flow_api.g_varchar2_table(359) := 'bbd048f7757da0f19b017cc524bd62107bd500'||wwv_flow.LF||
'1996509affb3fd381a89672f1f165dfe514173d9850528a2c6cce0239baa';
    wwv_flow_api.g_varchar2_table(360) := '4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0f'||wwv_flow.LF||
'bfff0000001c020000130000000000';
    wwv_flow_api.g_varchar2_table(361) := '0000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100a5d6'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(362) := 'a7e7c0000000360100000b00000000000000000000000000300100005f72656c732f2e72656c73504b01022d001400060008';
    wwv_flow_api.g_varchar2_table(363) := '00000021006b799616830000008a'||wwv_flow.LF||
'0000001c00000000000000000000000000190200007468656d652f7468656d652f7468';
    wwv_flow_api.g_varchar2_table(364) := '656d654d616e616765722e786d6c504b01022d00140006000800000021'||wwv_flow.LF||
'0030dd4329a8060000a41b000016000000000000';
    wwv_flow_api.g_varchar2_table(365) := '00000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d001400060008'||wwv_flow.LF||
'0000002100';
    wwv_flow_api.g_varchar2_table(366) := '0dd1909fb60000001b0100002700000000000000000000000000b20900007468656d652f7468656d652f5f72656c732f7468';
    wwv_flow_api.g_varchar2_table(367) := '656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000ad0a00000000}'||wwv_flow.LF||
'{\*\colorscheme';
    wwv_flow_api.g_varchar2_table(368) := 'mapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e';
    wwv_flow_api.g_varchar2_table(369) := '653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e';
    wwv_flow_api.g_varchar2_table(370) := '786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22206267313d226c74312220747831';
    wwv_flow_api.g_varchar2_table(371) := '3d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363'||wwv_flow.LF||
'65';
    wwv_flow_api.g_varchar2_table(372) := '6e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220';
    wwv_flow_api.g_varchar2_table(373) := '616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220';
    wwv_flow_api.g_varchar2_table(374) := '666f6c486c696e6b3d22666f6c486c696e6b222f3e}'||wwv_flow.LF||
'{\*\latentstyles\lsdstimax267\lsdlockeddef0\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(375) := 'endef1\lsdunhideuseddef1\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcept \lsdsemihidden0 \lsdunhide';
    wwv_flow_api.g_varchar2_table(376) := 'used0 \lsdqformat1 \lsdpriority0 \lsdlocked0 Normal;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \';
    wwv_flow_api.g_varchar2_table(377) := 'lsdpriority9 \lsdlocked0 heading 1;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdqformat1 \ls';
    wwv_flow_api.g_varchar2_table(378) := 'dpriority9 \lsdlocked0 heading 3;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdqformat1 \ls';
    wwv_flow_api.g_varchar2_table(379) := 'dpriority9 \lsdlocked0 heading 5;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 6;\lsdqformat1 \lsdp';
    wwv_flow_api.g_varchar2_table(380) := 'riority9 \lsdlocked0 heading 7;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdqformat1 \lsdpri';
    wwv_flow_api.g_varchar2_table(381) := 'ority9 \lsdlocked0 heading 9;'||wwv_flow.LF||
'\lsdpriority39 \lsdlocked0 toc 1;\lsdpriority39 \lsdlocked0 toc 2;\ls';
    wwv_flow_api.g_varchar2_table(382) := 'dpriority39 \lsdlocked0 toc 3;\lsdpriority39 \lsdlocked0 toc 4;\lsdpriority39 \lsdlocked0 toc 5;\lsd';
    wwv_flow_api.g_varchar2_table(383) := 'priority39 \lsdlocked0 toc 6;\lsdpriority39 \lsdlocked0 toc 7;'||wwv_flow.LF||
'\lsdpriority39 \lsdlocked0 toc 8;\ls';
    wwv_flow_api.g_varchar2_table(384) := 'dpriority39 \lsdlocked0 toc 9;\lsdqformat1 \lsdpriority35 \lsdlocked0 caption;\lsdsemihidden0 \lsdun';
    wwv_flow_api.g_varchar2_table(385) := 'hideused0 \lsdqformat1 \lsdpriority10 \lsdlocked0 Title;\lsdpriority1 \lsdlocked0 Default Paragraph ';
    wwv_flow_api.g_varchar2_table(386) := 'Font;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(387) := 'en0 \lsdunhideused0 \lsdqformat1 \lsdpriority22 \lsdlocked0 Strong;\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(388) := 'lsdqformat1 \lsdpriority20 \lsdlocked0 Emphasis;'||wwv_flow.LF||
'\lsdpriority59 \lsdlocked0 Table Grid;\lsdunhideus';
    wwv_flow_api.g_varchar2_table(389) := 'ed0 \lsdlocked0 Placeholder Text;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority1 \lsdlock';
    wwv_flow_api.g_varchar2_table(390) := 'ed0 No Spacing;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading;'||wwv_flow.LF||
'\lsdsemihi';
    wwv_flow_api.g_varchar2_table(391) := 'dden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List;\lsdsemihidden0 \lsdunhideused0 \lsdprio';
    wwv_flow_api.g_varchar2_table(392) := 'rity62 \lsdlocked0 Light Grid;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shad';
    wwv_flow_api.g_varchar2_table(393) := 'ing 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2;\lsdsemihidden0 ';
    wwv_flow_api.g_varchar2_table(394) := '\lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriorit';
    wwv_flow_api.g_varchar2_table(395) := 'y66 \lsdlocked0 Medium List 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Gr';
    wwv_flow_api.g_varchar2_table(396) := 'id 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdsemihidden0 \lsdun';
    wwv_flow_api.g_varchar2_table(397) := 'hideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 ';
    wwv_flow_api.g_varchar2_table(398) := '\lsdlocked0 Dark List;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading;\l';
    wwv_flow_api.g_varchar2_table(399) := 'sdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideu';
    wwv_flow_api.g_varchar2_table(400) := 'sed0 \lsdpriority73 \lsdlocked0 Colorful Grid;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdloc';
    wwv_flow_api.g_varchar2_table(401) := 'ked0 Light Shading Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Ac';
    wwv_flow_api.g_varchar2_table(402) := 'cent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(403) := 'en0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdsemihidden0 \lsdunhideu';
    wwv_flow_api.g_varchar2_table(404) := 'sed0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdprio';
    wwv_flow_api.g_varchar2_table(405) := 'rity65 \lsdlocked0 Medium List 1 Accent 1;\lsdunhideused0 \lsdlocked0 Revision;\lsdsemihidden0 \lsdu';
    wwv_flow_api.g_varchar2_table(406) := 'nhideused0 \lsdqformat1 \lsdpriority34 \lsdlocked0 List Paragraph;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(407) := '\lsdqformat1 \lsdpriority29 \lsdlocked0 Quote;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdprior';
    wwv_flow_api.g_varchar2_table(408) := 'ity30 \lsdlocked0 Intense Quote;\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium Li';
    wwv_flow_api.g_varchar2_table(409) := 'st 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;\l';
    wwv_flow_api.g_varchar2_table(410) := 'sdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 1;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(411) := 'unhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(412) := 'priority70 \lsdlocked0 Dark List Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0';
    wwv_flow_api.g_varchar2_table(413) := ' Colorful Shading Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List ';
    wwv_flow_api.g_varchar2_table(414) := 'Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdsem';
    wwv_flow_api.g_varchar2_table(415) := 'ihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 2;\lsdsemihidden0 \lsdunhid';
    wwv_flow_api.g_varchar2_table(416) := 'eused0 \lsdpriority61 \lsdlocked0 Light List Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority';
    wwv_flow_api.g_varchar2_table(417) := '62 \lsdlocked0 Light Grid Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium';
    wwv_flow_api.g_varchar2_table(418) := ' Shading 1 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Acce';
    wwv_flow_api.g_varchar2_table(419) := 'nt 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(420) := 'den0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 2;\lsdsemihidden0 \lsdunhideuse';
    wwv_flow_api.g_varchar2_table(421) := 'd0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority6';
    wwv_flow_api.g_varchar2_table(422) := '8 \lsdlocked0 Medium Grid 2 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medi';
    wwv_flow_api.g_varchar2_table(423) := 'um Grid 3 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 2;'||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(424) := 'lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 2;\lsdsemihidden0 ';
    wwv_flow_api.g_varchar2_table(425) := '\lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 2;\lsdsemihidden0 \lsdunhideused0 \l';
    wwv_flow_api.g_varchar2_table(426) := 'sdpriority73 \lsdlocked0 Colorful Grid Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \ls';
    wwv_flow_api.g_varchar2_table(427) := 'dlocked0 Light Shading Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light Lis';
    wwv_flow_api.g_varchar2_table(428) := 't Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 3;'||wwv_flow.LF||
'\lsdsemi';
    wwv_flow_api.g_varchar2_table(429) := 'hidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdsemihidden0 \lsdunh';
    wwv_flow_api.g_varchar2_table(430) := 'ideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(431) := 'iority65 \lsdlocked0 Medium List 1 Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdloc';
    wwv_flow_api.g_varchar2_table(432) := 'ked0 Medium List 2 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1';
    wwv_flow_api.g_varchar2_table(433) := ' Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 3;'||wwv_flow.LF||
'\lsdse';
    wwv_flow_api.g_varchar2_table(434) := 'mihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(435) := 'deused0 \lsdpriority70 \lsdlocked0 Dark List Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71';
    wwv_flow_api.g_varchar2_table(436) := ' \lsdlocked0 Colorful Shading Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 ';
    wwv_flow_api.g_varchar2_table(437) := 'Colorful List Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Acce';
    wwv_flow_api.g_varchar2_table(438) := 'nt 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 4;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_api.g_varchar2_table(439) := 'den0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(440) := '\lsdpriority62 \lsdlocked0 Light Grid Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlo';
    wwv_flow_api.g_varchar2_table(441) := 'cked0 Medium Shading 1 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium ';
    wwv_flow_api.g_varchar2_table(442) := 'Shading 2 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 4';
    wwv_flow_api.g_varchar2_table(443) := ';\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0';
    wwv_flow_api.g_varchar2_table(444) := ' \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(445) := 'lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsd';
    wwv_flow_api.g_varchar2_table(446) := 'locked0 Medium Grid 3 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark Lis';
    wwv_flow_api.g_varchar2_table(447) := 't Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsd';
    wwv_flow_api.g_varchar2_table(448) := 'semihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(449) := 'unhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(450) := 'iority60 \lsdlocked0 Light Shading Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocke';
    wwv_flow_api.g_varchar2_table(451) := 'd0 Light List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accen';
    wwv_flow_api.g_varchar2_table(452) := 't 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(453) := 'den0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(454) := 'deused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriori';
    wwv_flow_api.g_varchar2_table(455) := 'ty66 \lsdlocked0 Medium List 2 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 M';
    wwv_flow_api.g_varchar2_table(456) := 'edium Grid 1 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Acc';
    wwv_flow_api.g_varchar2_table(457) := 'ent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(458) := 'en0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(459) := '\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 ';
    wwv_flow_api.g_varchar2_table(460) := '\lsdlocked0 Colorful List Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorf';
    wwv_flow_api.g_varchar2_table(461) := 'ul Grid Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 6';
    wwv_flow_api.g_varchar2_table(462) := ';\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(463) := 'unhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpri';
    wwv_flow_api.g_varchar2_table(464) := 'ority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdloc';
    wwv_flow_api.g_varchar2_table(465) := 'ked0 Medium Shading 2 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium Lis';
    wwv_flow_api.g_varchar2_table(466) := 't 1 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 6;\ls';
    wwv_flow_api.g_varchar2_table(467) := 'dsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdsemihidden0 \lsdu';
    wwv_flow_api.g_varchar2_table(468) := 'nhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdp';
    wwv_flow_api.g_varchar2_table(469) := 'riority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlock';
    wwv_flow_api.g_varchar2_table(470) := 'ed0 Dark List Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading A';
    wwv_flow_api.g_varchar2_table(471) := 'ccent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 6;\lsdsemi';
    wwv_flow_api.g_varchar2_table(472) := 'hidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdsemihidden0 \lsdunhide';
    wwv_flow_api.g_varchar2_table(473) := 'used0 \lsdqformat1 \lsdpriority19 \lsdlocked0 Subtle Emphasis;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(474) := 'qformat1 \lsdpriority21 \lsdlocked0 Intense Emphasis;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \l';
    wwv_flow_api.g_varchar2_table(475) := 'sdpriority31 \lsdlocked0 Subtle Reference;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriorit';
    wwv_flow_api.g_varchar2_table(476) := 'y32 \lsdlocked0 Intense Reference;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority33 \lsdlo';
    wwv_flow_api.g_varchar2_table(477) := 'cked0 Book Title;\lsdpriority37 \lsdlocked0 Bibliography;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority39 \lsdlocked0 T';
    wwv_flow_api.g_varchar2_table(478) := 'OC Heading;}}{\*\datastore 0105000002000000180000004d73786d6c322e534158584d4c5265616465722e362e30000';
    wwv_flow_api.g_varchar2_table(479) := '00000000000000000060000'||wwv_flow.LF||
'd0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000';
    wwv_flow_api.g_varchar2_table(480) := '000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000fffffffffffffff';
    wwv_flow_api.g_varchar2_table(481) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(482) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(483) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(484) := 'fffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(485) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(486) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffff';
    wwv_flow_api.g_varchar2_table(487) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(488) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(489) := 'fffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffdfffffffefffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(490) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(491) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(492) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(493) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(494) := 'fffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(495) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(496) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(497) := 'f'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(498) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(499) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f0';
    wwv_flow_api.g_varchar2_table(500) := '07400200045006e0074007200790000000000000000000000000000000000000000000000000000000000000000000000000';
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(501) := '0000000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e50000000000000000000';
    wwv_flow_api.g_varchar2_table(502) := '000003058'||wwv_flow.LF||
'771f64a8d701feffffff000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(503) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000fffffffffffffffff';
    wwv_flow_api.g_varchar2_table(504) := 'fffffff00000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(505) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(506) := '00000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(507) := '00000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(508) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f';
    wwv_flow_api.g_varchar2_table(509) := 'fffffffffffffffffffffff000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(510) := '0000000000000000000000105000000000000}}';
wwv_flow_api.create_report_layout(
 p_id=>wwv_flow_api.id(33446810895390078339)
,p_report_layout_name=>'bill'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_api.g_varchar2_table
);
wwv_flow_api.component_end;
end;
/
