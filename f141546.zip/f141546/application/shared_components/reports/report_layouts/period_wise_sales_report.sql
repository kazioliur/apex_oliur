prompt --application/shared_components/reports/report_layouts/period_wise_sales_report
begin
--   Manifest
--     REPORT LAYOUT: period_wise_sales_report
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
    wwv_flow_api.g_varchar2_table(1) := '{\rtf1\adeflang1025\ansi\ansicpg1252\uc1\adeff0\deff0\stshfdbch0\stshfloch31506\stshfhich31506\stshf';
    wwv_flow_api.g_varchar2_table(2) := 'bi31506\deflang1033\deflangfe1033\themelang1033\themelangfe0\themelangcs0{\fonttbl{\f0\fbidi \froman';
    wwv_flow_api.g_varchar2_table(3) := '\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f34\fbidi \froman\fcharset0\fprq2';
    wwv_flow_api.g_varchar2_table(4) := '{\*\panose 02040503050406030204}Cambria Math;}'||wwv_flow.LF||
'{\f37\fbidi \fswiss\fcharset0\fprq2{\*\panose 020f05';
    wwv_flow_api.g_varchar2_table(5) := '02020204030204}Calibri;}{\f40\fbidi \fswiss\fcharset0\fprq2{\*\panose 020b0604030504040204}Tahoma;}{';
    wwv_flow_api.g_varchar2_table(6) := '\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\f';
    wwv_flow_api.g_varchar2_table(7) := 'dbmajor\f31501\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fhima';
    wwv_flow_api.g_varchar2_table(8) := 'jor\f31502\fbidi \froman\fcharset0\fprq2{\*\panose 02040503050406030204}Cambria;}'||wwv_flow.LF||
'{\fbimajor\f31503';
    wwv_flow_api.g_varchar2_table(9) := '\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\flominor\f31504\fbi';
    wwv_flow_api.g_varchar2_table(10) := 'di \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}'||wwv_flow.LF||
'{\fdbminor\f31505\fbidi';
    wwv_flow_api.g_varchar2_table(11) := ' \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fhiminor\f31506\fbidi \fs';
    wwv_flow_api.g_varchar2_table(12) := 'wiss\fcharset0\fprq2{\*\panose 020f0502020204030204}Calibri;}'||wwv_flow.LF||
'{\fbiminor\f31507\fbidi \froman\fchar';
    wwv_flow_api.g_varchar2_table(13) := 'set0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f285\fbidi \froman\fcharset238\fprq2 Ti';
    wwv_flow_api.g_varchar2_table(14) := 'mes New Roman CE;}{\f286\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\f288\fbidi \froman';
    wwv_flow_api.g_varchar2_table(15) := '\fcharset161\fprq2 Times New Roman Greek;}{\f289\fbidi \froman\fcharset162\fprq2 Times New Roman Tur';
    wwv_flow_api.g_varchar2_table(16) := ';}{\f290\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f291\fbidi \froman\fcharset178\';
    wwv_flow_api.g_varchar2_table(17) := 'fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f292\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\f';
    wwv_flow_api.g_varchar2_table(18) := '293\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f625\fbidi \froman\fcharset238\f';
    wwv_flow_api.g_varchar2_table(19) := 'prq2 Cambria Math CE;}{\f626\fbidi \froman\fcharset204\fprq2 Cambria Math Cyr;}'||wwv_flow.LF||
'{\f628\fbidi \froma';
    wwv_flow_api.g_varchar2_table(20) := 'n\fcharset161\fprq2 Cambria Math Greek;}{\f629\fbidi \froman\fcharset162\fprq2 Cambria Math Tur;}{\f';
    wwv_flow_api.g_varchar2_table(21) := '632\fbidi \froman\fcharset186\fprq2 Cambria Math Baltic;}{\f633\fbidi \froman\fcharset163\fprq2 Camb';
    wwv_flow_api.g_varchar2_table(22) := 'ria Math (Vietnamese);}'||wwv_flow.LF||
'{\f655\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}{\f656\fbidi \fswiss\fch';
    wwv_flow_api.g_varchar2_table(23) := 'arset204\fprq2 Calibri Cyr;}{\f658\fbidi \fswiss\fcharset161\fprq2 Calibri Greek;}{\f659\fbidi \fswi';
    wwv_flow_api.g_varchar2_table(24) := 'ss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\f660\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\f661\';
    wwv_flow_api.g_varchar2_table(25) := 'fbidi \fswiss\fcharset178\fprq2 Calibri (Arabic);}{\f662\fbidi \fswiss\fcharset186\fprq2 Calibri Bal';
    wwv_flow_api.g_varchar2_table(26) := 'tic;}{\f663\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}'||wwv_flow.LF||
'{\f685\fbidi \fswiss\fcharset238';
    wwv_flow_api.g_varchar2_table(27) := '\fprq2 Tahoma CE;}{\f686\fbidi \fswiss\fcharset204\fprq2 Tahoma Cyr;}{\f688\fbidi \fswiss\fcharset16';
    wwv_flow_api.g_varchar2_table(28) := '1\fprq2 Tahoma Greek;}{\f689\fbidi \fswiss\fcharset162\fprq2 Tahoma Tur;}'||wwv_flow.LF||
'{\f690\fbidi \fswiss\fcha';
    wwv_flow_api.g_varchar2_table(29) := 'rset177\fprq2 Tahoma (Hebrew);}{\f691\fbidi \fswiss\fcharset178\fprq2 Tahoma (Arabic);}{\f692\fbidi ';
    wwv_flow_api.g_varchar2_table(30) := '\fswiss\fcharset186\fprq2 Tahoma Baltic;}{\f693\fbidi \fswiss\fcharset163\fprq2 Tahoma (Vietnamese);';
    wwv_flow_api.g_varchar2_table(31) := '}'||wwv_flow.LF||
'{\f694\fbidi \fswiss\fcharset222\fprq2 Tahoma (Thai);}{\flomajor\f31508\fbidi \froman\fcharset238';
    wwv_flow_api.g_varchar2_table(32) := '\fprq2 Times New Roman CE;}{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(33) := '{\flomajor\f31511\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flomajor\f31512\fbidi \fr';
    wwv_flow_api.g_varchar2_table(34) := 'oman\fcharset162\fprq2 Times New Roman Tur;}{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times ';
    wwv_flow_api.g_varchar2_table(35) := 'New Roman (Hebrew);}'||wwv_flow.LF||
'{\flomajor\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\';
    wwv_flow_api.g_varchar2_table(36) := 'flomajor\f31515\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flomajor\f31516\fbidi \fro';
    wwv_flow_api.g_varchar2_table(37) := 'man\fcharset163\fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fdbmajor\f31518\fbidi \froman\fcharset238\fp';
    wwv_flow_api.g_varchar2_table(38) := 'rq2 Times New Roman CE;}{\fdbmajor\f31519\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdb';
    wwv_flow_api.g_varchar2_table(39) := 'major\f31521\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}'||wwv_flow.LF||
'{\fdbmajor\f31522\fbidi \froma';
    wwv_flow_api.g_varchar2_table(40) := 'n\fcharset162\fprq2 Times New Roman Tur;}{\fdbmajor\f31523\fbidi \froman\fcharset177\fprq2 Times New';
    wwv_flow_api.g_varchar2_table(41) := ' Roman (Hebrew);}{\fdbmajor\f31524\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdb';
    wwv_flow_api.g_varchar2_table(42) := 'major\f31525\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbmajor\f31526\fbidi \froman';
    wwv_flow_api.g_varchar2_table(43) := '\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fhimajor\f31528\fbidi \froman\fcharset238\fprq2 C';
    wwv_flow_api.g_varchar2_table(44) := 'ambria CE;}'||wwv_flow.LF||
'{\fhimajor\f31529\fbidi \froman\fcharset204\fprq2 Cambria Cyr;}{\fhimajor\f31531\fbidi ';
    wwv_flow_api.g_varchar2_table(45) := '\froman\fcharset161\fprq2 Cambria Greek;}{\fhimajor\f31532\fbidi \froman\fcharset162\fprq2 Cambria T';
    wwv_flow_api.g_varchar2_table(46) := 'ur;}'||wwv_flow.LF||
'{\fhimajor\f31535\fbidi \froman\fcharset186\fprq2 Cambria Baltic;}{\fhimajor\f31536\fbidi \fro';
    wwv_flow_api.g_varchar2_table(47) := 'man\fcharset163\fprq2 Cambria (Vietnamese);}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times ';
    wwv_flow_api.g_varchar2_table(48) := 'New Roman CE;}'||wwv_flow.LF||
'{\fbimajor\f31539\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fbimajor\f3';
    wwv_flow_api.g_varchar2_table(49) := '1541\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset';
    wwv_flow_api.g_varchar2_table(50) := '162\fprq2 Times New Roman Tur;}'||wwv_flow.LF||
'{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (';
    wwv_flow_api.g_varchar2_table(51) := 'Hebrew);}{\fbimajor\f31544\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f315';
    wwv_flow_api.g_varchar2_table(52) := '45\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}'||wwv_flow.LF||
'{\fbimajor\f31546\fbidi \froman\fcharse';
    wwv_flow_api.g_varchar2_table(53) := 't163\fprq2 Times New Roman (Vietnamese);}{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New';
    wwv_flow_api.g_varchar2_table(54) := ' Roman CE;}{\flominor\f31549\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\flominor\f3155';
    wwv_flow_api.g_varchar2_table(55) := '1\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\flominor\f31552\fbidi \froman\fcharset162';
    wwv_flow_api.g_varchar2_table(56) := '\fprq2 Times New Roman Tur;}{\flominor\f31553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebre';
    wwv_flow_api.g_varchar2_table(57) := 'w);}'||wwv_flow.LF||
'{\flominor\f31554\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\flominor\f31555\';
    wwv_flow_api.g_varchar2_table(58) := 'fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\';
    wwv_flow_api.g_varchar2_table(59) := 'fprq2 Times New Roman (Vietnamese);}'||wwv_flow.LF||
'{\fdbminor\f31558\fbidi \froman\fcharset238\fprq2 Times New Ro';
    wwv_flow_api.g_varchar2_table(60) := 'man CE;}{\fdbminor\f31559\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\fdbminor\f31561\fbi';
    wwv_flow_api.g_varchar2_table(61) := 'di \froman\fcharset161\fprq2 Times New Roman Greek;}'||wwv_flow.LF||
'{\fdbminor\f31562\fbidi \froman\fcharset162\fp';
    wwv_flow_api.g_varchar2_table(62) := 'rq2 Times New Roman Tur;}{\fdbminor\f31563\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);';
    wwv_flow_api.g_varchar2_table(63) := '}{\fdbminor\f31564\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\fdbminor\f31565\fbi';
    wwv_flow_api.g_varchar2_table(64) := 'di \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fdbminor\f31566\fbidi \froman\fcharset163\fpr';
    wwv_flow_api.g_varchar2_table(65) := 'q2 Times New Roman (Vietnamese);}{\fhiminor\f31568\fbidi \fswiss\fcharset238\fprq2 Calibri CE;}'||wwv_flow.LF||
'{\f';
    wwv_flow_api.g_varchar2_table(66) := 'himinor\f31569\fbidi \fswiss\fcharset204\fprq2 Calibri Cyr;}{\fhiminor\f31571\fbidi \fswiss\fcharset';
    wwv_flow_api.g_varchar2_table(67) := '161\fprq2 Calibri Greek;}{\fhiminor\f31572\fbidi \fswiss\fcharset162\fprq2 Calibri Tur;}'||wwv_flow.LF||
'{\fhiminor';
    wwv_flow_api.g_varchar2_table(68) := '\f31573\fbidi \fswiss\fcharset177\fprq2 Calibri (Hebrew);}{\fhiminor\f31574\fbidi \fswiss\fcharset17';
    wwv_flow_api.g_varchar2_table(69) := '8\fprq2 Calibri (Arabic);}{\fhiminor\f31575\fbidi \fswiss\fcharset186\fprq2 Calibri Baltic;}'||wwv_flow.LF||
'{\fhim';
    wwv_flow_api.g_varchar2_table(70) := 'inor\f31576\fbidi \fswiss\fcharset163\fprq2 Calibri (Vietnamese);}{\fbiminor\f31578\fbidi \froman\fc';
    wwv_flow_api.g_varchar2_table(71) := 'harset238\fprq2 Times New Roman CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roma';
    wwv_flow_api.g_varchar2_table(72) := 'n Cyr;}'||wwv_flow.LF||
'{\fbiminor\f31581\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\';
    wwv_flow_api.g_varchar2_table(73) := 'fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fpr';
    wwv_flow_api.g_varchar2_table(74) := 'q2 Times New Roman (Hebrew);}'||wwv_flow.LF||
'{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Ar';
    wwv_flow_api.g_varchar2_table(75) := 'abic);}{\fbiminor\f31585\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\f';
    wwv_flow_api.g_varchar2_table(76) := 'bidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}}'||wwv_flow.LF||
'{\colortbl;\red0\green0\blue0;\red0\';
    wwv_flow_api.g_varchar2_table(77) := 'green0\blue255;\red0\green255\blue255;\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blu';
    wwv_flow_api.g_varchar2_table(78) := 'e0;\red255\green255\blue0;\red255\green255\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0';
    wwv_flow_api.g_varchar2_table(79) := '\green128\blue0;'||wwv_flow.LF||
'\red128\green0\blue128;\red128\green0\blue0;\red128\green128\blue0;\red128\green12';
    wwv_flow_api.g_varchar2_table(80) := '8\blue128;\red192\green192\blue192;\red231\green243\blue253;\red192\green0\blue0;\red0\green112\blue';
    wwv_flow_api.g_varchar2_table(81) := '192;}{\*\defchp \f31506\fs22 }{\*\defpap \ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\as';
    wwv_flow_api.g_varchar2_table(82) := 'palpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa200\sl276';
    wwv_flow_api.g_varchar2_table(83) := '\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af0\a';
    wwv_flow_api.g_varchar2_table(84) := 'fs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext0 ';
    wwv_flow_api.g_varchar2_table(85) := '\sqformat \spriority0 Normal;}{\*\cs10 \additive \ssemihidden \sunhideused \spriority1 Default Parag';
    wwv_flow_api.g_varchar2_table(86) := 'raph Font;}{\*'||wwv_flow.LF||
'\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpadd';
    wwv_flow_api.g_varchar2_table(87) := 'fr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdr';
    wwv_flow_api.g_varchar2_table(88) := 'v \ql \li0\ri0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\l';
    wwv_flow_api.g_varchar2_table(89) := 'in0\itap0 \rtlch\fcs1 \af31506\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_api.g_varchar2_table(90) := 'ngnp1033\langfenp1033 \snext11 \ssemihidden \sunhideused Normal Table;}{\*\ts15\tsrowd'||wwv_flow.LF||
'\trbrdrt\brd';
    wwv_flow_api.g_varchar2_table(91) := 'rs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(92) := '10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpadd';
    wwv_flow_api.g_varchar2_table(93) := 'fr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdr';
    wwv_flow_api.g_varchar2_table(94) := 'v '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs';
    wwv_flow_api.g_varchar2_table(95) := '1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(96) := '\sbasedon11 \snext15 \sunhideused \spriority59 \styrsid8735851 Table Grid;}{\s16\ql \li0\ri0\widctlp';
    wwv_flow_api.g_varchar2_table(97) := 'ar\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 ';
    wwv_flow_api.g_varchar2_table(98) := '\af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \s';
    wwv_flow_api.g_varchar2_table(99) := 'basedon0 \snext16 \slink17 \sunhideused \styrsid8735851 header;}{\*\cs17 \additive \rtlch\fcs1 \af0 ';
    wwv_flow_api.g_varchar2_table(100) := '\ltrch\fcs0 \sbasedon10 \slink16 \slocked \styrsid8735851 Header Char;}{'||wwv_flow.LF||
'\s18\ql \li0\ri0\widctlpar';
    wwv_flow_api.g_varchar2_table(101) := '\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(102) := 'f0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'\sba';
    wwv_flow_api.g_varchar2_table(103) := 'sedon0 \snext18 \slink19 \sunhideused \styrsid8735851 footer;}{\*\cs19 \additive \rtlch\fcs1 \af0 \l';
    wwv_flow_api.g_varchar2_table(104) := 'trch\fcs0 \sbasedon10 \slink18 \slocked \styrsid8735851 Footer Char;}{'||wwv_flow.LF||
'\s20\ql \li0\ri0\widctlpar\w';
    wwv_flow_api.g_varchar2_table(105) := 'rapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af40\afs16\alang1025 \ltr';
    wwv_flow_api.g_varchar2_table(106) := 'ch\fcs0 \f40\fs16\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 '||wwv_flow.LF||
'\sbasedon0 \snext20 \slink21 \';
    wwv_flow_api.g_varchar2_table(107) := 'ssemihidden \sunhideused \styrsid8735851 Balloon Text;}{\*\cs21 \additive \rtlch\fcs1 \af40\afs16 \l';
    wwv_flow_api.g_varchar2_table(108) := 'trch\fcs0 \f40\fs16 \sbasedon10 \slink20 \slocked \ssemihidden \styrsid8735851 Balloon Text Char;}}{';
    wwv_flow_api.g_varchar2_table(109) := '\*\rsidtbl \rsid273454'||wwv_flow.LF||
'\rsid852486\rsid1123090\rsid1723735\rsid3433759\rsid3549643\rsid4139640\rsid';
    wwv_flow_api.g_varchar2_table(110) := '4159075\rsid4355353\rsid4855564\rsid4995876\rsid5657930\rsid6776828\rsid7216684\rsid7943541\rsid8728';
    wwv_flow_api.g_varchar2_table(111) := '293\rsid8735851\rsid8994382\rsid9989025\rsid10628002\rsid11090035\rsid11102424'||wwv_flow.LF||
'\rsid12919090\rsid13';
    wwv_flow_api.g_varchar2_table(112) := '042299\rsid13843577\rsid14170085\rsid14755898\rsid15029683\rsid15281513\rsid15415714\rsid15889683}{\';
    wwv_flow_api.g_varchar2_table(113) := 'mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\mlMargin0\mrMargin0\mdefJc1\mwrapInde';
    wwv_flow_api.g_varchar2_table(114) := 'nt1440\mintLim0\mnaryLim1}{\info'||wwv_flow.LF||
'{\author oliur}{\operator oliur}{\creatim\yr2021\mo9\dy18\hr4\min5';
    wwv_flow_api.g_varchar2_table(115) := '6}{\revtim\yr2021\mo9\dy18\hr5\min14}{\version21}{\edmins4}{\nofpages1}{\nofwords102}{\nofchars588}{';
    wwv_flow_api.g_varchar2_table(116) := '\nofcharsws689}{\vern49247}}{\*\xmlnstbl {\xmlns1 http://schemas.microsoft.com/office/wor'||wwv_flow.LF||
'd/2003/wo';
    wwv_flow_api.g_varchar2_table(117) := 'rdml}}\paperw12240\paperh15840\margl720\margr720\margt720\margb720\gutter0\ltrsect '||wwv_flow.LF||
'\widowctrl\ftnb';
    wwv_flow_api.g_varchar2_table(118) := 'j\aenddoc\trackmoves0\trackformatting1\donotembedsysfont1\relyonvml0\donotembedlingdata0\grfdocevent';
    wwv_flow_api.g_varchar2_table(119) := 's0\validatexml1\showplaceholdtext0\ignoremixedcontent0\saveinvalidxml0\showxmlerrors1\noxlattoyen'||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(120) := 'expshrtn\noultrlspc\dntblnsbdb\nospaceforul\formshade\horzdoc\dgmargin\dghspace180\dgvspace180\dghor';
    wwv_flow_api.g_varchar2_table(121) := 'igin720\dgvorigin720\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100\pgbrdrhead\pgbrdrfoot\splytw';
    wwv_flow_api.g_varchar2_table(122) := 'nine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd\lyttblrtgr\lnbrkrule\nobrkwr';
    wwv_flow_api.g_varchar2_table(123) := 'ptbl\snaptogridincell\allowfieldendsel\wrppunct'||wwv_flow.LF||
'\asianbrkrule\rsidroot8735851\newtblstyruls\nogrowa';
    wwv_flow_api.g_varchar2_table(124) := 'utofit\usenormstyforlist\noindnmbrts\felnbrelev\nocxsptable\indrlsweleven\noafcnsttbl\afelev\utinl\h';
    wwv_flow_api.g_varchar2_table(125) := 'welev\spltpgpar\notcvasp\notbrkcnstfrctbl\notvatxbx\krnprsnet\cachedcolbal \nouicompat \fet0'||wwv_flow.LF||
'{\*\wg';
    wwv_flow_api.g_varchar2_table(126) := 'rffmtfilter 2450}\nofeaturethrottle1\ilfomacatclnup0{\*\ftnsep \ltrpar \pard\plain \ltrpar\ql \li0\r';
    wwv_flow_api.g_varchar2_table(127) := 'i0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8735851 \rtlch\f';
    wwv_flow_api.g_varchar2_table(128) := 'cs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp103';
    wwv_flow_api.g_varchar2_table(129) := '3 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid5657930 \chftnsep '||wwv_flow.LF||
'\par }}{\*\ftnsepc \ltrpar \pard\plain \';
    wwv_flow_api.g_varchar2_table(130) := 'ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid';
    wwv_flow_api.g_varchar2_table(131) := '8735851 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp10';
    wwv_flow_api.g_varchar2_table(132) := '33\langfenp1033 {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid5657930 \chftnsepc '||wwv_flow.LF||
'\par }}{\*\aftnsep \ltr';
    wwv_flow_api.g_varchar2_table(133) := 'par \pard\plain \ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\li';
    wwv_flow_api.g_varchar2_table(134) := 'n0\itap0\pararsid8735851 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe10';
    wwv_flow_api.g_varchar2_table(135) := '33\cgrid\langnp1033\langfenp1033 {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid5657930 \chftnsep '||wwv_flow.LF||
'\par }}';
    wwv_flow_api.g_varchar2_table(136) := '{\*\aftnsepc \ltrpar \pard\plain \ltrpar\ql \li0\ri0\widctlpar\wrapdefault\aspalpha\aspnum\faauto\ad';
    wwv_flow_api.g_varchar2_table(137) := 'justright\rin0\lin0\itap0\pararsid8735851 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\';
    wwv_flow_api.g_varchar2_table(138) := 'lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid5657930 \c';
    wwv_flow_api.g_varchar2_table(139) := 'hftnsepc '||wwv_flow.LF||
'\par }}\ltrpar \sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735';
    wwv_flow_api.g_varchar2_table(140) := '851\sftnbj {\headerl \ltrpar \pard\plain \ltrpar\s16\ql \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wra';
    wwv_flow_api.g_varchar2_table(141) := 'pdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 '||wwv_flow.LF||
'\rtlch\fcs1 \af0\afs22\alang1025 \ltrc';
    wwv_flow_api.g_varchar2_table(142) := 'h\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(143) := '\insrsid7943541 '||wwv_flow.LF||
'\par }}{\headerr \ltrpar \pard\plain \ltrpar\s16\qc \fi2880\li0\ri0\widctlpar\tqc\';
    wwv_flow_api.g_varchar2_table(144) := 'tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8735851 \rt';
    wwv_flow_api.g_varchar2_table(145) := 'lch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfe';
    wwv_flow_api.g_varchar2_table(146) := 'np1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid5657930 '||wwv_flow.LF||
'{\shp{\*\shpinst\';
    wwv_flow_api.g_varchar2_table(147) := 'shpleft5010\shptop240\shpright5804\shpbottom1005\shpfhdr0\shpbxcolumn\shpbxignore\shpbypage\shpbyign';
    wwv_flow_api.g_varchar2_table(148) := 'ore\shpwr3\shpwrk0\shpfblwtxt0\shpz0\shplid2049{\sp{\sn shapeType}{\sv 75}}{\sp{\sn fFlipH}{\sv 0}}{';
    wwv_flow_api.g_varchar2_table(149) := '\sp{\sn fFlipV}{\sv 0}}'||wwv_flow.LF||
'{\sp{\sn fLockAspectRatio}{\sv 1}}{\sp{\sn fLockPosition}{\sv 0}}{\sp{\sn f';
    wwv_flow_api.g_varchar2_table(150) := 'LockAgainstSelect}{\sv 0}}{\sp{\sn fLockAgainstGrouping}{\sv 0}}{\sp{\sn pib}{\sv {\pict\picscalex10';
    wwv_flow_api.g_varchar2_table(151) := '5\picscaley103\piccropl0\piccropr0\piccropt0\piccropb0'||wwv_flow.LF||
'\picw1328\pich1316\picwgoal753\pichgoal746\j';
    wwv_flow_api.g_varchar2_table(152) := 'pegblip\bliptag1982191550{\*\blipuid 7625d7beb2922187a56e7c9aa7c90388}ffd8ffe000104a4649460001010100';
    wwv_flow_api.g_varchar2_table(153) := 'dc00dc0000ffdb004300020101010101020101010202020202040302020202050404030406050606060506060607090806'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(154) := '0709070606080b08090a0a0a0a0a06080b0c0b0a0c090a0a0affdb004301020202020202050303050a0706070a0a0a0a0a0a';
    wwv_flow_api.g_varchar2_table(155) := '0a0a0a0a0a0a0a0a0a0a0a0a0a0a'||wwv_flow.LF||
'0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0affc0001108';
    wwv_flow_api.g_varchar2_table(156) := '0072007303012200021101031101ffc4001f0000010501010101010100'||wwv_flow.LF||
'000000000000000102030405060708090a0bffc4';
    wwv_flow_api.g_varchar2_table(157) := '00b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a10823'||wwv_flow.LF||
'42b1c11552';
    wwv_flow_api.g_varchar2_table(158) := 'd1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a63646566676869';
    wwv_flow_api.g_varchar2_table(159) := '6a737475767778797a'||wwv_flow.LF||
'838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6';
    wwv_flow_api.g_varchar2_table(160) := 'c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1'||wwv_flow.LF||
'f2f3f4f5f6f7f8f9faffc4001f010003010101010101010101';
    wwv_flow_api.g_varchar2_table(161) := '0000000000000102030405060708090a0bffc400b5110002010204040304070504040001027700'||wwv_flow.LF||
'01020311040521310612';
    wwv_flow_api.g_varchar2_table(162) := '41510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445';
    wwv_flow_api.g_varchar2_table(163) := '46474849'||wwv_flow.LF||
'4a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3';
    wwv_flow_api.g_varchar2_table(164) := 'a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4'||wwv_flow.LF||
'c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7';
    wwv_flow_api.g_varchar2_table(165) := 'f8f9faffda000c03010002110311003f00fe7fe8a28a0028a74713ca7082b6344f0c'||wwv_flow.LF||
'5feab7b1e99a6584d757570cb1dbdb';
    wwv_flow_api.g_varchar2_table(166) := 'dbc45e4964638545500966270001c9340195159cd20cede83356d346721b703f2ae7f9d7ea07eca1ff0006d0fed05e29f8'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(167) := '6dff000d21ff00050bf8c5e1bfd9a7e18ac2b24ba878f2645d5a64209016d249235819864059e449738c44fdfd427f89bff0';
    wwv_flow_api.g_varchar2_table(168) := '6be7ec27e7693f0bbf66df883fb5'||wwv_flow.LF||
'078a2c21cbf88bc5b7af67a4c8c33b8047f250aee071fe8728c7476eac01f8ec742daa';
    wwv_flow_api.g_varchar2_table(169) := 'ff00bbced5cff3a593410bbff75f7541afe86ff6d8ff008280df7fc133'||wwv_flow.LF||
'3c25f68f0c7fc139ff00619f09eb51dc5ac4df0c';
    wwv_flow_api.g_varchar2_table(170) := '741d6e2d63c476705c5bbcf1dd5cc369636889094087797dcde7210a5496af30fd937fe0b99f1fff006eff00'||wwv_flow.LF||
'da33c37fb2';
    wwv_flow_api.g_varchar2_table(171) := '9597fc12ff00f661d7755f165e35b58c1ab78767b7b61b629257323b0b9daa2389c92236e9d2803f0b67d10a6ec2fddc5559';
    wwv_flow_api.g_varchar2_table(172) := 'f4e9a227033838afdf'||wwv_flow.LF||
'4fda37c7bff0481bad3f509ffe0a39ff00044987e13d9c5f10b58f04278e7e08f8a2d4c2dace9922';
    wwv_flow_api.g_varchar2_table(173) := '25e3a5adb1b190c28644224682543bb0033020789f8cff00'||wwv_flow.LF||
'e0de2fd94bf6d2f0b6a1f12ffe08a1ff000502d07e234d6b1f';
    wwv_flow_api.g_varchar2_table(174) := 'da6e7e17f8fae12c35cb6418e0398e26049f957ceb78a3247fae3d6803f1c19590ed65c5257a97'||wwv_flow.LF||
'ed1ffb2dfc74fd95fe25';
    wwv_flow_api.g_varchar2_table(175) := '6a1f07ff00689f851ad783fc49a7c8bf68d2b5bb3689ca13812467eecb1b60ed910b230e5588af33bab392dd9b8e01c50043';
    wwv_flow_api.g_varchar2_table(176) := '45145005'||wwv_flow.LF||
'cb4f11f886c2dd6d2c75dbc8625fbb1c374eaa39cf001f5a2a9d140053a28da56daa29a327815b9e16f0f6a5ad';
    wwv_flow_api.g_varchar2_table(177) := 'ea36fa4691a74d77797922c56b6b6f11792691'||wwv_flow.LF||
'885545500966248000e493401dc7ecbffb2e7c66fdadbe32e89fb3f7ecfd';
    wwv_flow_api.g_varchar2_table(178) := 'e03bbf1178abc4538834dd3ad57ea5a5918fcb1448a0b3c8c42a2a924802bf63ed0f'||wwv_flow.LF||
'fc13cbfe0daad1edbc2fa5d9687f1a';
    wwv_flow_api.g_varchar2_table(179) := 'ff006c0bab189f5cd7ee2d4dce91f0fd645e7cb8f2ac1d5492114a5cccb92ef6d1c8886b6a573e13ff0083687f600b5f07'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(180) := '784adf4ebafdb33e387867ed5ad6a92224cfe04d1db3b634ce46e5705547dd96e11dd8bc76d1a1fc99d62eb5ef166b1ad78a';
    wwv_flow_api.g_varchar2_table(181) := 'bc55abdd6a5a96a30b5dea1a85f5'||wwv_flow.LF||
'c34d3dd4f234acf2c8ec4b3bb312c589249393401fd01dd7ec6b6be3afdae356d77fe0';
    wwv_flow_api.g_varchar2_table(182) := 'a37f1897f68af84ff1fbe094dff0ac7e2b5d69eb12f84750166f77730e'||wwv_flow.LF||
'9f668cd0e9c66b2f3eee09235f31c5a0405dd652';
    wwv_flow_api.g_varchar2_table(183) := 'ff00889fb5efec91e3dfd8ebf689f1dfece3f126056d4bc2ce615bc897115fdb3077b7bb8bfe99cd0b472af7'||wwv_flow.LF||
'c3807906bf';
    wwv_flow_api.g_varchar2_table(184) := '4d3fe08bff00f052fd43c23f04ed7f67af19e9b3789f5ff867ac58df783fc1eb119eebc61a15cdf0336956718e64d42cae71';
    wwv_flow_api.g_varchar2_table(185) := '7d6839251ae61f9236'||wwv_flow.LF||
'761ee7fb70ff00c1397f666f1be97e1df8b3ff00053ff8f7a57c17f0bf84f4bd4348f0ad8d95c25d';
    wwv_flow_api.g_varchar2_table(186) := '78c75cf0c8ba965d3ad2ea38fcf8d25b281cc0a604ba6653'||wwv_flow.LF||
'9919586d001f267fc165bc27e19f8d1f01be157c70f057ec61';
    wwv_flow_api.g_varchar2_table(187) := 'e20d5fc5be2afd9f7c2be22f177c69d3b56bfb8b5b48edad27b3b8d3e6b3488dbc5b1a0476b877'||wwv_flow.LF||
'dd82a30a01dde3dff046';
    wwv_flow_api.g_varchar2_table(188) := 'c96e3e0bfc67f8bffb5e40be5dcfc1ef807e20d7345baed1eab710ff0066d9ae7b167bc3f8035f73ebbff0566ff82477c11f';
    wwv_flow_api.g_varchar2_table(189) := '83527ecc'||wwv_flow.LF||
'3f0d7e03fc72f895e0dd17436b47d37c4df102f2c74abdb3732e6236ab79e53a31df90f6cb9ddd380070d61ff0';
    wwv_flow_api.g_varchar2_table(190) := '524ff82275fe8fe24f01f8c7fe095de2af0b68'||wwv_flow.LF||
'3af69f6f6fe268fc0be389e23a8dbacbe6471cd1c3736ab3049116455762';
    wwv_flow_api.g_varchar2_table(191) := '03007a8a760388ff0083a4dfc2fe1df8c1f0e7e04783eed67b786c75cf1e5f347fc5'||wwv_flow.LF||
'75e22d6a59ceec7f12c76b1a8ff642';
    wwv_flow_api.g_varchar2_table(192) := '9ef5e1bfb007ec66de0cfd9afc43fb67f893c31ae5f78ebc71e22b7f00fecb5a0e83addce9b7d7be289a48d65d6a39ada4'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(193) := '8e5586c47f16ef29dcc91c98e2bec8f8e7fb187fc13b7fe0b25e3193c5dfb277fc145358d27e2aff0065d969d63e06f8c96e';
    wwv_flow_api.g_varchar2_table(194) := '91f9b0dba85b7b486448e36385ea'||wwv_flow.LF||
'd1b5dbf5247535b5fb7f7c4ef0b7fc134742f0bf8cef2c3c45a4fc58f07fc1fb4f01fc';
    wwv_flow_api.g_varchar2_table(195) := '14f87b71e13923d1fc1d773858757f125bea8ac6db519a557664743e70'||wwv_flow.LF||
'69144f1a9e1101c8fc55ff0082817ec6bf193e29';
    wwv_flow_api.g_varchar2_table(196) := 'eb9ff048eff82cf78b74df8afa3f856eadf45d13f699d17454d3aff40d73c8885ca48e85c98a2b92d09bb550'||wwv_flow.LF||
'b27923ed10';
    wwv_flow_api.g_varchar2_table(197) := '48a5a41f99ff00f056dff82417c6bff82607c4eb6835bd461f167c37f15b0b9f87df123498c1b3d5edcaab08dca9658ae021';
    wwv_flow_api.g_varchar2_table(198) := '0c53715653bd1994e4'||wwv_flow.LF||
'78ff008934e9ae6e2faeaea46925935289a492462ccec7ca2493d4924d7e8d7fc11e3f6f9f859f1a';
    wwv_flow_api.g_varchar2_table(199) := 'fe1e6a1ff0460ff82965cff6cfc20f1f4e961f0f7c41a84c'||wwv_flow.LF||
'3ed1e0fd5df69b648a6707ca8da660626e4452b0520c52c814';
    wwv_flow_api.g_varchar2_table(200) := '03f1d2f6d1ade46c0e3762a0afa33fe0a43fb05fc56ff82767ed5be2afd973e2dc1e6dc68f78b2'||wwv_flow.LF||
'e8dac470948758d364e6';
    wwv_flow_api.g_varchar2_table(201) := 'def62ce7e575e19727648b22124a1af9d668cc52143da801b45145004d65099a6c62bf53bfe0da4fd94be1b6aff1cbc69ff0';
    wwv_flow_api.g_varchar2_table(202) := '521fda4e'||wwv_flow.LF||
'cd57e19fecd3e177f125cbcd1865b8d60472496aaaad812344b14b32a839132db0fe319fcbbd162dcf9c7635fb';
    wwv_flow_api.g_varchar2_table(203) := '25f19cff00c30c7fc1afbf0a7e0c68e7ec7e24'||wwv_flow.LF||
'fda73c6971e25f12edf95a7d2e02248c03d4831c1a49c74c48e3f8b900f8';
    wwv_flow_api.g_varchar2_table(204) := '3bf6c7fda9fe257edcff00b4ef8e7f6a5f8ad72cdaa78aae24b98acfcc2d1e9f6a03'||wwv_flow.LF||
'2dbda479fe08a2548c773b72724926';
    wwv_flow_api.g_varchar2_table(205) := '97c38f85fe31f8a7e3287e1afc3cf0e5d6adaf6bcb6f61a3697671ee96eeea6791238947ab3103d39e6b8fd32d47d9ae3e'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(206) := '5ff98667f46afd5aff0082147c38f057ecc7f097e357fc1623e30787e1bfd37e117865b4cf01d8dc70b77af4b1b6403fc2d8';
    wwv_flow_api.g_varchar2_table(207) := 'b8b6801e702f58e3280d007abf8b'||wwv_flow.LF||
'fc47f03bfe0ddef8193fc3cf84da7e89e31fdaebc55e155b9f14789ee611716be0db49';
    wwv_flow_api.g_varchar2_table(208) := '11da3862078ea1b6a70662be6cb88fc989bf377e32fc40f89ff1d3c73e'||wwv_flow.LF||
'2cf89ff187c71a9f893c41a968ab2df6adab5d34';
    wwv_flow_api.g_varchar2_table(209) := 'd2c87fd230327eea8e8a8b85503000000a4f8bff00117c77f1d3e2678ebe307c4fd765d53c41e22b36d4356b'||wwv_flow.LF||
'e98f324d23';
    wwv_flow_api.g_varchar2_table(210) := '5c9200fe151c2aa8e154051800549acd9aaaf88801d3c369ff00b75548ab19faf6871c635d057eee8319fd6e2a4f10e8912b';
    wwv_flow_api.g_varchar2_table(211) := '6b202fddb2b73ff8f4'||wwv_flow.LF||
'95eb7e01fd91bf698fda10ebc7e077c02f16f8aa393458a25bad17419e78049bae3e532aaec53c8e';
    wwv_flow_api.g_varchar2_table(212) := '0b0eb5ec7fb687fc11fbf6ccfd96b59d4a11f0bb58f1ae93'||wwv_flow.LF||
'71e1ab2bc97c41e0ed06eeead6da42d2f9b6f2111e55a32392';
    wwv_flow_api.g_varchar2_table(213) := '40055d0f0490283dd3e33d7f45782e7539e12cad1dc599565e181dcbc835fa05fb147fc14f3e1f'||wwv_flow.LF||
'7ed09e0ab8ff008275ff';
    wwv_flow_api.g_varchar2_table(214) := '00c15c42f8c3e1aead7f6f65e15f881aac99d4bc2d7acb18b791ee4e5ca2c8e36cec4b4409590bc25953e1ff001258490dde';
    wwv_flow_api.g_varchar2_table(215) := 'b504d132'||wwv_flow.LF||
'b25d59ab232e0a9dcb904763581e28d397cdd49827fcc72c47eb6f482c757ff053ff00f82767c4dff82757ed11';
    wwv_flow_api.g_varchar2_table(216) := 'abfc1cf1bb1d4347bebeb7bff06789a38f6c5a'||wwv_flow.LF||
'ce9acf12a4a3190b22905248f3f2b2e4655919be54d7ec5a27ba913e565b';
    wwv_flow_api.g_varchar2_table(217) := 'f870476e22afd95f085e4fff000568ff00822ef8dbe0af8b545f7c56fd95ee60d5fc'||wwv_flow.LF||
'27a94cdbae6ffc3eb1a4cf067ef3e2';
    wwv_flow_api.g_varchar2_table(218) := '08a68768ce5adacc9c93cfe41789acf0d7bc7fcc4a11fa435049fa5ffb5dcbff000f9fff008213e95fb5fdd27dbfe397ec'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(219) := 'ad7a9a27c40bafbd75ace80c233f6a93bb7eecc7705d8e03dbdf607cf5f8afac5bf972b301d1bfa57ebb7fc1b11f17345d33';
    wwv_flow_api.g_varchar2_table(220) := 'f6f3f16fec73f1100baf077c7af0'||wwv_flow.LF||
'1ea7e1cd634b95b11dc4f159b5c465b3c67ece2f621ff5f15f98dfb4efc1cd6fe007c7';
    wwv_flow_api.g_varchar2_table(221) := '8f1d7c09f1292da8782fc5fa86857cc571ba5b4b87818e3d09427f1a00'||wwv_flow.LF||
'f34a283c7145006c68280b2ffb86bf663fe0e1bf';
    wwv_flow_api.g_varchar2_table(222) := '096b86fbf634fd8c3c251c40f877f678d360d26ce6b85863f3ee043698dcc4282df6041d79381d48afc67d00'||wwv_flow.LF||
'8dcbfee7f5';
    wwv_flow_api.g_varchar2_table(223) := 'afd9eff838d749f0afc45fda1bf655f883e2ef1b7fc239e16f157ecf1a42dc788934f92efec702cf24d24a9147f34cc12e50';
    wwv_flow_api.g_varchar2_table(224) := 'aa02b925416504b000'||wwv_flow.LF||
'f987e3affc12cfe3dfece9f05f44f8b1e27bdd3e417de02b8d57c65a5dc4f1da4be139e3beb9b48a';
    wwv_flow_api.g_varchar2_table(225) := 'c2e0cb20f36e2630b18e241e63b4738546581a43f687ed54'||wwv_flow.LF||
'7fe1487fc1b71f037e17e8c7c89fe2578b354d7f5e78f8fb4c';
    wwv_flow_api.g_varchar2_table(226) := '711bc28adeb856b3fc6115f227ed27fb53fc1afda6fe1268de006f1e789b4f3e18f02dd5f69336'||wwv_flow.LF||
'b37977a84b7daa0bfbe8';
    wwv_flow_api.g_varchar2_table(227) := 'fc8d559f227bc9ec23b1912f62052267fb3102154fb2fd77fb7b8ff84fff00e0deff00d967e26e95f3dae8579ac6857857fe';
    wwv_flow_api.g_varchar2_table(228) := '59cc7ed6'||wwv_flow.LF||
'8037a67ec4c7f11ea29a03e0c9a0022f10363fe65e4ffdb9afd5eff82767fc1217c2da47c03d53f6fafdaefc3f';
    wwv_flow_api.g_varchar2_table(229) := '6fa859dd68505c783fc0bab69ef716b2db877d'||wwv_flow.LF||
'9797d0ac91b4f1c82505200caa530cfb83841f9c1fb32e93e04f117ed0da';
    wwv_flow_api.g_varchar2_table(230) := '4e95f143c31ae6b7e19696c1fc47a3f8674f6bbbfbdb0496e1ee21822520b3b44aea'||wwv_flow.LF||
'3046339ed5fd0758ff00c1603f6678';
    wwv_flow_api.g_varchar2_table(231) := '34f92c25f809f1a2c2d6cac55bc893e12def96b16180451186070131b47418f514f52ba1e47e32fdb03f6be9348b9f0f7c'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(232) := '29f15daf8774db1d39574b8bc23f05b51896dd46f002f9d05f458002e02a607a722bc97f64aff82df7ed8d69f1bfc51f053e';
    wwv_flow_api.g_varchar2_table(233) := '29fc0dd73e3247a6cc4588f05f87'||wwv_flow.LF||
'fc9d6e00b3488ccf0c30a4722615721a38594e4b11f7471dfb6e7fc148b46f889aa789';
    wwv_flow_api.g_varchar2_table(234) := '34ff00873ff0480f0bde59db69bbedfc45f11be1fcb35ddf29330c3476'||wwv_flow.LF||
'd1c4d0fddced13b9f9fa8cd707f077fe0b29fb43';
    wwv_flow_api.g_varchar2_table(235) := '7ec8736b76be05fd897e15e87a6986da6be8b49f075f69f71787320c4971f68667da3eeef0db771c75a649f4'||wwv_flow.LF||
'8ffc14a7e0';
    wwv_flow_api.g_varchar2_table(236) := 'e7c30fdba3e1fea7af597fc12fbe3e7867e23148a4d3fc61a4f8274c57ba9410563bc44bf0d7317014b30f31072a700ab7e3';
    wwv_flow_api.g_varchar2_table(237) := '5fc62f86fe39f855e3'||wwv_flow.LF||
'2f117c3df897e11d4342d734df1169f1ea1a4ea96ad0cf6ec45ab00c8c011956561ea0823835fd18';
    wwv_flow_api.g_varchar2_table(238) := '7fc136bfe0ac3f0b3fe0a1f79aef81b4ef02ea3e15f18786'||wwv_flow.LF||
'6ce2bbd5b47ba9c5c5bcb6ee42f9b04e0296018a86574420ba';
    wwv_flow_api.g_varchar2_table(239) := 'e370c91f0cff00c1d2dfb3a681a06a9f0fbf6a5d034c8e0bad72fa2d0bc472c7185f3e4867865b'||wwv_flow.LF||
'591b1f79fcb33a163ced';
    wwv_flow_api.g_varchar2_table(240) := '8a31d14612ec544f9bff00e0dc8f1ebf863fe0a7137c39b955974ef1f786f55d1b50b39398e644b18af46e1d0ffc7a91f466';
    wwv_flow_api.g_varchar2_table(241) := '1dcd7c4f'||wwv_flow.LF||
'7dfb157c4cf899fb5178f3f676f853a6add4fe15f1d4d65a84924c3367656f74904d7922fde30c28a6495c03b1';
    wwv_flow_api.g_varchar2_table(242) := '14b1c0afb0bfe0de5f095f78a3fe0ad3e1ad5e'||wwv_flow.LF||
'ce2668fc3f6dac6a178cbfc31b68ed6c09f6df7083f1af97fc65f19be1c6';
    wwv_flow_api.g_varchar2_table(243) := '8ffb68fc62fda5b54f1d6b16b2c7f10b52d47c2fa3f87aeae2da5d726bbbbf96196e'||wwv_flow.LF||
'a12a60b311c85a7dac24963fdcc7b4';
    wwv_flow_api.g_varchar2_table(244) := 'c86588649d87c0efd94be2bffc137bfe0b0ff084ebfe20d3f50d161fda334ef0fe83e24b5ba8a26d7acc6a30585d5dc56d'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(245) := 'e634ab07ef2585a420c7e6a4b12c8ed13e3c87fe0e2ff0259fc3dff82cafc7ad0aca1548ee3c5167a99551d5ef74cb3bc73f';
    wwv_flow_api.g_varchar2_table(246) := '8b4ec4fbd7ab786bc67f0b7f6b0f'||wwv_flow.LF||
'f82b8fc27f893f0e3c73a85d6aba87ed2da0e9cda2dc59cc2d4e8f06ad6a6caf6c0ba8';
    wwv_flow_api.g_varchar2_table(247) := 'fb2dbfd95555ac98298193318f2dc45079effc1cb9e24b4f13ff00c169'||wwv_flow.LF||
'fe395f59481a38354d16cf8fefc1a1e9d0b8ff00';
    wwv_flow_api.g_varchar2_table(248) := 'bed1aa40fcfb9062461ef45129cc8d8f5a28034343970f8cff0009afd8eff828e20fdad7fe0deffd907f6c3d'||wwv_flow.LF||
'1ffd26f3e1';
    wwv_flow_api.g_varchar2_table(249) := '6c775f0f3c4de5f325ba2c42da1694fa634b80827fe7ed7fbd5f8cfa74de54d827ad7ec27fc1bb7e3cf087ed8ffb33fc7aff';
    wwv_flow_api.g_varchar2_table(250) := '0082247c56d760b45f'||wwv_flow.LF||
'8a5e1b97c47f0ceeaf1be4b5d7ad6342f81c924182cee36ae3e4b39ffbd401f9d7a65c8fb35cf3ff';
    wwv_flow_api.g_varchar2_table(251) := '0030bc7e8d5fae3ff04b678bfe0a07ff0004a2f8f9ff0004'||wwv_flow.LF||
'b7b6659fc73e1cb51e39f8636f238df72f801ede2cf03f7d17';
    wwv_flow_api.g_varchar2_table(252) := '9649e9fda59ec71f925e34f0678c7e12f8e3c47f0b3e226853e97af78766b8d335ad36e97125ad'||wwv_flow.LF||
'd40f2472c6deeaea457b';
    wwv_flow_api.g_varchar2_table(253) := '47ec5bfb60fc49fd88ff0068fd1bf69af85370a754f0cac53c963348561d42d8f9cb35a4b8fe09232c84f55c86186504007e';
    wwv_flow_api.g_varchar2_table(254) := 'ab7fc11f'||wwv_flow.LF||
'ff00e0a63ff04bff00d8abe047f627c7bf84b71a37c58d06faf27d5bc5d1f8352f2f2e2091a658c4771feba109';
    wwv_flow_api.g_varchar2_table(255) := '16f85a1f940f98f3e6357db371ff000715ff00'||wwv_flow.LF||
'c133ed85d197c67e2bff0043b5171363c2737119dfc8e793f2357e71ff00';
    wwv_flow_api.g_varchar2_table(256) := 'c14cbf626f007eda1f08f57ff82b8ffc1382ce4d6bc3de28d29e4f8a7e01b18435ff'||wwv_flow.LF||
'00877544491ee27f25324e4c9ba650';
    wwv_flow_api.g_varchar2_table(257) := '0e0fefd4bc52968ff3d350d6d5a3d7c16fbde1f41ffa5355619fd15ddffc1c41ff0004d5b217467f1978abfd0ed56e26c7'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(258) := '84e6e10efc11cf3f71a96eff00e0e1eff826b591b813f8cbc55fe8b1a49363c27370ac4e3bf3d0d7f3d3e20d523906bc55fa';
    wwv_flow_api.g_varchar2_table(259) := 'e8317f3b9a7788b528f76b47cceb'||wwv_flow.LF||
'636fff00a1494728f94fe83a7ff8387bfe09956135c48de2bf142c90b46b332f8426cf';
    wwv_flow_api.g_varchar2_table(260) := 'ce46de73cf5ae4fe307fc178ff00e08e3f14bc3b3786fe31f87aff00c6'||wwv_flow.LF||
'1616379195d2b5ef872b7b18b865010a2dc0281f';
    wwv_flow_api.g_varchar2_table(261) := '12603718dc790335f81fe23d6504bab056eb3d9ffe84b5f457fc137ffe099ff127fe0a15f13755d635abb93c'||wwv_flow.LF||
'2bf0a7c37a';
    wwv_flow_api.g_varchar2_table(262) := 'a417be3af1fdf6d86dedede08e19a4821924c234c5179272b129defc6d572c23e9bfd84b54f09fec39fb1afed41ff056ab5f';
    wwv_flow_api.g_varchar2_table(263) := '0bcbe19b4f1c6a175e'||wwv_flow.LF||
'12f80fa4dc4999923b99951361c9f31639bc904839c69b39f435f8e1e27bb05ef4eeff00989407f4';
    wwv_flow_api.g_varchar2_table(264) := '86beeeff0082d67fc1473c03fb51f8a343fd97ff0065ad39'||wwv_flow.LF||
'749f81ff0007a6b7d2fc19676e195354993ca57d4194f382bf';
    wwv_flow_api.g_varchar2_table(265) := '247bf2fb77bb61a6751f9f7e23bfdcd77f375bf84fe915488fb97fe0dacf80eff1bbfe0ae1e17f'||wwv_flow.LF||
'14dfc0ada37c38b1d43c';
    wwv_flow_api.g_varchar2_table(266) := '59ac4d270912c36a20818b1e062e6e206fa21f4247c35ff0508f8f91fed3dfb68fc5afda12d67692d7c61f10f54d534d2dd5';
    wwv_flow_api.g_varchar2_table(267) := '6d25b963'||wwv_flow.LF||
'6e9ff018bcb5fc2bf4fbf66e8dbfe0927ff040df89dfb60f8a07f67fc50fdaa674f0b7c37b67f96e2df4331bc4';
    wwv_flow_api.g_varchar2_table(268) := 'd76bfc51e626bbb80e383fe8473f32d7e2eeb7'||wwv_flow.LF||
'73bde45cf57fe82803349c9cd14514002b156dc2bd2bf66bfda03e23fecc';
    wwv_flow_api.g_varchar2_table(269) := 'ff001a3c2ff1ff00e10ebeda6f89bc21ab43a9e8f78bc859a260db5c7f1c6c32ae87'||wwv_flow.LF||
'8646653c135e6b52dadcb5bbe477e2';
    wwv_flow_api.g_varchar2_table(270) := '803f6cbfe0ad3fb3f7c3aff82a4fec9f61ff0005d1fd86b4056be9b474b0fda17c0961fbcb8d1750b78955ef4a81b98229'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(271) := '5123606e83c89f681e711f9756fab662bef9bae9aa3f492bd4bfe0935ff055bf8cdff04b8f8f4df123c1102ebde0fd76de3b';
    wwv_flow_api.g_varchar2_table(272) := '3f1ff80efa6c5a6bb620b7182084'||wwv_flow.LF||
'9d03398e5c1da59948647746fb83f6d8ff0082457c16fdb6be11ea5ff0526ff821e5f0';
    wwv_flow_api.g_varchar2_table(273) := 'f1678475481a6f1a7c15b38c2eb1e16bc2acf2456f6c096c0dc7fd1464'||wwv_flow.LF||
'8c06b73344ea1002b7fc1bb1a7fedb3e2bfdb27c';
    wwv_flow_api.g_varchar2_table(274) := '4337ec99f172cfc25a4e8be0ff00ed1f1c5d788ece4bbd12ea146985b5b5dc2b2479324a70b22bac91a099d0'||wwv_flow.LF||
'9dac8df4ef';
    wwv_flow_api.g_varchar2_table(275) := 'c4af82bff04acff82997c2a5fda67c65a2ebbfb2a788fc617171a5c3e3e9b4966f04f882f236955e449dd62806584ad976b3';
    wwv_flow_api.g_varchar2_table(276) := '91c89322428e45aff8'||wwv_flow.LF||
'2527c39f84bf0abfe09efe32f863a27c488d65d4bc136b75f183c45e179526bf975ef104ada7d878';
    wwv_flow_api.g_varchar2_table(277) := '62c981e751b5d3c5d45e436425f6ad093828d8f957fe0e0e'||wwv_flow.LF||
'fdb634ef14fc43d07fe09e1f0aad74cd2fc13f027c389617da';
    wwv_flow_api.g_varchar2_table(278) := '4e81213649af344cb3c119e0c8967185b557601cb8b866e5cd007a678eff00e0dbcfdb9752b3d4'||wwv_flow.LF||
'3c49fb3f7c4ff861f127';
    wwv_flow_api.g_varchar2_table(279) := '41d4b4f5874dd4b41f14189a6c79872c248c4433bc7dd95c7bd67e93ff0006dd7fc150fc537d7d06b7e1ef04f876dee2de35';
    wwv_flow_api.g_varchar2_table(280) := '37dad78c'||wwv_flow.LF||
'2368a30a58966fb324cd800ff76a7f1668daefec5bff00047bf845f1f7c2bfb06f877c551f8b7c23ad5ffc41f8';
    wwv_flow_api.g_varchar2_table(281) := 'a9711ddd9df69125d6a2d168e05dd94f149c24'||wwv_flow.LF||
'ab85903a92500db920f9e7fc1167c59f087f6abf8fbf143e06feddd7fabf';
    wwv_flow_api.g_varchar2_table(282) := '8c3c3ba97c1cd52f34bb8d5b56b8ba9f4bb8b5024967b5577204cb6c6e2453824342'||wwv_flow.LF||
'b8a7703dbb48ff0082717fc1283f62';
    wwv_flow_api.g_varchar2_table(283) := '9d79756ff82827edd7a5fc4cf124b7b6d1c3f0a3e17dda624b9deaa90dcdc0943468cc41dd33d9a81c97c67367fe0acff1'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(284) := 'b3f69ef8bffb24fc48f83bf0a3c2b67f07fc1bf007e20697a1f8ebe01f876c912e23d1ae4432d96b5717703ecbab59666c79';
    wwv_flow_api.g_varchar2_table(285) := '3122c685964769b8907cd1ff0005'||wwv_flow.LF||
'e0fd98f52fd9a7c45f0775fbbd174fb57d6fe165a68baa5de956a915b6a9a968b74f63';
    wwv_flow_api.g_varchar2_table(286) := '2ea1184f94adcdbfd8ae01ea44e18fdeafa63fe09d5f1a7c41fb7df873'||wwv_flow.LF||
'c03f17fc23a2697e28f88ff0fac57e177ed29e0c';
    wwv_flow_api.g_varchar2_table(287) := 'd5758b7b3ff84d7e1adea88e3d61da77412c962a7f78db8bb342acc4028a501f8dfafeafbbed9f3f5d4613ff'||wwv_flow.LF||
'00a2abea8f';
    wwv_flow_api.g_varchar2_table(288) := 'f823a7fc1316ff00fe0a2ff1f750f15fc56bb3a07c12f877326b1f14bc5d7937d9edd6d618d66fb0a4c480b248a877be4795';
    wwv_flow_api.g_varchar2_table(289) := '16f909cec57f40fd99'||wwv_flow.LF||
'3fe084be3afdacbf690f88dad597c4cb7f0bfeccbe04f1b6a514ff001cb5d92386d755d22cae1904';
    wwv_flow_api.g_varchar2_table(290) := 'd62d2158ee0b47164dc03f678fe662cc42c6f99ff0572ff8'||wwv_flow.LF||
'2bcfc14bbf8216dff04b3ff825768d27857e00f866658fc41a';
    wwv_flow_api.g_varchar2_table(291) := 'fc21a3bcf1cdd2b2b3cd2b30121b76701c97c3ccc14b044544a00f1fff0082ea7fc14f2cbfe0a2'||wwv_flow.LF||
'ff00b54e3e15daff0065';
    wwv_flow_api.g_varchar2_table(292) := 'fc23f86f683c3bf0af43861f2624b18f607bcf2b0046d394421700a451c08465093f075dcc66999fdeacea77c6691901ead9';
    wwv_flow_api.g_varchar2_table(293) := 'fd0552a0'||wwv_flow.LF||
'028a28a0028a28a009adeede0e33c118af6cfd8dbf6ecfda67f613f8b10fc6bfd96fe2c6a1e17d6e18963b916e';
    wwv_flow_api.g_varchar2_table(294) := 'c1edb5084127c8b981f31dc444ff000ba9c1f9'||wwv_flow.LF||
'976b00c3c369c923c6728d401fbc1f01ff00e0b6bff04c1fdb9fc6da3fc4';
    wwv_flow_api.g_varchar2_table(295) := '2fdb77c05aa7ece3f1db4bbcb6bdb3f8e1f0bad44fa6de5f42aeb0dcde5a4914eb23'||wwv_flow.LF||
'29760a2ea0ba08a5b13c60f1e7ff00';
    wwv_flow_api.g_varchar2_table(296) := '15bfe0daefda0be3743ac7c6dff827efedb7f0c3f688d0f56679e4beb5f12476ba9cb348cee7cdf9e6b7321663b8bce8c5'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(297) := 'b3951c81f8d30eab22060ffc4b8ae93c13f15bc6df0f35d5f157c3ef1a6aba0ea90c788352d1f5096d6e23ebf7648d830fc0';
    wwv_flow_api.g_varchar2_table(298) := 'd007ee17fc1543fe09a5fb49fc67'||wwv_flow.LF||
'f805e08d4be1afecfdfb4069be32f875f083c37e018fe1affc20b67a8e97aa47605fcd';
    wwv_flow_api.g_varchar2_table(299) := 'ba5bfd2f51b88f3be69661bd096c28c29391f3effc12dff619ff00829d'||wwv_flow.LF||
'fecc5fb7b7c3ff008f9e29ff00827afc5993c3fa';
    wwv_flow_api.g_varchar2_table(300) := '4eadf67f12dbc9e1192069b4cb9826b4bc502e0c68e7c8b8930a580271c8eb5f27f81bfe0b7dff00055ff877'||wwv_flow.LF||
'67f61f0cff';
    wwv_flow_api.g_varchar2_table(301) := '00c140be28490c718589756f144da86debc0fb51938fe55b1e23ff0082fa7fc15ebc4967258dff00edf9e3d8d1971bb4fbd8';
    wwv_flow_api.g_varchar2_table(302) := 'ad1c7d1e08d187e740'||wwv_flow.LF||
'1fab1f1dff00e0951ff0526fdbb3f617f85bfb34fed13f0fbc37f0b6dbe09f883515d17e297c4af1';
    wwv_flow_api.g_varchar2_table(303) := 'dda34b2f85640ab6f04d6b63f68d93a4715b21df32285b75'||wwv_flow.LF||
'04924b0f014f037fc1bb9ff0499793c47f163e30de7ed85f15';
    wwv_flow_api.g_varchar2_table(304) := '2c6456b7f0c786a3897c336f7031b7cd6567b77407860f35d74cfd9c1afca2f8cffb59fed19fb4'||wwv_flow.LF||
'25db5ffc79fda03c69e3';
    wwv_flow_api.g_varchar2_table(305) := '598481e393c59e29bbd4590fa8f3e46c7e15e7775acb396da739606803ed7ff829c7fc1713f6beff00829285f0178b754b3f';
    wwv_flow_api.g_varchar2_table(306) := '057c31d3'||wwv_flow.LF||
'6688687f0bfc1f9834d8238f6f9467230d74e800c17c46846638e3c915f11dfea4f333043f79b39aaf35ccb31c';
    wwv_flow_api.g_varchar2_table(307) := 'b3547400649e4d145140051451400514514005145140051451400bb9bfbc68dedfde345140099a28a2800a28a2800a28a280';
    wwv_flow_api.g_varchar2_table(308) := '0a28a2803fffd9}'||wwv_flow.LF||
'}}{\sp{\sn pictureGray}{\sv 0}}{\sp{\sn pictureBiLevel}{\sv 0}}{\sp{\sn fFilled}{\s';
    wwv_flow_api.g_varchar2_table(309) := 'v 0}}{\sp{\sn fNoFillHitTest}{\sv 0}}{\sp{\sn fLine}{\sv 0}}{\sp{\sn wzName}{\sv Picture 1}}{\sp{\sn';
    wwv_flow_api.g_varchar2_table(310) := ' posrelv}{\sv 1}}{\sp{\sn dhgt}{\sv 251658240}}'||wwv_flow.LF||
'{\sp{\sn fLayoutInCell}{\sv 1}}{\sp{\sn fAllowOverl';
    wwv_flow_api.g_varchar2_table(311) := 'ap}{\sv 1}}{\sp{\sn fBehindDocument}{\sv 0}}{\sp{\sn fHidden}{\sv 0}}{\sp{\sn sizerelh}{\sv 0}}{\sp{';
    wwv_flow_api.g_varchar2_table(312) := '\sn sizerelv}{\sv 0}}{\sp{\sn fLayoutInCell}{\sv 1}}}{\shprslt\par\pard'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\pvpg';
    wwv_flow_api.g_varchar2_table(313) := '\posx5009\posy239\dxfrtext180\dfrmtxtx180\dfrmtxty0\wraparound\aspalpha\aspnum\faauto\adjustright\ri';
    wwv_flow_api.g_varchar2_table(314) := 'n0\lin0\itap0 {\pict\picscalex105\picscaley103\piccropl0\piccropr0\piccropt0\piccropb0'||wwv_flow.LF||
'\picw1328\pi';
    wwv_flow_api.g_varchar2_table(315) := 'ch1316\picwgoal753\pichgoal746\wmetafile8\bliptag1982191550\blipupi220{\*\blipuid 7625d7beb2922187a5';
    wwv_flow_api.g_varchar2_table(316) := '6e7c9aa7c90388}010009000003c64d000000009d4d000000000400000003010800050000000b0200000000050000000c023';
    wwv_flow_api.g_varchar2_table(317) := '3003300030000001e00040000000701040004000000'||wwv_flow.LF||
'070104009d4d0000410b2000cc00720073000000000032003200000';
    wwv_flow_api.g_varchar2_table(318) := '000002800000073000000720000000100180000000000f89a000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(319) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(320) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(321) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(322) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(323) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(324) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(325) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(326) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(327) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(328) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000080808000000080';
    wwv_flow_api.g_varchar2_table(329) := '8080000000808'||wwv_flow.LF||
'0800000008080800000008080800000008080800000008080800000008080800000000000000000000000';
    wwv_flow_api.g_varchar2_table(330) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(331) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(332) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(333) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(334) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(335) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(336) := '000000000000808080000000808080000000808080000000808080000000808080000000808080000000000000000'||wwv_flow.LF||
'00080';
    wwv_flow_api.g_varchar2_table(337) := '8080000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(338) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(339) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(340) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(341) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(342) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000808080000000000000000000808080808080808080000000';
    wwv_flow_api.g_varchar2_table(343) := '8080808080808080800000010101008080808080800'||wwv_flow.LF||
'0000080808080808080808000000080808080808080808000000080';
    wwv_flow_api.g_varchar2_table(344) := '8080808080808080000000808080808080808080000000808080000000000000000000808'||wwv_flow.LF||
'0800000000000000000000000';
    wwv_flow_api.g_varchar2_table(345) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(346) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(347) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(348) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(349) := '000000000000000000000000000000000000000000000000000000000000000000000000000080808000000080808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(350) := '8080808080808080808000000080808080808080808080808080808080808080808080808080808000000080808000000080';
    wwv_flow_api.g_varchar2_table(351) := '80800000008080808080808'||wwv_flow.LF||
'080800000000000000000008080800000008080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(352) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(353) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(354) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(355) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(356) := '0000000000000000000000000000808080000000808'||wwv_flow.LF||
'0800000008080800000008080808080808080800000008080808080';
    wwv_flow_api.g_varchar2_table(357) := '8080808000000080808080808101010080808080808080808101010000000080808080808'||wwv_flow.LF||
'0808080808080808080808080';
    wwv_flow_api.g_varchar2_table(358) := '8080808080810101008080808080808080808080808080808080808080808080800000008080800000008080800000000000';
    wwv_flow_api.g_varchar2_table(359) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(360) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(361) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(362) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(363) := '0000000000000000000000000000000000000000000000000000008080800000000000000000008080800000008080808080';
    wwv_flow_api.g_varchar2_table(364) := '80808080808080808080808'||wwv_flow.LF||
'081010100808080000000808081010100808080808080808081010100808080808080808080';
    wwv_flow_api.g_varchar2_table(365) := '80808080808080808080808101010080808080808080808080808'||wwv_flow.LF||
'000000080808080808080808000000080808000000080';
    wwv_flow_api.g_varchar2_table(366) := '80800000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(367) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(368) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(369) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(370) := '0000000000000000000000000000008080800000008080800000008080808080808080800'||wwv_flow.LF||
'0000101010080808101010080';
    wwv_flow_api.g_varchar2_table(371) := '8081010100808081010100000001010100808081010100808081818181010101010100808081010100808080808080808081';
    wwv_flow_api.g_varchar2_table(372) := '010'||wwv_flow.LF||
'10101010101010080808101010080808080808080808101010080808080808080808101010080808080808080808080';
    wwv_flow_api.g_varchar2_table(373) := '808080808080808000000080808000000'||wwv_flow.LF||
'08080800000008080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(374) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(375) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(376) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(377) := '00000000000000000000000'||wwv_flow.LF||
'000000080808000000080808000000080808000000080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(378) := '80808080808080810101008080808080808080818181839393952'||wwv_flow.LF||
'52526b6b6b8484849494949c9c9ca5a5a5a5a5a5a5a5a';
    wwv_flow_api.g_varchar2_table(379) := '59c9c9c8c8c8c7b7b7b5a5a5a4242421818181010100808080808080808080808080808080808080808'||wwv_flow.LF||
'080808080808080';
    wwv_flow_api.g_varchar2_table(380) := '8080808080808080800000008080800000008080800000008080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(381) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(382) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(383) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(384) := '0000000080808000000080808000000080808080808080808080808080808080808080808080808101010080808101010101';
    wwv_flow_api.g_varchar2_table(385) := '010'||wwv_flow.LF||
'101010080808181818424242848484adadade7e7e7fffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(386) := 'fffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffefefefc6c6c69494945a5a5a2121211010100808081010100808080';
    wwv_flow_api.g_varchar2_table(387) := '808080808081010100808080808080808080808080808080808080000000808'||wwv_flow.LF||
'08000000080808000000000000000000000';
    wwv_flow_api.g_varchar2_table(388) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(389) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(390) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(391) := '00000000000000000000000000000000808080000000808080808'||wwv_flow.LF||
'080808080808080808080808081010100808080808080';
    wwv_flow_api.g_varchar2_table(392) := '808082121216b6b6bb5b5b5f7f7f7ffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(393) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffcecece8484843939391';
    wwv_flow_api.g_varchar2_table(394) := '0101000000010'||wwv_flow.LF||
'1010080808101010000000080808080808080808000000080808000000080808000000000000000000000';
    wwv_flow_api.g_varchar2_table(395) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(396) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(397) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(398) := '000'||wwv_flow.LF||
'00000808080000000808080000000808080808080808080000001010100808081010100808081010101010101818185';
    wwv_flow_api.g_varchar2_table(399) := 'a5a5ac6c6c6ffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffdededeb5b5b58c8c8c7b7b7b6363635252524a4';
    wwv_flow_api.g_varchar2_table(400) := 'a4a4a4a4a4242424a4a4a4a4a4a6363637373738c8c8ca5a5a5cececef7f7f7'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(401) := 'fffffffdedede7b7b7b29292910101010101008080808080810101010101008080808080810101000000000000008'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(402) := '8080800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(403) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(404) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(405) := '00000000000000000000000000000000008080808080808080808080808080808080810101008080808'||wwv_flow.LF||
'08082121218c8c8';
    wwv_flow_api.g_varchar2_table(406) := 'cefefeffffffffffffffffffffffffffffffff7f7f7b5b5b57b7b7b4242421818182121214242426b6b6b9494947b7b7b101';
    wwv_flow_api.g_varchar2_table(407) := '0101010101010'||wwv_flow.LF||
'101818181010101010101818181010101818186363632929291818183131316b6b6ba5a5a5dededefffff';
    wwv_flow_api.g_varchar2_table(408) := 'fffffffffffffffffffffffffffffffadadad424242'||wwv_flow.LF||
'0000001010100808081010100000000808080808080808080000000';
    wwv_flow_api.g_varchar2_table(409) := '8080800000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(410) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(411) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(412) := '000000000080808000000080808080808'||wwv_flow.LF||
'1010100808081010100808081010100808081010101010102929299c9c9cfffff';
    wwv_flow_api.g_varchar2_table(413) := 'fffffffffffffffffffffffffefefefa5a5a54a4a4a21212110101018181810'||wwv_flow.LF||
'10107b7b7bffffffffffffffffffffffffc';
    wwv_flow_api.g_varchar2_table(414) := 'ecece181818101010212121181818181818101010212121181818424242ffffffa5a5a51010102929297b7b7b4a4a'||wwv_flow.LF||
'4a101';
    wwv_flow_api.g_varchar2_table(415) := '010393939848484d6d6d6ffffffffffffffffffffffffffffffc6c6c64a4a4a1010101010100808081010100808080808080';
    wwv_flow_api.g_varchar2_table(416) := '80808080808080808000000'||wwv_flow.LF||
'080808000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(417) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(418) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(419) := '00000000000080808000000000000080808080808080808080808080808080808101010080808181818949494f7f7f7fffff';
    wwv_flow_api.g_varchar2_table(420) := 'fffffffffffff'||wwv_flow.LF||
'ffffffbdbdbd5a5a5a212121101010101010181818212121181818101010636363ffffffcecece6b6b6b4';
    wwv_flow_api.g_varchar2_table(421) := '2424221212118181810101018181821212110101010'||wwv_flow.LF||
'1010181818212121737373ffffff636363212121949494ffffffcec';
    wwv_flow_api.g_varchar2_table(422) := 'ece1818181010101010101818183939399c9c9cf7f7f7ffffffffffffffffffffffffbdbd'||wwv_flow.LF||
'bd39393908080810101008080';
    wwv_flow_api.g_varchar2_table(423) := '8101010000000080808080808080808000000080808000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(424) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(425) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(426) := '000000000000808080000000808080000000808080808081010100000001010'||wwv_flow.LF||
'10101010101010636363efefeffffffffff';
    wwv_flow_api.g_varchar2_table(427) := 'fffffffffffffffa5a5a5393939101010181818181818181818101010212121181818212121080808424242ffffff'||wwv_flow.LF||
'cecec';
    wwv_flow_api.g_varchar2_table(428) := 'e101010212121212121212121101010212121212121212121101010212121181818b5b5b5ffffff393939313131fffffffff';
    wwv_flow_api.g_varchar2_table(429) := 'fff94949418181810101018'||wwv_flow.LF||
'1818181818181818101010181818848484e7e7e7ffffffffffffffffffffffff94949418181';
    wwv_flow_api.g_varchar2_table(430) := '81010100808080808080808081010100808080808080000000808'||wwv_flow.LF||
'080000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(431) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(432) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(433) := '0000000000000'||wwv_flow.LF||
'0000000000080808000000080808000000101010080808080808080808292929c6c6c6fffffffffffffff';
    wwv_flow_api.g_varchar2_table(434) := 'fffffffff9c9c9c2929291818187b7b7bf7f7f73131'||wwv_flow.LF||
'31212121181818080808181818212121181818181818212121fffff';
    wwv_flow_api.g_varchar2_table(435) := 'fefefef181818181818212121212121181818212121212121181818181818212121181818'||wwv_flow.LF||
'e7e7e7e7e7e7212121a5a5a5f';
    wwv_flow_api.g_varchar2_table(436) := 'fffffffffff636363212121101010181818181818181818080808212121181818181818737373efefeffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(437) := 'fef'||wwv_flow.LF||
'efef5252521010100808080808080808080808080000000808080000000808080000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(438) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(439) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(440) := '00000000000000808080000000808080808080808080808080808080808081010100808086b6b6bf7f7f7ffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(441) := 'fffffbdbdbd424242181818848484424242848484ffffffa5a5a518181821212110101021212121212121212110101021212';
    wwv_flow_api.g_varchar2_table(442) := '1d6d6d6ffffff3939395a5a'||wwv_flow.LF||
'5a636363212121101010212121212121212121101010292929393939ffffffb5b5b54a4a4af';
    wwv_flow_api.g_varchar2_table(443) := 'fffffffffffffffff313131181818181818181818212121181818'||wwv_flow.LF||
'181818101010181818181818181818212121949494fff';
    wwv_flow_api.g_varchar2_table(444) := 'fffffffffffffffffffff9c9c9c10101010101010101008080808080808080808080800000008080800'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(445) := '0080808000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(446) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(447) := '0000000000000080808080808000000000000080808'||wwv_flow.LF||
'080808080808080808101010101010a5a5a5ffffffffffffffffffe';
    wwv_flow_api.g_varchar2_table(448) := 'fefef636363212121181818848484ffffffdedede212121e7e7e7ffffff39393918181810'||wwv_flow.LF||
'1010212121212121212121101';
    wwv_flow_api.g_varchar2_table(449) := '010212121b5b5b5ffffffffffffffffffefefef212121181818212121212121212121181818212121737373ffffff7b7b7bb';
    wwv_flow_api.g_varchar2_table(450) := '5b5'||wwv_flow.LF||
'b5f7f7f7f7f7f7e7e7e71818182121211010101818181818182121211010102121216b6b6bf7f7f7ffffffbdbdbd313';
    wwv_flow_api.g_varchar2_table(451) := '131393939c6c6c6ffffffffffffffffff'||wwv_flow.LF||
'd6d6d631313108080810101000000008080800000008080800000008080800000';
    wwv_flow_api.g_varchar2_table(452) := '008080800000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(453) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(454) := '000000000000000080808080808080808000000101010080808101010000000101010292929d6d6d6ffffffffffffffffffb';
    wwv_flow_api.g_varchar2_table(455) := 'dbdbd212121393939efefef'||wwv_flow.LF||
'949494393939ffffffffffffa5a5a56b6b6bffffffadadad212121101010292929212121212';
    wwv_flow_api.g_varchar2_table(456) := '121101010212121949494ffffffd6d6d69c9c9c73737329292910'||wwv_flow.LF||
'10102929292121212121211818182929299c9c9cfffff';
    wwv_flow_api.g_varchar2_table(457) := 'f7b7b7bffffffadadadffffffadadad292929212121181818181818292929212121101010424242ffff'||wwv_flow.LF||
'ffffffffdededef';
    wwv_flow_api.g_varchar2_table(458) := 'fffffe7e7e7181818101010848484fffffffffffffffffff7f7f75a5a5a10101008080808080810101008080808080808080';
    wwv_flow_api.g_varchar2_table(459) := '8080808080808'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(460) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(461) := '0000000000000000000000000000808080808080808080808081010100808080808083939'||wwv_flow.LF||
'39f7f7f7fffffffffffffffff';
    wwv_flow_api.g_varchar2_table(462) := 'f7b7b7b181818101010181818dededef7f7f7212121dededeffffffffffff6b6b6be7e7e7ffffff424242101010212121212';
    wwv_flow_api.g_varchar2_table(463) := '121'||wwv_flow.LF||
'2121211818182121216b6b6bffffffadadad212121292929292929181818212121292929212121181818212121d6d6d';
    wwv_flow_api.g_varchar2_table(464) := '6f7f7f7cececeefefef7b7b7bffffff84'||wwv_flow.LF||
'8484212121212121181818212121212121212121101010cececeffffff7b7b7b0';
    wwv_flow_api.g_varchar2_table(465) := '80808bdbdbdffffff424242101010181818424242e7e7e7ffffffffffffffff'||wwv_flow.LF||
'ff737373000000101010080808080808080';
    wwv_flow_api.g_varchar2_table(466) := '808080808000000080808000000080808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(467) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(468) := '00000000000000008080800'||wwv_flow.LF||
'00000808080000001010100808080808080808081010104a4a4af7f7f7ffffffffffffefefe';
    wwv_flow_api.g_varchar2_table(469) := 'f4a4a4a181818181818080808212121636363ffffff9c9c9c9494'||wwv_flow.LF||
'94ffffffc6c6c6f7f7f78c8c8cffffffbdbdbd1010102';
    wwv_flow_api.g_varchar2_table(470) := '929292929292929291818182929294a4a4affffffd6d6d6292929292929313131181818313131292929'||wwv_flow.LF||
'292929181818313';
    wwv_flow_api.g_varchar2_table(471) := '131ffffffffffffffffff8c8c8ca5a5a5ffffff4a4a4a2929292121212121212121212929292121216b6b6bffffffdedede2';
    wwv_flow_api.g_varchar2_table(472) := '12121181818e7'||wwv_flow.LF||
'e7e7ffffff292929101010181818181818212121cececeffffffffffffffffff8c8c8c080808101010080';
    wwv_flow_api.g_varchar2_table(473) := '8080808080808080808080808080808080000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(474) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(475) := '000000000000000000000000000000000000808080808080808080808080808081010104a4a4affffffffffffffffffd6d6d';
    wwv_flow_api.g_varchar2_table(476) := '629'||wwv_flow.LF||
'2929181818181818101010101010181818212121cececeffffff5a5a5affffff8c8c8cdededecececedededeffffff4';
    wwv_flow_api.g_varchar2_table(477) := '242422121212929292121211010102929'||wwv_flow.LF||
'29313131f7f7f7f7f7f7424242636363848484424242292929313131292929181';
    wwv_flow_api.g_varchar2_table(478) := '8185a5a5affffffffffffefefef313131d6d6d6efefef212121292929292929'||wwv_flow.LF||
'181818212121212121292929e7e7e7fffff';
    wwv_flow_api.g_varchar2_table(479) := 'f5a5a5a212121848484ffffffa5a5a5212121080808181818181818181818080808a5a5a5ffffffffffffffffff94'||wwv_flow.LF||
'94941';
    wwv_flow_api.g_varchar2_table(480) := '0101010101000000008080808080808080800000008080800000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(481) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(482) := '00000000000000000080808000000080808000000080808101010'||wwv_flow.LF||
'0808080000001010104a4a4affffffffffffffffffc6c';
    wwv_flow_api.g_varchar2_table(483) := '6c6292929080808181818181818212121080808212121181818636363ffffffadadade7e7e7cecece39'||wwv_flow.LF||
'3939ffffffd6d6d';
    wwv_flow_api.g_varchar2_table(484) := '6ffffffc6c6c6292929292929313131181818313131292929dededeffffffffffffffffffffffff848484313131313131292';
    wwv_flow_api.g_varchar2_table(485) := '9292121219494'||wwv_flow.LF||
'94ffffffffffff737373393939ffffffc6c6c6212121313131292929212121212121292929949494fffff';
    wwv_flow_api.g_varchar2_table(486) := 'fbdbdbd212121393939fffffff7f7f7393939212121'||wwv_flow.LF||
'1010101818181818181818181010101818188c8c8cfffffffffffff';
    wwv_flow_api.g_varchar2_table(487) := 'fffff94949408080808080808080810101008080808080808080808080800000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(488) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(489) := '000'||wwv_flow.LF||
'00000000000000000000000000080808000000080808080808080808080808080808393939f7f7f7ffffffffffffbdb';
    wwv_flow_api.g_varchar2_table(490) := 'dbd212121101010101010181818181818'||wwv_flow.LF||
'181818101010181818212121212121cececef7f7f7b5b5b5ffffff3131317b7b7';
    wwv_flow_api.g_varchar2_table(491) := 'bffffffffffffffffff5a5a5a313131292929181818292929313131adadadde'||wwv_flow.LF||
'dedeb5b5b59494947373733939393131313';
    wwv_flow_api.g_varchar2_table(492) := '131312929292121215a5a5aa5a5a5b5b5b52929295a5a5affffff8484842929292929292929291818182929293939'||wwv_flow.LF||
'39fff';
    wwv_flow_api.g_varchar2_table(493) := 'fffffffff4a4a4a292929a5a5a5ffffff8c8c8c212121212121101010212121181818181818101010181818101010848484f';
    wwv_flow_api.g_varchar2_table(494) := 'fffffffffffffffff848484'||wwv_flow.LF||
'080808080808080808080808000000080808000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(495) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(496) := '0000000000000000000080808000000080808080808080808080808080808080808101010292929efef'||wwv_flow.LF||
'efffffffffffffc';
    wwv_flow_api.g_varchar2_table(497) := '6c6c62121211818181818181010102121211818182121211010102121212121212929294a4a4affffffdededeffffff73737';
    wwv_flow_api.g_varchar2_table(498) := '3292929bdbdbd'||wwv_flow.LF||
'ffffffffffffd6d6d62929293131311818183131313131313939392121215a5a5a7373738c8c8c8c8c8c9';
    wwv_flow_api.g_varchar2_table(499) := 'c9c9c9c9c9c9c9c9c8484847b7b7b5a5a5a39393921'||wwv_flow.LF||
'21214a4a4a8c8c8c4a4a4a292929313131292929212121212121b5b';
    wwv_flow_api.g_varchar2_table(500) := '5b5ffffff9c9c9c2929294a4a4affffffe7e7e72929292121212121211818181818182121'||wwv_flow.LF||
'2118181810101018181818181';
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(501) := '8101010848484ffffffffffffffffff6b6b6b101010101010080808080808080808080808000000080808000000000000000';
    wwv_flow_api.g_varchar2_table(502) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(503) := '000000000000000000000000000000008'||wwv_flow.LF||
'0808000000080808080808080808080808101010101010d6d6d6ffffffffffffc';
    wwv_flow_api.g_varchar2_table(504) := 'ecece1818181010101818181818181010101818182121212121211010102121'||wwv_flow.LF||
'21292929212121101010bdbdbdfffffffff';
    wwv_flow_api.g_varchar2_table(505) := 'fffcecece292929393939e7e7e7ffffffefefef4a4a4a292929292929737373adadaddededeffffffffffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(506) := 'fffffffffffffffffffffffffffffffffffffffffffffffffe7e7e7bdbdbd8c8c8c393939292929313131313131212121525';
    wwv_flow_api.g_varchar2_table(507) := '252fffffff7f7f721212129'||wwv_flow.LF||
'2929c6c6c6ffffff5a5a5a29292921212121212110101021212121212121212108080818181';
    wwv_flow_api.g_varchar2_table(508) := '8181818181818080808949494fffffffffffff7f7f74a4a4a0808'||wwv_flow.LF||
'081010100000001010100808080808080000000000000';
    wwv_flow_api.g_varchar2_table(509) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(510) := '000000000000000000000000000080808080808080808080808080808080808080808080808101010adadadffffffffffffe';
    wwv_flow_api.g_varchar2_table(511) := 'fefef31313108'||wwv_flow.LF||
'0808181818181818212121101010212121212121212121101010292929212121292929181818525252fff';
    wwv_flow_api.g_varchar2_table(512) := 'fffffffffffffff4242423131316363638484844242'||wwv_flow.LF||
'426b6b6bbdbdbdfffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(513) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffd6d6d68c8c8c4242422';
    wwv_flow_api.g_varchar2_table(514) := '929299c9c9cffffff8484841818186b6b6bffffffcecece10101029292929292921212118181821212121212121212110101';
    wwv_flow_api.g_varchar2_table(515) := '018'||wwv_flow.LF||
'1818212121181818101010181818b5b5b5ffffffffffffe7e7e72929291010100808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(516) := '000000808080000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(517) := '000000000000000000000000000000000000000000000080808000000080808'||wwv_flow.LF||
'080808080808080808737373fffffffffff';
    wwv_flow_api.g_varchar2_table(518) := 'ff7f7f74a4a4a10101010101018181821212118181810101021212121212121212118181821212129292929292918'||wwv_flow.LF||
'18182';
    wwv_flow_api.g_varchar2_table(519) := '92929bdbdbdffffffffffff848484313131393939848484e7e7e7ffffffffffffffffffffffffffffffffffffe7e7e7bdbdb';
    wwv_flow_api.g_varchar2_table(520) := 'da5a5a58c8c8c7373737373'||wwv_flow.LF||
'737373737373737b7b7b949494b5b5b5d6d6d6fffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(521) := 'fffff9c9c9c4a4a4a6b6b6b393939212121e7e7e7ffffff525252'||wwv_flow.LF||
'181818292929212121292929101010292929212121212';
    wwv_flow_api.g_varchar2_table(522) := '121101010212121181818212121080808181818212121d6d6d6ffffffffffffbdbdbd10101000000010'||wwv_flow.LF||
'101008080808080';
    wwv_flow_api.g_varchar2_table(523) := '8000000080808000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(524) := '0000000000000'||wwv_flow.LF||
'00000000000000000000000000000000080808080808080808080808080808080808313131f7f7f7fffff';
    wwv_flow_api.g_varchar2_table(525) := 'fffffff737373181818181818080808181818212121'||wwv_flow.LF||
'2121211010102121212121212929291010102929292929292929291';
    wwv_flow_api.g_varchar2_table(526) := '818183131314a4a4affffff949494424242848484efefefffffffffffffffffffffffffef'||wwv_flow.LF||
'efefb5b5b57b7b7b4a4a4a212';
    wwv_flow_api.g_varchar2_table(527) := '1213939393939393939392121213939393939393939392929293939393939393131313131316b6b6b9c9c9ce7e7e7fffffff';
    wwv_flow_api.g_varchar2_table(528) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffadadad393939525252ffffffb5b5b5292929181818292929292929292929181818212121292';
    wwv_flow_api.g_varchar2_table(529) := '929212121181818212121212121181818'||wwv_flow.LF||
'101010181818181818292929ffffffffffffffffff73737308080808080808080';
    wwv_flow_api.g_varchar2_table(530) := '808080808080808080808080800000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(531) := '00000000000000000000000000000000000000000000000080808000000080808000000101010101010101010c6c6'||wwv_flow.LF||
'c6fff';
    wwv_flow_api.g_varchar2_table(532) := 'fffffffffadadad1818181818181818181010101818182121211818181010102121212929292121211818182929292929292';
    wwv_flow_api.g_varchar2_table(533) := '92929181818292929313131'||wwv_flow.LF||
'313131424242d6d6d6ffffffffffffffffffffffffd6d6d67b7b7b292929393939424242393';
    wwv_flow_api.g_varchar2_table(534) := '93921212139393942424239393929212142393942393931313129'||wwv_flow.LF||
'292939393942424231313131292939393942424229292';
    wwv_flow_api.g_varchar2_table(535) := '95a5a5aadadadfffffffffffffffffffffffff7f7f76b6b6b3939394242423131311010103131312929'||wwv_flow.LF||
'292929291010102';
    wwv_flow_api.g_varchar2_table(536) := '929292121212929291010102121212121211818180808081818181010101818185a5a5affffffffffffffffff29292910101';
    wwv_flow_api.g_varchar2_table(537) := '0080808101010'||wwv_flow.LF||
'0000000808080000000808080000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(538) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000080808080808080808080808101010080808101010737373fff';
    wwv_flow_api.g_varchar2_table(539) := 'fffffffffefefef1818181818181818182121211010102121212121212121211010102929'||wwv_flow.LF||
'2929292929292910101031313';
    wwv_flow_api.g_varchar2_table(540) := '1292929313131181818313131313131949494ffffffffffffffffffffffffc6c6c66b6b6b393939393939212121424242424';
    wwv_flow_api.g_varchar2_table(541) := '242'||wwv_flow.LF||
'4242422121214a42424242424242422929294a424242393942393929292942424242424239393929292942424239393';
    wwv_flow_api.g_varchar2_table(542) := '93131312929294242424a4a4aa5a5a5ff'||wwv_flow.LF||
'ffffffffffffffffffffffbdbdbd4242423131312121213131313131312929291';
    wwv_flow_api.g_varchar2_table(543) := '818182929292929292121211818182121212929291818181010101818182121'||wwv_flow.LF||
'21181818101010adadadffffffffffffc6c';
    wwv_flow_api.g_varchar2_table(544) := '6c6101010101010080808080808000000080808000000080808000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(545) := '0000000000000000000000000000000000000000000000000000000000000000000080808101010080808101010212121f7f';
    wwv_flow_api.g_varchar2_table(546) := '7f7ffffffffffff5a5a5a10'||wwv_flow.LF||
'101010101021212118181818181818181821212121212118181821212129292929292918181';
    wwv_flow_api.g_varchar2_table(547) := '8292929292929292929212121313131bdbdbdffffffffffffffff'||wwv_flow.LF||
'ffefefef7373732121213939394242423939392121214';
    wwv_flow_api.g_varchar2_table(548) := '23939424242424242292929423939424242393939292929424242424242393939313131423939424242'||wwv_flow.LF||
'393131313131393';
    wwv_flow_api.g_varchar2_table(549) := '9394242422929293939393939393939392929294a4a4ac6c6c6ffffffffffffffffffe7e7e75a5a5a1010103131312929292';
    wwv_flow_api.g_varchar2_table(550) := '9292918181829'||wwv_flow.LF||
'2929292929292929101010212121181818292929101010181818181818212121080808212121e7e7e7fff';
    wwv_flow_api.g_varchar2_table(551) := 'fffffffff6b6b6b0808080808080808080808080000'||wwv_flow.LF||
'0008080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(552) := '0000000000000000000000000000000000000000000000000080808000000080808080808'||wwv_flow.LF||
'080808080808080808080808a';
    wwv_flow_api.g_varchar2_table(553) := '5a5a5ffffffffffffb5b5b518181810101018181818181821212110101021212121212129292910101029292929292931313';
    wwv_flow_api.g_varchar2_table(554) := '118'||wwv_flow.LF||
'1818313131313131393939313131dededeffffffffffffffffffb5b5b54242424242422121214242423939394a4a4a2';
    wwv_flow_api.g_varchar2_table(555) := '121214a42424239394a42422929294a42'||wwv_flow.LF||
'424a42424a42422929294a4a4a4a42424242422929294a4a4a424242393939313';
    wwv_flow_api.g_varchar2_table(556) := '1314242423939393939393131314242424242422929293131313939397b7b7b'||wwv_flow.LF||
'fffffffffffffffffff7f7f763636331313';
    wwv_flow_api.g_varchar2_table(557) := '131313129292921212129292929292929292918181821212129292921212118181818181821212118181810101018'||wwv_flow.LF||
'18186';
    wwv_flow_api.g_varchar2_table(558) := 'b6b6bffffffffffffe7e7e718181810101008080808080808080800000008080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(559) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000808080808080808080808080808080808083';
    wwv_flow_api.g_varchar2_table(560) := '93939ffffffffffffffffff313131101010101010101010212121'||wwv_flow.LF||
'181818101010212121212121212121101010292929292';
    wwv_flow_api.g_varchar2_table(561) := '9292929291818183129293131314a4a4ae7e7e7fffffffffffffff7f76b6b6b39393942393939393921'||wwv_flow.LF||
'212142424242424';
    wwv_flow_api.g_varchar2_table(562) := '24242422921214242424a424a4242422921294a424a4a4a4a4242422929294a42424a4a4a4239423129314a42424a4a4a393';
    wwv_flow_api.g_varchar2_table(563) := '1393131314242'||wwv_flow.LF||
'424a4242313131313131424242424242292929393939393939424242424242dededefffffffffffffffff';
    wwv_flow_api.g_varchar2_table(564) := 'f7b7b7b313131313131181818292929292929292929'||wwv_flow.LF||
'1010102929292121212929291010102121211818182121210808081';
    wwv_flow_api.g_varchar2_table(565) := '81818101010cececeffffffffffff84848410101000000008080808080808080800000008'||wwv_flow.LF||
'0808000000000000000000000';
    wwv_flow_api.g_varchar2_table(566) := '0000000000000000000000000000000000000000000000000000000000000000808080000000808080808081010100808081';
    wwv_flow_api.g_varchar2_table(567) := '010'||wwv_flow.LF||
'10adadadffffffffffff949494181818181818101010181818181818212121101010212121292929292929101010313';
    wwv_flow_api.g_varchar2_table(568) := '1312929292929291818183939394a4242'||wwv_flow.LF||
'efe7e7ffffffffffffefefef635a5a2121214242424239394242422121214a424';
    wwv_flow_api.g_varchar2_table(569) := '24242424a42422121214a4a4a4a424a4a4a4a292129524a4a4a4a4a4a4a4a29'||wwv_flow.LF||
'29294a4a4a4a4a4a4a42423129314a4a4a4';
    wwv_flow_api.g_varchar2_table(570) := 'a4a4a4239423131314a4a4a4a42423939393131314a4a4a424242313131393939424242423939292929424242cece'||wwv_flow.LF||
'cefff';
    wwv_flow_api.g_varchar2_table(571) := 'fffffffffffffff7373733939392121212929293131312929291818182121212929292121211818182121212121212121211';
    wwv_flow_api.g_varchar2_table(572) := '01010181818212121424242'||wwv_flow.LF||
'ffffffffffffefefef181818080808080808101010080808080808000000080808000000000';
    wwv_flow_api.g_varchar2_table(573) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000008080800000008080808080';
    wwv_flow_api.g_varchar2_table(574) := '8101010292929fffffffffffff7f7f72929291010101818181010101818181818182121211818182121'||wwv_flow.LF||
'212121212929291';
    wwv_flow_api.g_varchar2_table(575) := '81818292929313131292929181818393131e7dedeffffffffffffe7e7e752525242424221212139393942424242424229212';
    wwv_flow_api.g_varchar2_table(576) := '14242424a4242'||wwv_flow.LF||
'4242422929294a42424a4a4a4a4a4a2929294a4a4a4a4a4a4a42423129314a4a4a4a4a4a4242423131314';
    wwv_flow_api.g_varchar2_table(577) := 'a424a4a4a4a3939393931394a42424a4a4a31313139'||wwv_flow.LF||
'39394242424a4242292929393939423939424242212121393939393';
    wwv_flow_api.g_varchar2_table(578) := '939bdbdbdffffffffffffffffff5a5a5a1818183131312929292929291818182929292121'||wwv_flow.LF||
'2129292910101021212118181';
    wwv_flow_api.g_varchar2_table(579) := '8212121101010181818101010181818b5b5b5ffffffffffff848484000000101010080808080808000000080808000000000';
    wwv_flow_api.g_varchar2_table(580) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000008080808080808080808080';
    wwv_flow_api.g_varchar2_table(581) := '81010100808089c9c9cffffffffffff8c'||wwv_flow.LF||
'8c8c1010101818182121211010102121211818182929291010102929292929292';
    wwv_flow_api.g_varchar2_table(582) := '92929181818313131292929313131212121cec6c6fffffffffffff7efef5252'||wwv_flow.LF||
'524239394242422121214242424242424a4';
    wwv_flow_api.g_varchar2_table(583) := 'a4a2921214a4a4a4a42424a4a4a292929524a4a4a4a4a524a52292929524a524a4a4a4a4a4a312929524a524a4a4a'||wwv_flow.LF||
'4a4a4';
    wwv_flow_api.g_varchar2_table(584) := 'a313131524a524a4a4a424242393139524a4a4a4a4a3939393939394a4a4a4a42423131313939394a4242423939292929393';
    wwv_flow_api.g_varchar2_table(585) := '939424242424242c6c6c6ff'||wwv_flow.LF||
'ffffffffffefefef39393931313131313129292918181829292929292929292918181821212';
    wwv_flow_api.g_varchar2_table(586) := '1212121212121101010181818212121101010424242ffffffffff'||wwv_flow.LF||
'ffe7e7e71010100808081010100808080808080808080';
    wwv_flow_api.g_varchar2_table(587) := '80808000000000000000000000000000000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'000000080808000';
    wwv_flow_api.g_varchar2_table(588) := '000080808080808181818f7f7f7ffffffffffff2929291010102121211818181010101818182121212121211818182121212';
    wwv_flow_api.g_varchar2_table(589) := '9292929292918'||wwv_flow.LF||
'18182929293131313131318c8c8cffffffffffffffffff4242424239393939394239392929294242424a4';
    wwv_flow_api.g_varchar2_table(590) := '2424242422929294a42424a4a4a4a42422929294a4a'||wwv_flow.LF||
'4a524a4a4a4a4a2929294a4a4a524a524a424a3129314a4a4a524a5';
    wwv_flow_api.g_varchar2_table(591) := '24242423131314a4a4a524a524239393931394a4a4a524a4a3931313939394a4a4a4a4a4a'||wwv_flow.LF||
'3129294239394242424a42422';
    wwv_flow_api.g_varchar2_table(592) := '92929393939393939393939292929d6d6d6ffffffffffffcecece39393931313131313110101031313129292929292910101';
    wwv_flow_api.g_varchar2_table(593) := '021'||wwv_flow.LF||
'2121212121212121080808212121181818181818080808c6c6c6ffffffffffff5a5a5a1010100808080808080000000';
    wwv_flow_api.g_varchar2_table(594) := '808080000000808080000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000080808000000080808080';
    wwv_flow_api.g_varchar2_table(595) := '808080808101010101010737373ffffffffffffadadad101010181818181818'||wwv_flow.LF||
'21212110101021212121212129292910101';
    wwv_flow_api.g_varchar2_table(596) := '02929292121213131311818183131313131315a5a5affffffffffffffffff7b7b7b21181842424242424242424221'||wwv_flow.LF||
'21214';
    wwv_flow_api.g_varchar2_table(597) := 'a4a4a4242424a4a4a292121524a4a4a4a4a524a4a2929295252524a4a4a5252522929295252524a4a4a524a4a31292952525';
    wwv_flow_api.g_varchar2_table(598) := '2524a4a4a4a4a3131315252'||wwv_flow.LF||
'52524a4a4242423931395252524a4a4a423939393939524a4a4a4a4a3931313939394a4a4a4';
    wwv_flow_api.g_varchar2_table(599) := '242422929293939394a4a4a4239392121214a4a4aefefefffffff'||wwv_flow.LF||
'ffffff949494393939313131181818292929313131292';
    wwv_flow_api.g_varchar2_table(600) := '9291818182121212929292121211010101818182121211818180808085a5a5affffffffffffcecece10'||wwv_flow.LF||
'101010101008080';
    wwv_flow_api.g_varchar2_table(601) := '8080808080808080808000000000000000000000000000000000000000000000000000000000000000000000000080808080';
    wwv_flow_api.g_varchar2_table(602) := '8080808080808'||wwv_flow.LF||
'08080808080808d6d6d6ffffffffffff4a4a4a10101010101018181818181818181818181821212121212';
    wwv_flow_api.g_varchar2_table(603) := '1181818212121292929292929181818292929313131'||wwv_flow.LF||
'd6d6d6ffffffffffffb5b5b53939392121213939394242424242422';
    wwv_flow_api.g_varchar2_table(604) := '929294242424a4a4a4a42422929294a4a4a524a4a4a4a4a2929294a4a4a524a524a4a4a31'||wwv_flow.LF||
'29314a4a4a524a524a4a4a313';
    wwv_flow_api.g_varchar2_table(605) := '1314a4a4a524a524242423931394a4a4a524a524239423939394a4a4a524a4a3939394239394a4a4a4a4a4a3131314242424';
    wwv_flow_api.g_varchar2_table(606) := '242'||wwv_flow.LF||
'424a4a4a2929294242423939394242421818184242426b6b6bffffffffffffffffff4a4a4a313131101010313131292';
    wwv_flow_api.g_varchar2_table(607) := '929292929101010292929212121212121'||wwv_flow.LF||
'101010212121181818181818101010181818e7e7e7ffffffffffff29292908080';
    wwv_flow_api.g_varchar2_table(608) := '808080800000008080800000008080800000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000808080';
    wwv_flow_api.g_varchar2_table(609) := '80808080808080808080808101010393939ffffffffffffdedede1818181010101818181818182121211010102121'||wwv_flow.LF||
'21212';
    wwv_flow_api.g_varchar2_table(610) := '121292929181818292929292929313131181818393939848484ffffffffffffefefef4242424242422121214242424242424';
    wwv_flow_api.g_varchar2_table(611) := 'a42422921214a4a4a4a4242'||wwv_flow.LF||
'4a4a4a292929524a4a4a4a4a525252292929525252524a4a525252312929525252524a4a524';
    wwv_flow_api.g_varchar2_table(612) := 'a52313131525252524a4a4a4a4a313131525252524a524a424a39'||wwv_flow.LF||
'39395252524a4a4a4242423939395252524a4a4a39393';
    wwv_flow_api.g_varchar2_table(613) := '94242424a4a4a4a4a4a2929294239394a4242424242292929393939424242adadadffffffffffffcece'||wwv_flow.LF||
'ce3131312121212';
    wwv_flow_api.g_varchar2_table(614) := '92929313131292929181818292929292929212121181818212121212121181818101010181818949494ffffffffffff84848';
    wwv_flow_api.g_varchar2_table(615) := '4101010080808'||wwv_flow.LF||
'0808080808080808080000000808080000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(616) := '000000808080808080808080808081010107b7b7bff'||wwv_flow.LF||
'ffffffffff8c8c8c181818101010101010212121181818181818181';
    wwv_flow_api.g_varchar2_table(617) := '818292929212121181818212121313131292929212121393939efefefffffffffffff7373'||wwv_flow.LF||
'7339393939393921212139393';
    wwv_flow_api.g_varchar2_table(618) := '94242424242422929294242424a4a4a4a4a4a2929294a4a4a4a4a4a4a4a4a2929294a4a4a5252524a4a4a2929294a4a4a525';
    wwv_flow_api.g_varchar2_table(619) := '252'||wwv_flow.LF||
'4a4a4a3131314a4a4a5252524242423131314a4a4a5252524242423939394a4a4a5252523939393939394a4a4a4a4a4';
    wwv_flow_api.g_varchar2_table(620) := 'a3131314242424a4a4a4a4a4a21212142'||wwv_flow.LF||
'4242424242424242212121424242393939424242efefefffffffffffff6b6b6b1';
    wwv_flow_api.g_varchar2_table(621) := '818183131312929293131311010102929292121212929291010102121211818'||wwv_flow.LF||
'18181818101010181818393939fffffffff';
    wwv_flow_api.g_varchar2_table(622) := 'fffd6d6d6080808080808000000080808000000080808000000080808000000000000000000000000000000000000'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(623) := '8000000080808080808080808080808101010080808cececeffffffffffff424242181818101010181818212121212121101';
    wwv_flow_api.g_varchar2_table(624) := '01021212121212129292918'||wwv_flow.LF||
'18182929293131313131311818188c8c8cffffffffffffbdbdbd39393939393942424221212';
    wwv_flow_api.g_varchar2_table(625) := '14a4a4a4a4a4a4242422929295252524a4a4a4a4a4a2929295252'||wwv_flow.LF||
'525252525252522929295252525252525252523131315';
    wwv_flow_api.g_varchar2_table(626) := '252525252525252523131315252525252524a4a4a3939395252525252524a4a4a393939525252525252'||wwv_flow.LF||
'393939393939525';
    wwv_flow_api.g_varchar2_table(627) := '2524a4a4a3939394242425252524a4a4a2929294242424a4a4a424242292929424242424242393939848484ffffffffffffc';
    wwv_flow_api.g_varchar2_table(628) := 'ecece21212129'||wwv_flow.LF||
'2929313131292929181818292929292929212121101010212121212121212121080808181818181818ded';
    wwv_flow_api.g_varchar2_table(629) := 'edeffffffffffff3131311010100808080808080808'||wwv_flow.LF||
'0808080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(630) := '0000000080808000000080808080808080808080808212121ffffffffffffe7e7e7181818'||wwv_flow.LF||
'1818181010101010102121212';
    wwv_flow_api.g_varchar2_table(631) := '12121181818181818292929292929181818292929292929313131212121efefefffffffffffff4a4a4a39393942424239393';
    wwv_flow_api.g_varchar2_table(632) := '96b'||wwv_flow.LF||
'6b6ba5a5a5adadadadadada5a5a5adadadadadadadadada5a5a5adadadb5b5b5adadada5a5a5adadadb5b5b5adadada';
    wwv_flow_api.g_varchar2_table(633) := '5a5a5adadadb5b5b5adadada5a5a5adad'||wwv_flow.LF||
'adb5b5b5adadada5a5a5adadadb5b5b5a5a5a5adadadadadadb5b5b5a5a5a5ada';
    wwv_flow_api.g_varchar2_table(634) := 'dadadadadb5b5b5a5a5a5adadadadadadb5b5b5a5a5a5adadadadadadadadad'||wwv_flow.LF||
'9c9c9c7b7b7b393939393939212121efefe';
    wwv_flow_api.g_varchar2_table(635) := 'fffffffffffff4a4a4a31313129292931313110101029292921212129292910101021212118181818181810101018'||wwv_flow.LF||
'18181';
    wwv_flow_api.g_varchar2_table(636) := '81818949494ffffffffffff63636310101000000008080808080808080800000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(637) := '00000000808080000000808'||wwv_flow.LF||
'080808081010100808080808085a5a5affffffffffffadadad1818182121211010101818182';
    wwv_flow_api.g_varchar2_table(638) := '12121212121181818212121292929292929181818292929313131'||wwv_flow.LF||
'3131316b6b6bffffffffffffd6d6d6181818424242393';
    wwv_flow_api.g_varchar2_table(639) := '9399c9c9cffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(640) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(641) := 'fffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff9c9c9c42424221212';
    wwv_flow_api.g_varchar2_table(642) := '18c8c8cffffffffffffb5b5b5313131313131292929'||wwv_flow.LF||
'1818182929292929292121211818182121212121211818181010101';
    wwv_flow_api.g_varchar2_table(643) := '818181818185a5a5affffffffffffb5b5b508080808080808080808080808080808080800'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(644) := '000000000000000000000000000000000080808080808080808080808949494ffffffffffff6b6b6b1818181818181818181';
    wwv_flow_api.g_varchar2_table(645) := '818'||wwv_flow.LF||
'18212121212121181818212121292929292929181818292929313131292929c6c6c6ffffffffffff737373212121393';
    wwv_flow_api.g_varchar2_table(646) := '939424242e7e7e7ffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(647) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(648) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe7e7'||wwv_flow.LF||
'e7393';
    wwv_flow_api.g_varchar2_table(649) := '939212121424242f7f7f7fffffff7f7f74242423131313131311010102929292929292929291010102121212121212121210';
    wwv_flow_api.g_varchar2_table(650) := '80808181818181818212121'||wwv_flow.LF||
'ffffffffffffe7e7e7101010000000080808080808080808000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(651) := '00000000000000000000008080800000008080808080810101008'||wwv_flow.LF||
'0808080808c6c6c6ffffffffffff39393918181818181';
    wwv_flow_api.g_varchar2_table(652) := '8101010181818212121212121181818212121292929292929181818313131313131424242ffffffffff'||wwv_flow.LF||
'fff7f7f74242421';
    wwv_flow_api.g_varchar2_table(653) := '81818424242424242dededefffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(654) := 'fffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(655) := 'fffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffded';
    wwv_flow_api.g_varchar2_table(656) := 'ede393939292929393939bdbdbdffffffffffff7b7b7b3131313131311818182929292929'||wwv_flow.LF||
'2929292918181821212129292';
    wwv_flow_api.g_varchar2_table(657) := '9181818181818181818212121181818d6d6d6ffffffffffff212121080808080808080808080808080808000000080808000';
    wwv_flow_api.g_varchar2_table(658) := '000'||wwv_flow.LF||
'000000000000000000000000000000080808000000080808080808080808080808f7f7f7fffffff7f7f710101018181';
    wwv_flow_api.g_varchar2_table(659) := '818181818181818181821212121212118'||wwv_flow.LF||
'1818212121292929292929181818292929313131737373ffffffffffffb5b5b53';
    wwv_flow_api.g_varchar2_table(660) := '93939212121393939424242737373f7f7f7ffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(661) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(662) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(663) := 'fff6b6b6b42424221212139'||wwv_flow.LF||
'39396b6b6bffffffffffffbdbdbd31313131313118181829292929292929292910101029292';
    wwv_flow_api.g_varchar2_table(664) := '92121212121210808081818181818181818189c9c9cffffffffff'||wwv_flow.LF||
'ff5252520000001010100808080808080000000808080';
    wwv_flow_api.g_varchar2_table(665) := '00000000000000000000000000000000000080808000000080808080808101010080808292929ffffff'||wwv_flow.LF||
'ffffffc6c6c6181';
    wwv_flow_api.g_varchar2_table(666) := '818181818212121101010181818212121292929181818212121292929313131181818313131313131b5b5b5ffffffffffff7';
    wwv_flow_api.g_varchar2_table(667) := 'b7b7b39393921'||wwv_flow.LF||
'21214242424242424242423131316b6b6b737373fffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(668) := 'fffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(669) := 'ffffffffffffffffffffffffffffffff7f7f7ffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffefefef6b6b6b5';
    wwv_flow_api.g_varchar2_table(670) := '252524a4a4a424242424242292929393939424242ffffffffffffefefef31313131313118181829292929292929292918181';
    wwv_flow_api.g_varchar2_table(671) := '821'||wwv_flow.LF||
'21212121212121211010102121211818181818187b7b7bffffffffffff7b7b7b0808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(672) := '808080000000000000000000000000000'||wwv_flow.LF||
'00000000000000080808000000080808080808101010424242ffffffffffffa5a';
    wwv_flow_api.g_varchar2_table(673) := '5a5101010181818181818181818181818292929212121181818212121292929'||wwv_flow.LF||
'292929181818292929313131dededefffff';
    wwv_flow_api.g_varchar2_table(674) := 'fffffff5252523939392121214242424242424242422921214a4a4a524a52a59c9cadadadbdbdbdc6c6c6bdbdbdbd'||wwv_flow.LF||
'b5bdb';
    wwv_flow_api.g_varchar2_table(675) := 'dbdbdc6c6c6bdbdbdadadadb5b5b5b5b5b5adadad9c9c9ca5a5a5a5a5a5949494847b7b8c8c8c948c8c7b7b7b6b6b6b73737';
    wwv_flow_api.g_varchar2_table(676) := '37373735a5a5a4a4a4a5a5a'||wwv_flow.LF||
'5a5a5a5a3939394242427b7b7bffffffffffffffffffffffffffffffffffffffffffcecece4';
    wwv_flow_api.g_varchar2_table(677) := 'a4a4a2921294a4242424242424242212121393939393939cecece'||wwv_flow.LF||
'ffffffffffff4a4a4a313131101010313131292929292';
    wwv_flow_api.g_varchar2_table(678) := '9291010102121212121212121210808082121211818181818184a4a4affffffffffffa5a5a500000010'||wwv_flow.LF||
'101008080808080';
    wwv_flow_api.g_varchar2_table(679) := '80000000808080000000000000000000000000000000000000808080000000808080808081010100808086b6b6bfffffffff';
    wwv_flow_api.g_varchar2_table(680) := 'fff7b7b7b1010'||wwv_flow.LF||
'10181818212121181818212121212121212121181818292929292929313131181818313131393939fffff';
    wwv_flow_api.g_varchar2_table(681) := 'fffffffefefef3939394242422121214a4a4a424242'||wwv_flow.LF||
'4a4a4a292121524a524a4a4a525252292929525252524a525252522';
    wwv_flow_api.g_varchar2_table(682) := '921295a52525252525252523131315a5a5a5252525a5a5a3129295a5a5a5a5a5a5a5a5a31'||wwv_flow.LF||
'3131635a5a5a5a5a525252393';
    wwv_flow_api.g_varchar2_table(683) := '9395a5a5a5a5252524a4a3939395a52525252524242424242429c9c9cffffffffffffffffffffffffffffffffffffffffffb';
    wwv_flow_api.g_varchar2_table(684) := 'db5'||wwv_flow.LF||
'bd4a4a4a2921294a424a4a4a4a424242292929393939424242a5a5a5ffffffffffff7b7b7b313131181818292929313';
    wwv_flow_api.g_varchar2_table(685) := '131292929181818212121212121212121'||wwv_flow.LF||
'101010181818212121181818313131ffffffffffffb5b5b508080808080810101';
    wwv_flow_api.g_varchar2_table(686) := '008080808080808080808080800000000000000000000000000000000000008'||wwv_flow.LF||
'08080000000808080808081010107b7b7bf';
    wwv_flow_api.g_varchar2_table(687) := 'fffffffffff6b6b6b1010101818186b6b6b949494181818212121cecece1818182121215a5a5aadadad2121212929'||wwv_flow.LF||
'29525';
    wwv_flow_api.g_varchar2_table(688) := '252ffffffffffffbdbdbd3939393939392921214242424242424242422929294a4a4a4a4a4a5a5a5a636363847b84948c949';
    wwv_flow_api.g_varchar2_table(689) := '494948c8c8ca59c9cadadad'||wwv_flow.LF||
'adadadadadad7373735a5a5a5a52523131315252525a5a5a5a52523939395a5a5a5a5a5a524';
    wwv_flow_api.g_varchar2_table(690) := 'a4a3939395a5a5a5a5a5a4a42424242425252525a52523939396b'||wwv_flow.LF||
'6b6bf7f7f7fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(691) := 'fffffff8c8c8c4a4a4a2921214a4a4a424242424242212121424242393939847b7bffffffffffff9c9c'||wwv_flow.LF||
'9c3131311818182';
    wwv_flow_api.g_varchar2_table(692) := '929299494947b7b7b101010313131bdbdbd212121080808737373848484181818101010ffffffffffffd6d6d608080810101';
    wwv_flow_api.g_varchar2_table(693) := '0080808080808'||wwv_flow.LF||
'0000000808080000000000000000000000000000000000000808080000000808080808081010100808089';
    wwv_flow_api.g_varchar2_table(694) := '49494ffffffffffff525252101010181818292929c6'||wwv_flow.LF||
'c6c6848484212121cecece101010424242d6d6d65a5a5a181818313';
    wwv_flow_api.g_varchar2_table(695) := '1316b6b6bffffffffffffada5a54239394242422121214242424242424a4a4a292121524a'||wwv_flow.LF||
'4a4a4a4a8c8c8cfffffffffff';
    wwv_flow_api.g_varchar2_table(696) := 'fffffffffffffffffffffffffffffffffffffffffffffffffb5b5b56b6b6b3131315a5a5a5a5a5a525252393131635a5a5a5';
    wwv_flow_api.g_varchar2_table(697) := 'a5a'||wwv_flow.LF||
'5a5252393939635a5a5a5a5a4a4a4a4242425a5a5a737373c6c6c6fffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(698) := 'fffffffffffff635a634a4a4a2929294a'||wwv_flow.LF||
'4a4a4a4a4a424242292929423939424242636363ffffffffffffb5b5b53131312';
    wwv_flow_api.g_varchar2_table(699) := '12121292929424242dedede5a5a5a313131bdbdbd2121214a4a4acecece3939'||wwv_flow.LF||
'39181818101010f7f7f7ffffffefefef080';
    wwv_flow_api.g_varchar2_table(700) := '808080808101010080808080808080808080808000000000000000000000000000000000000080808000000080808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(701) := '8101010a5a5a5ffffffffffff424242101010212121181818212121b5b5b5636363a5a5a5292929b5b5b54a4a4a292929212';
    wwv_flow_api.g_varchar2_table(702) := '121292929848484ffffffff'||wwv_flow.LF||
'ffff9494944239393939392121214242424242424242422929294a4a4a524a52525252fffff';
    wwv_flow_api.g_varchar2_table(703) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffd6d6d6adadad8484846363633939395';
    wwv_flow_api.g_varchar2_table(704) := 'a5a5a636363524a4a393939635a5a736b6b847b7ba5a5a5e7e7e7ffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(705) := 'fffffffffffffffdedede4a4a4a524a4a2121214a4a4a424242424242212121424242393939525252ffffffffffffcecece3';
    wwv_flow_api.g_varchar2_table(706) := '1313110101031'||wwv_flow.LF||
'3131292929424242c6c6c64a4a4aa5a5a5424242b5b5b5292929181818181818080808efefeffffffffff';
    wwv_flow_api.g_varchar2_table(707) := 'fff0000000808080808080808080000000808080000'||wwv_flow.LF||
'0000000000000000000000000000000008080800000008080808080';
    wwv_flow_api.g_varchar2_table(708) := '8101010080808b5b5b5ffffffffffff393939181818101010212121101010212121b5b5b5'||wwv_flow.LF||
'bdbdbd9c9c9c3939392929292';
    wwv_flow_api.g_varchar2_table(709) := '92929181818313131949494ffffffffffff8c84843939394242422121214a4a4a4242424a4a4a2929294a4a4a4a4a4a52525';
    wwv_flow_api.g_varchar2_table(710) := '2bd'||wwv_flow.LF||
'bdbdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(711) := 'ff7f7f7f7f7efefefefefefefefefffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(712) := 'fffffffffffffffffffff949494524a52524a4a2929294a4a4a4a4a4a424242'||wwv_flow.LF||
'292929424242424242424242fffffffffff';
    wwv_flow_api.g_varchar2_table(713) := 'fdedede313131212121292929313131292929292929bdbdbdbdbdbd949494181818181818212121181818080808de'||wwv_flow.LF||
'dedef';
    wwv_flow_api.g_varchar2_table(714) := 'fffffffffff10101008080810101008080808080808080808080800000000000000000000000000000000000008080800000';
    wwv_flow_api.g_varchar2_table(715) := '0080808080808101010adad'||wwv_flow.LF||
'adffffffffffff393939101010212121181818181818181818313131efefef5a5a5a2121212';
    wwv_flow_api.g_varchar2_table(716) := '92929292929212121292929949494ffffffffffff7b7b7b393939'||wwv_flow.LF||
'3939392921214242424242424242422929294a4a4a4a4';
    wwv_flow_api.g_varchar2_table(717) := 'a4a4a4a52525252ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffff7f7f';
    wwv_flow_api.g_varchar2_table(718) := '7d6d6d6b5adadadadadc6bdbde7e7e7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(719) := 'fffffffffffff'||wwv_flow.LF||
'fffffffff7eff7524a524a4a4a4a4a4a2929294a4a4a424242424242212121424242393939424242fffff';
    wwv_flow_api.g_varchar2_table(720) := 'fffffffdedede313131181818292929292929292929'||wwv_flow.LF||
'101010525252efefef4a4a4a101010181818181818181818080808d';
    wwv_flow_api.g_varchar2_table(721) := '6d6d6ffffffffffff10101010101008080808080800000008080800000000000000000000'||wwv_flow.LF||
'0000000000000000080808000';
    wwv_flow_api.g_varchar2_table(722) := '000080808080808101010080808b5b5b5ffffffffffff393939101010181818212121212121b5b5b5b5b5b57b7b7bcecece8';
    wwv_flow_api.g_varchar2_table(723) := '484'||wwv_flow.LF||
'84292929292929181818313131949494ffffffffffff7b7b7b4239394242422121214242424242424a4a4a2929294a4';
    wwv_flow_api.g_varchar2_table(724) := 'a524a4a4a525252292929cececeffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffefefefd6d6d6b5b5b5a59c9c6363636b6b6';
    wwv_flow_api.g_varchar2_table(725) := 'b5a5a5a5a5a5a393939636363635a5a5a5252737373f7f7f7ffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(726) := 'fffffffffffffffffffffffffffff847b844a4a4a524a4a4a4a4a2929294a4a4a4a4a4a4242422929294239394242'||wwv_flow.LF||
'42423';
    wwv_flow_api.g_varchar2_table(727) := '939ffffffffffffdedede313131181818313131292929424242bdbdbd9c9c9c7b7b7bdedede5a5a5a1818181818181818181';
    wwv_flow_api.g_varchar2_table(728) := '01010d6d6d6ffffffffffff'||wwv_flow.LF||
'181818080808101010080808080808080808080808000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(729) := '000080808000000080808080808101010adadadffffffffffff39'||wwv_flow.LF||
'3939101010181818181818848484e7e7e7949494d6d6d';
    wwv_flow_api.g_varchar2_table(730) := '65a5a5ae7e7e78c8c8c2929291818183131318c8c8cffffffffffff8484844242423939392121214242'||wwv_flow.LF||
'424242424242422';
    wwv_flow_api.g_varchar2_table(731) := '929294a4a4a4a4a524a4a4a292929636363ffffffffffffffffffffffffffffffc6c6c69c9c9cb5b5b5cec6c6cec6c6cecec';
    wwv_flow_api.g_varchar2_table(732) := 'ed6d6d6e7e7e7'||wwv_flow.LF||
'dededed6d6d6b5b5b55a5a5a524a4a4242426b6b6bc6c6c6fff7f7fffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(733) := 'fffffffffffffffffffffffffffffe7dee73129314a'||wwv_flow.LF||
'4a4a4a4a4a4a4a4a2921214a4a4a4242424a4242212121423939393';
    wwv_flow_api.g_varchar2_table(734) := '9394a4242ffffffffffffd6d6d63131311818183131313131319c9c9cf7f7f78c8c8cd6d6'||wwv_flow.LF||
'd6636363efefef63636318181';
    wwv_flow_api.g_varchar2_table(735) := '8212121080808dededeffffffffffff080808080808080808080808000000080808000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(736) := '000'||wwv_flow.LF||
'080808000000080808080808101010080808adadadffffffffffff39393918181810101052525284848473737394949';
    wwv_flow_api.g_varchar2_table(737) := '4ffffffadadad4a4a4adedede94949418'||wwv_flow.LF||
'1818313131848484ffffffffffff9494943939394242422121214242424242424';
    wwv_flow_api.g_varchar2_table(738) := 'a4a4a2929294a4a524a4a4a524a52292929525252949494ffffffffffffffff'||wwv_flow.LF||
'ffffffffc6c6c69494949c9c9c8c8c8c848';
    wwv_flow_api.g_varchar2_table(739) := '4846363638484847b73737b7b7b6363637373736363635252523939395a5a5a5a5a5a524a4a6363639494949c9c9c'||wwv_flow.LF||
'a5a5a';
    wwv_flow_api.g_varchar2_table(740) := '59c9c9ca5a5a59c9c9c8484848c84848c8c8c635a633131314a424a4a4a4a524a523129294a42424a4a4a4a4a4a212121424';
    wwv_flow_api.g_varchar2_table(741) := '242423939525252ffffffff'||wwv_flow.LF||
'ffffcecece3131312121212929296b6b6b8c8c8c5a5a5ab5b5b5ffffff8c8c8c4a4a4ae7e7e';
    wwv_flow_api.g_varchar2_table(742) := '76b6b6b181818101010e7e7e7ffffffffffff0808080808081010'||wwv_flow.LF||
'100808080808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(743) := '000000000000000000808080000000808080808081010108c8c8cffffffffffff525252101010181818'||wwv_flow.LF||
'212121313131181';
    wwv_flow_api.g_varchar2_table(744) := '818848484ffffffa5a5a52121212929294a4a4a212121292929737373ffffffffffffa5a5a53939393939392921214242424';
    wwv_flow_api.g_varchar2_table(745) := '2424242424229'||wwv_flow.LF||
'29294a424a4a4a4a4a4a4a2929294a4a4a4a4a4abdbdbdffffffffffffffffffcececeb5b5b5c6c6c6c6c';
    wwv_flow_api.g_varchar2_table(746) := '6c6c6c6c6c6bdbdc6c6c6cececec6c6c6c6c6c6b5ad'||wwv_flow.LF||
'ad5a52524a4a4a4242425a52525a5a5a4a4a4a4242425252525a5a5';
    wwv_flow_api.g_varchar2_table(747) := 'a4242424a4a4a5252524a4a4a3939394a4242524a4a524a523129314a4a4a4a4a4a4a4a4a'||wwv_flow.LF||
'2121214a4a4a4242424242422';
    wwv_flow_api.g_varchar2_table(748) := '92121424242393939636363ffffffffffffb5b5b5313131181818313131393939393939101010adadadffffff8c8c8c10101';
    wwv_flow_api.g_varchar2_table(749) := '021'||wwv_flow.LF||
'2121313131181818080808f7f7f7ffffffefefef0808081010100808080808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(750) := '000000000000000000808080808080808'||wwv_flow.LF||
'08080808101010080808848484ffffffffffff636363101010181818181818181';
    wwv_flow_api.g_varchar2_table(751) := '818181818313131e7e7e7424242292929292929313131181818313131525252'||wwv_flow.LF||
'ffffffffffffc6c6c639393942393921212';
    wwv_flow_api.g_varchar2_table(752) := '14242424242424a4a4a2929294a4a4a4a4a4a5252522929294a4a52524a5252525ac6c6c6fffffffffffff7f7f7d6'||wwv_flow.LF||
'd6d6d';
    wwv_flow_api.g_varchar2_table(753) := '6d6d6c6c6c6c6c6c6a5a5a5adadada5a5a59c94947b7b7b8484845a5a5a5252523939395a5a5a737373adadadcec6c6efefe';
    wwv_flow_api.g_varchar2_table(754) := 'ff7f7f7fffffff7f7f7ffff'||wwv_flow.LF||
'fff7f7f7f7f7f78c8c8c524a52524a523131314a424a524a4a4a4a4a2929294a4a4a4a4a4a4';
    wwv_flow_api.g_varchar2_table(755) := '24242292929423939423939847b7bffffffffffff9c9c9c313131'||wwv_flow.LF||
'1818182929292929292929291818184a4a4adedede313';
    wwv_flow_api.g_varchar2_table(756) := '131101010181818212121101010181818ffffffffffffcecece08080808080808080808080808080808'||wwv_flow.LF||
'080808080800000';
    wwv_flow_api.g_varchar2_table(757) := '0000000000000000000000000000000080808000000080808080808080808636363ffffffffffff848484101010181818181';
    wwv_flow_api.g_varchar2_table(758) := '8181010101818'||wwv_flow.LF||
'18212121212121181818181818313131292929181818292929393939f7f7f7ffffffe7e7e742393939393';
    wwv_flow_api.g_varchar2_table(759) := '92121214242424a42424242422929294a424a524a4a'||wwv_flow.LF||
'4a4a4a292929525252524a524a4a4a313131c6c6c6ffffffcec6c69';
    wwv_flow_api.g_varchar2_table(760) := '494948c84847b73736b6b6b5a5a5a8c84849494949c94949494949494945a5a5a52525239'||wwv_flow.LF||
'3939adadadfffffffffffffff';
    wwv_flow_api.g_varchar2_table(761) := 'fffffffffffffffffffffffffffffffffffffff8484844a4242524a52524a523131314a4a4a4a4a4a4a4a4a21212142424a4';
    wwv_flow_api.g_varchar2_table(762) := '242'||wwv_flow.LF||
'424a4242212121423939393939a5a5a5ffffffffffff7b7b7b313131181818313131292929292929101010292929212';
    wwv_flow_api.g_varchar2_table(763) := '121292929080808181818101010181818'||wwv_flow.LF||
'292929ffffffffffffbdbdbd08080808080808080808080800000008080800000';
    wwv_flow_api.g_varchar2_table(764) := '000000000000000000000000000000008080800000008080808080810101008'||wwv_flow.LF||
'08084a4a4affffffffffff9c9c9c1010101';
    wwv_flow_api.g_varchar2_table(765) := '81818181818181818212121212121212121181818292929292929313131181818313131313131e7e7e7ffffffffff'||wwv_flow.LF||
'ff4a4';
    wwv_flow_api.g_varchar2_table(766) := 'a4a4242422121214a42424242424a4a4a2921214a4a4a4a4a4a524a52292929525252525252525252292929525252a5a5a5f';
    wwv_flow_api.g_varchar2_table(767) := 'fffffffffffffffffffffff'||wwv_flow.LF||
'fff7f7d6d6d6c6bdbda5a5a5847b7b4a4a4a6b6363736b6b9c9c9cd6d6d6fffffffffffffff';
    wwv_flow_api.g_varchar2_table(768) := 'ffffffffffffffffffffffffffffffffff7f7f784848442393942'||wwv_flow.LF||
'42425252525252523129314242425252524a424229292';
    wwv_flow_api.g_varchar2_table(769) := '942424a4a4242424242292929393939423939d6ceceffffffffffff5252523131311818182929293131'||wwv_flow.LF||
'312121211010102';
    wwv_flow_api.g_varchar2_table(770) := '121212929292121211010101818182121211818184a4a4affffffffffffa5a5a508080808080810101008080808080808080';
    wwv_flow_api.g_varchar2_table(771) := '8080808000000'||wwv_flow.LF||
'000000000000000000000000000000080808000000080808080808080808212121ffffffffffffcecece1';
    wwv_flow_api.g_varchar2_table(772) := '0101018181818181810101010101021212121212118'||wwv_flow.LF||
'1818212121292929292929181818292929313131a5a5a5fffffffff';
    wwv_flow_api.g_varchar2_table(773) := 'fff7b7b7b3939392121214239394242424242422929294a42424a4a4a4a4a4a3129294a4a'||wwv_flow.LF||
'4a4a4a4a4a4a4a292929524a4';
    wwv_flow_api.g_varchar2_table(774) := 'a525252737373dededefffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(775) := 'fff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffcecece6363635252523131314a4242524a52524a4a2929294a4a4a4a424a4a4a4';
    wwv_flow_api.g_varchar2_table(776) := 'a21212142424a42424242424221212142'||wwv_flow.LF||
'4242424242fffffffffffff7f7f73131313131311818183131312121212929291';
    wwv_flow_api.g_varchar2_table(777) := '01010292929212121212121101010181818181818181818737373ffffffffff'||wwv_flow.LF||
'ff7b7b7b000000101010080808080808000';
    wwv_flow_api.g_varchar2_table(778) := '000080808000000000000000000000000000000000000080808000000080808080808101010080808101010efefef'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(779) := 'ff7f7f71818181818182121211010101818182121212929291818182121212929292929291818183131313131317b7b7bfff';
    wwv_flow_api.g_varchar2_table(780) := 'fffffffffb5b5b542424221'||wwv_flow.LF||
'21214242424242424a4a4a2921214a4a4a4a4a4a524a52292929524a5252525252525229292';
    wwv_flow_api.g_varchar2_table(781) := '95252525252525a5a5a312929949494e7e7e7ffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(782) := 'fffffffffffffffffffffffffffffd6d6d66b6b6b424242525252524a4a424242424242524a52524a4a'||wwv_flow.LF||
'3131314a424a524';
    wwv_flow_api.g_varchar2_table(783) := 'a524a4a4a2929294242424a42424239392929293939397b7373ffffffffffffbdbdbd3131313131311818182929293131312';
    wwv_flow_api.g_varchar2_table(784) := '1212118181821'||wwv_flow.LF||
'2121292929181818101010181818181818101010adadadffffffffffff525252080808101010080808080';
    wwv_flow_api.g_varchar2_table(785) := '8080808080000000808080000000000000000000000'||wwv_flow.LF||
'00000000000000080808000000080808080808080808080808cecec';
    wwv_flow_api.g_varchar2_table(786) := 'effffffffffff393939181818101010181818181818212121212121181818212121292929'||wwv_flow.LF||
'2929291818182929293131313';
    wwv_flow_api.g_varchar2_table(787) := '93939fffffffffffff7f7f73939392121213939424242424239422121214242424a4a4a4242422929314a4a4a524a524a4a4';
    wwv_flow_api.g_varchar2_table(788) := 'a29'||wwv_flow.LF||
'2929524a4a525252524a523129294a4a4a5a5a5a7b7b7badadadefefeffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(789) := 'fffffffffffffffffdededea5a5a56b6b'||wwv_flow.LF||
'6b5a525a3931314242425252525252523131314a424a4a4a4a524a4a2929294a4';
    wwv_flow_api.g_varchar2_table(790) := '24a4a4a4a4a424a2121214a4242393939424242212121393939adadadffffff'||wwv_flow.LF||
'ffffff7b7b7b31313131313110101029292';
    wwv_flow_api.g_varchar2_table(791) := '9292929292929101010212121212121212121080808212121181818181818d6d6d6ffffffffffff21212100000008'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(792) := '8080808080800000000000000000000000000000000000000000000000008080800000008080808080810101008080810101';
    wwv_flow_api.g_varchar2_table(793) := '0949494ffffffffffff7373'||wwv_flow.LF||
'731818182121211010101818182121212121211818182121212929292929291818183131313';
    wwv_flow_api.g_varchar2_table(794) := '13131313131bdbdbdffffffffffff7b7b7b181818424242423942'||wwv_flow.LF||
'4242422121214a4a4a4a4a4a4a4a4a2929295252524a4';
    wwv_flow_api.g_varchar2_table(795) := 'a4a525252292929525252524a525252522929295252525252525252523131315a52526b636384848484'||wwv_flow.LF||
'8484fff7f7fffff';
    wwv_flow_api.g_varchar2_table(796) := 'ff7f7f7848484847b7b635a5a4a4a4a3939395a525a524a52424242423942525252524a4a3939394242425252524a4a4a313';
    wwv_flow_api.g_varchar2_table(797) := '131424242524a'||wwv_flow.LF||
'4a4a42422929294242424a4a4a393939292929424242ffffffffffffffffff39393931313129292918181';
    wwv_flow_api.g_varchar2_table(798) := '8292929292929212121181818212121212121212121'||wwv_flow.LF||
'101010181818181818292929ffffffffffffe7e7e71010100808080';
    wwv_flow_api.g_varchar2_table(799) := '8080810101008080808080800000008080800000000000000000000000000000000000008'||wwv_flow.LF||
'0808000000080808080808080';
    wwv_flow_api.g_varchar2_table(800) := '808080808525252ffffffffffff9c9c9c1818181818181010101010102121212121211818181818182929292929291818182';
    wwv_flow_api.g_varchar2_table(801) := '929'||wwv_flow.LF||
'292929292929296b6b6bffffffffffffcecece2121213939394242424242422121293939394a424a4a4a4a2929294a4';
    wwv_flow_api.g_varchar2_table(802) := 'a4a4a4a4a4a4a4a2929294a4a4a525252'||wwv_flow.LF||
'524a52312931524a4a5252525252523131315252525a52524a4a4a313131e7e7e';
    wwv_flow_api.g_varchar2_table(803) := '7ffffffdedede3939395252525252524242423939394a4a4a52525239393942'||wwv_flow.LF||
'39424a4a4a524a523131314242424a4a4a4';
    wwv_flow_api.g_varchar2_table(804) := 'a4a4a2929294a42424242424a42422121214242423939394242421818188c8c8cffffffffffffadadad3131312929'||wwv_flow.LF||
'29292';
    wwv_flow_api.g_varchar2_table(805) := '929101010292929212121292929101010212121181818212121101010181818181818525252ffffffffffffadadad0808080';
    wwv_flow_api.g_varchar2_table(806) := '00000080808080808080808'||wwv_flow.LF||
'000000080808000000000000000000000000000000000000080808000000080808080808101';
    wwv_flow_api.g_varchar2_table(807) := '010080808101010212121ffffffffffffe7e7e718181818181810'||wwv_flow.LF||
'101018181821212121212118181821212121212129292';
    wwv_flow_api.g_varchar2_table(808) := '9181818313131292929313131212121e7e7e7ffffffffffff4a4a4a42424239393942424a1818214a4a'||wwv_flow.LF||
'4a4242424a4a4a2';
    wwv_flow_api.g_varchar2_table(809) := '92929524a4a4a4a4a525252292929525252524a4a525252292929525252524a4a5a525231292952525252525252525231313';
    wwv_flow_api.g_varchar2_table(810) := '16b6b6badadad'||wwv_flow.LF||
'6b6b6b3931315252525252524a4a4a3939395a525a525252423942393939525252524a4a3939394242425';
    wwv_flow_api.g_varchar2_table(811) := '24a524a4a4a3131314242424a4a4a42424229212942'||wwv_flow.LF||
'4242424242393939292929e7e7e7ffffffffffff525252313131313';
    wwv_flow_api.g_varchar2_table(812) := '1312929291818182929292929292121211818182121212121211818181010101818181818'||wwv_flow.LF||
'189c9c9cffffffffffff6b6b6';
    wwv_flow_api.g_varchar2_table(813) := 'b080808080808080808080808080808080808000000000000000000000000000000000000000000000000000000000000080';
    wwv_flow_api.g_varchar2_table(814) := '808'||wwv_flow.LF||
'080808080808000000101010c6c6c6ffffffffffff42424218181810101010101021212118181818181818181829292';
    wwv_flow_api.g_varchar2_table(815) := '921212118181821212131313129292921'||wwv_flow.LF||
'21218c8c8cffffffffffffc6c6c63931394242423939392121214242424242424';
    wwv_flow_api.g_varchar2_table(816) := '2424a2921294a424a4a4a4a4a4a4a2929294a4a4a524a524a4a4a2929294a4a'||wwv_flow.LF||
'4a525252524a52312931524a525a52524a4';
    wwv_flow_api.g_varchar2_table(817) := 'a4a2929295252525252524239423939394a4a4a525252424242393939524a52525252393139423939524a52524a52'||wwv_flow.LF||
'31313';
    wwv_flow_api.g_varchar2_table(818) := '14242424a4a4a4a4a4a2929294242424242424242422121214242423939393939397b7b7bffffffffffffd6d6d6101010313';
    wwv_flow_api.g_varchar2_table(819) := '13129292929292910101029'||wwv_flow.LF||
'2929212121292929101010212121181818212121080808181818101010dededefffffffffff';
    wwv_flow_api.g_varchar2_table(820) := 'f2929291010100000000808080808080808080000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(821) := '80808080808080808080808080808101010848484ffffffffffff8c8c8c181818101010181818212121'||wwv_flow.LF||
'212121101010212';
    wwv_flow_api.g_varchar2_table(822) := '121212121292929181818313131292929313131181818424242f7f7f7ffffffffffff7373733939393939422121214242424';
    wwv_flow_api.g_varchar2_table(823) := '2424242424229'||wwv_flow.LF||
'29294a4a4a4a4a4a524a52292129525252524a4a525252292929525252524a52525252292929525252525';
    wwv_flow_api.g_varchar2_table(824) := '2525252523131315a52524a4a4a5252523131315a52'||wwv_flow.LF||
'52525252424242393939525252524a524239423939395252524a4a4';
    wwv_flow_api.g_varchar2_table(825) := 'a393139424242524a524a4a4a3129314239424a4a4a424242292129423942424242424242'||wwv_flow.LF||
'efefefffffffffffff6b6b6b2';
    wwv_flow_api.g_varchar2_table(826) := '12121292929313131292929181818292929292929212121101010212121212121181818101010181818424242fffffffffff';
    wwv_flow_api.g_varchar2_table(827) := 'fce'||wwv_flow.LF||
'cece1010100808080808080808080808080000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(828) := '000000000000808080808080808080808'||wwv_flow.LF||
'08101010313131ffffffffffffdedede181818101010101010181818181818181';
    wwv_flow_api.g_varchar2_table(829) := '818181818212121212121181818292929292929292929181818313131848484'||wwv_flow.LF||
'ffffffffffffe7e7e742424239393921212';
    wwv_flow_api.g_varchar2_table(830) := '13939394242424242422921294242424a4a4a4a4a4a2929294a4a4a524a4a4a4a4a292929524a4a524a4a4a4a4a31'||wwv_flow.LF||
'29315';
    wwv_flow_api.g_varchar2_table(831) := '24a525252524a424a312931524a4a5252524a42423931394a4a4a525252423942393939524a4a524a523939393939394a4a4';
    wwv_flow_api.g_varchar2_table(832) := 'a524a4a3131314242424a42'||wwv_flow.LF||
'424a4a4a292929424242423942424242211821424242313131adadadffffffffffffc6c6c63';
    wwv_flow_api.g_varchar2_table(833) := '13131101010313131292929292929101010292929212121212121'||wwv_flow.LF||
'1010102121211818181818180808081818188c8c8cfff';
    wwv_flow_api.g_varchar2_table(834) := 'fffffffff84848408080810101000000008080808080800000000000008080800000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(835) := '0080808000000080808000000080808080808080808101010101010d6d6d6ffffffffffff525252101010181818181818212';
    wwv_flow_api.g_varchar2_table(836) := '1211010102121'||wwv_flow.LF||
'21212121292929181818292929292929313131181818313131313131dededeffffffffffffadadad39394';
    wwv_flow_api.g_varchar2_table(837) := '221212142424239393942424a2121294a4a4a4a424a'||wwv_flow.LF||
'524a4a292129524a4a4a4a4a5252522929295252524a4a4a5252522';
    wwv_flow_api.g_varchar2_table(838) := '92929525252524a4a524a523129315252524a4a4a4a4a4a313131525252524a524a424a39'||wwv_flow.LF||
'31395252524a4a4a423942423';
    wwv_flow_api.g_varchar2_table(839) := '942524a524a4a4a3939394239424a4a4a4a42422929294239394242424239422121214239396b6b6bffffffffffffffffff5';
    wwv_flow_api.g_varchar2_table(840) := '252'||wwv_flow.LF||
'52313131181818292929313131292929181818292929292929212121101010212121212121181818101010181818efe';
    wwv_flow_api.g_varchar2_table(841) := 'fefffffffffffff313131101010080808'||wwv_flow.LF||
'08080800000008080800000008080800000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(842) := '000000000000000000000000008080800000008080808080810101008080873'||wwv_flow.LF||
'7373ffffffffffffa5a5a51010101010101';
    wwv_flow_api.g_varchar2_table(843) := '81818181818101010181818212121212121181818212121292929292929181818292929313131525252ffffffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(844) := 'fff7373732121213939394242423939392121214242424a42424242422929294a4a4a524a4a4a4a4a3129294a4a4a524a524';
    wwv_flow_api.g_varchar2_table(845) := 'a4a4a3129294a4a4a525252'||wwv_flow.LF||
'4a424a3129314a4a4a524a524242423131314a4a4a5252524239423931394a4a4a525252393';
    wwv_flow_api.g_varchar2_table(846) := '9393939394a4a4a4a4a4a31313142424242424242424229212142'||wwv_flow.LF||
'4242423939423939212121524a4aefefeffffffffffff';
    wwv_flow_api.g_varchar2_table(847) := 'f9c9c9c3131313131311010103131312929292929291010102121212121212121211010101818181818'||wwv_flow.LF||
'181818180808085';
    wwv_flow_api.g_varchar2_table(848) := 'a5a5affffffffffffc6c6c610101008080808080800000008080800000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(849) := '0000000000000'||wwv_flow.LF||
'000000000000080808000000080808080808080808080808101010181818ffffffffffffffffff2929291';
    wwv_flow_api.g_varchar2_table(850) := '8181818181821212110101021212121212129292910'||wwv_flow.LF||
'1010292929292929292929181818393939292929313131848484fff';
    wwv_flow_api.g_varchar2_table(851) := 'fffffffffffffff4242424242423939394242422121214a42424242424a4a4a2921214a4a'||wwv_flow.LF||
'4a4a4a4a4a4a4a292929524a5';
    wwv_flow_api.g_varchar2_table(852) := '24a4a4a524a52292929524a52524a4a4a4a4a292929525252524a4a4a4a4a313131525252524a4a4242423931315252524a4';
    wwv_flow_api.g_varchar2_table(853) := 'a4a'||wwv_flow.LF||
'393939393939524a4a4a4a4a3131313939394a4a4a4a4a4a292929393939424242424242292929d6d6d6fffffffffff';
    wwv_flow_api.g_varchar2_table(854) := 'fcecece31313131313129292918181829'||wwv_flow.LF||
'29292929292929291818182121212929292121211010101818182121211818181';
    wwv_flow_api.g_varchar2_table(855) := '01010c6c6c6ffffffffffff6363631010101010100808080808080000000808'||wwv_flow.LF||
'08000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(856) := '000000000000000000000000000000000000000000000000000080808000000101010080808101010949494ffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(857) := 'f8c8c8c101010181818181818181818181818181818212121181818212121292929292929181818292929313131313131212';
    wwv_flow_api.g_varchar2_table(858) := '121bdbdbdffffffffffffef'||wwv_flow.LF||
'efef4a4a4a4242423939392121214239394242424242423129293939394a4a4a4a4a4a29292';
    wwv_flow_api.g_varchar2_table(859) := '94a424a4a4a4a4a4a4a3129294a424a524a4a4a424a3129314a4a'||wwv_flow.LF||
'4a524a4a4242423131314a4a4a4a4a4a4239393931394';
    wwv_flow_api.g_varchar2_table(860) := 'a4a4a4a4a4a3931313939394a42424a4a4a292929393939424242423939292929393939393131424242'||wwv_flow.LF||
'bdbdbdfffffffff';
    wwv_flow_api.g_varchar2_table(861) := 'fffefefef3131313131312929293131311010102929292121212929291010102121212121212121211010102121211818181';
    wwv_flow_api.g_varchar2_table(862) := '81818393939ff'||wwv_flow.LF||
'ffffffffffefefef101010080808080808080808000000080808000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(863) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000080808080808080808080808101010080808313131fffff';
    wwv_flow_api.g_varchar2_table(864) := 'fffffffffffff313131101010212121101010181818181818292929101010292929212121'||wwv_flow.LF||
'2929291010103131313131313';
    wwv_flow_api.g_varchar2_table(865) := '13131101010424242dededeffffffffffffefefef5252524242422121214242424239394242422121214a4a4a4242424a4a4';
    wwv_flow_api.g_varchar2_table(866) := 'a29'||wwv_flow.LF||
'29294a4a4a4a424a524a4a2929294a4a4a4a4a4a4a4a4a292929524a524a4a4a4a4a4a313131524a4a4a4a4a4242423';
    wwv_flow_api.g_varchar2_table(867) := '131314a4a4a4a4a4a3939393939394a4a'||wwv_flow.LF||
'4a4242423131313939394a4242424242292929393939424242bdbdbdfffffffff';
    wwv_flow_api.g_varchar2_table(868) := 'fffffffff636363212121313131313131292929181818292929292929212121'||wwv_flow.LF||
'18181821212121212118181810101018181';
    wwv_flow_api.g_varchar2_table(869) := '8212121101010bdbdbdffffffffffff84848408080808080810101008080808080800000008080800000008080800'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(870) := '0000000000000000000000000000000000000000000000000000000000000000008080800000010101008080808080808080';
    wwv_flow_api.g_varchar2_table(871) := '8b5b5b5ffffffffffff8c8c'||wwv_flow.LF||
'8c1818181010101010101818182121211818181010102121212929292121211818182929292';
    wwv_flow_api.g_varchar2_table(872) := '92929292929181818313131424242e7e7e7ffffffffffffefefef'||wwv_flow.LF||
'5a5a5a2121213939394242424239392121214242424a4';
    wwv_flow_api.g_varchar2_table(873) := 'a4a4239392921214242424a4a4a4242422929294a42424a4a4a4242422929294a4a4a4a4a4a42424231'||wwv_flow.LF||
'31314a4a4a4a4a4';
    wwv_flow_api.g_varchar2_table(874) := 'a3939393931314242424a4a4a313131313131424242424242292929393939393131424242212121424242cec6c6fffffffff';
    wwv_flow_api.g_varchar2_table(875) := 'fffffffff7373'||wwv_flow.LF||
'7331313118181831313129292931313110101029292921212129292910101021212121212121212108080';
    wwv_flow_api.g_varchar2_table(876) := '81818181010104a4a4affffffffffffefefef181818'||wwv_flow.LF||
'0000001010100808080808080000000808080000000000000000000';
    wwv_flow_api.g_varchar2_table(877) := '0000000000000000000000000000000000000000000000000000000000000000008080800'||wwv_flow.LF||
'0000080808080808101010080';
    wwv_flow_api.g_varchar2_table(878) := '808101010313131ffffffffffffffffff3131311818181010101818181818182121211010102121212121212929291010102';
    wwv_flow_api.g_varchar2_table(879) := '929'||wwv_flow.LF||
'292929293131311818183131313131314a4a4ae7e7e7ffffffffffffffffff6b6b6b423939423939424242212121424';
    wwv_flow_api.g_varchar2_table(880) := '2424242424a4a4a2921214a4a4a424242'||wwv_flow.LF||
'4a4a4a2921214a4a4a4a42424a4a4a2929294a4a4a4a42424242423129294a4a4';
    wwv_flow_api.g_varchar2_table(881) := 'a4a42424239393131314a4a4a4242423931313131314a424242424229292931'||wwv_flow.LF||
'31314a42423939394a4242dededefffffff';
    wwv_flow_api.g_varchar2_table(882) := 'fffffffffff7b73733131313131312121212929293131312929291010102929292929292121211010102121212121'||wwv_flow.LF||
'21181';
    wwv_flow_api.g_varchar2_table(883) := '818101010181818181818cececeffffffffffff8484841010100808080808080808080808080808080000000808080000000';
    wwv_flow_api.g_varchar2_table(884) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000080808000000080808080';
    wwv_flow_api.g_varchar2_table(885) := '808080808000000080808a5a5a5ffffffffffffb5b5b518181810'||wwv_flow.LF||
'101010101021212118181818181818181821212121212';
    wwv_flow_api.g_varchar2_table(886) := '1181818292929292929212121212121292929313131292929313131d6d6d6ffffffffffffffffffadad'||wwv_flow.LF||
'ad4242423939392';
    wwv_flow_api.g_varchar2_table(887) := '121214239394242424239392121214239394242424242422929294242424242424242422929294242424a424239393931292';
    wwv_flow_api.g_varchar2_table(888) := '9424242424242'||wwv_flow.LF||
'393131313131423939424242313131393131424242424242292121393939393939847b7bfff7f7fffffff';
    wwv_flow_api.g_varchar2_table(889) := 'fffffffffff5a5a5a39313129292931313110101031'||wwv_flow.LF||
'3131292929292929101010292929212121212121101010212121181';
    wwv_flow_api.g_varchar2_table(890) := '818181818080808212121636363ffffffffffffe7e7e71818181010100000001010100000'||wwv_flow.LF||
'0008080800000000000000000';
    wwv_flow_api.g_varchar2_table(891) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000080808000000080808080';
    wwv_flow_api.g_varchar2_table(892) := '808'||wwv_flow.LF||
'101010080808080808101010212121f7f7f7ffffffffffff63636310101018181818181821212110101021212118181';
    wwv_flow_api.g_varchar2_table(893) := '829292918181829292929292931313110'||wwv_flow.LF||
'1010313131313131313131181818393939bdbdbdffffffffffffffffffe7e7e77';
    wwv_flow_api.g_varchar2_table(894) := 'b73732121214239394239394242422121214242424242424a42422121214a42'||wwv_flow.LF||
'424242424242422921214a4242424242424';
    wwv_flow_api.g_varchar2_table(895) := '2422929294a42424242423939393131314a42424242423131313131314242423939393131314a4a4acececeffffff'||wwv_flow.LF||
'fffff';
    wwv_flow_api.g_varchar2_table(896) := 'fffffffefefef5a5a5a212121313131313131292929181818292929292929292929181818212121212121212121101010181';
    wwv_flow_api.g_varchar2_table(897) := '81821212118181810101021'||wwv_flow.LF||
'2121efefefffffffffffff63636310101008080808080808080808080800000008080800000';
    wwv_flow_api.g_varchar2_table(898) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(899) := '00000080808000000080808000000080808101010737373ffffffffffffe7e7e7212121101010181818'||wwv_flow.LF||
'181818101010181';
    wwv_flow_api.g_varchar2_table(900) := '8182121212121211010102121212929292121211818182929293131312929291818183131313131318c8c8cfffffffffffff';
    wwv_flow_api.g_varchar2_table(901) := 'fffffffffffc6'||wwv_flow.LF||
'c6c66363633939393939392121213939394242424239392121214242424a4242393939292929424242424';
    wwv_flow_api.g_varchar2_table(902) := '2423931313129294242424242423131313131313939'||wwv_flow.LF||
'39393939292929313131393939525252a5a5a5fffffffffffffffff';
    wwv_flow_api.g_varchar2_table(903) := 'fffffffc6c6c6424242313131181818313131292929292929101010292929212121292929'||wwv_flow.LF||
'1010102929292121212121210';
    wwv_flow_api.g_varchar2_table(904) := '80808181818181818181818080808adadadffffffffffffbdbdbd10101008080810101000000008080800000008080800000';
    wwv_flow_api.g_varchar2_table(905) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(906) := '000000808080808080808080808080808'||wwv_flow.LF||
'08101010101010101010cececeffffffffffffadadad181818181818181818101';
    wwv_flow_api.g_varchar2_table(907) := '010212121212121292929101010292929292929212121101010292929313131'||wwv_flow.LF||
'313131181818424242dedede73737342424';
    wwv_flow_api.g_varchar2_table(908) := '2d6d6d6ffffffffffffffffffffffffcecece7b7b7b21212142424239393942393921212142393942393942424221'||wwv_flow.LF||
'21214';
    wwv_flow_api.g_varchar2_table(909) := '24242424242393939292929423939423939393131292929424242393939313131525252b5b5b5fffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(910) := 'fefefef7373732929293131'||wwv_flow.LF||
'313131312121213131313131312929291818182929292929292121211010101818182121212';
    wwv_flow_api.g_varchar2_table(911) := '12121101010181818181818181818636363fffffffffffff7f7f7'||wwv_flow.LF||
'313131101010101010080808080808080808080808000';
    wwv_flow_api.g_varchar2_table(912) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(913) := '0000000000000000000080808000000080808000000080808080808080808313131f7f7f7ffffffffffff6b6b6b181818181';
    wwv_flow_api.g_varchar2_table(914) := '8180808081818'||wwv_flow.LF||
'181818182121211010102121212121212121211818182929292929292929291818189c9c9cffffff6b6b6';
    wwv_flow_api.g_varchar2_table(915) := 'b393939636363848484e7e7e7ffffffffffffffffff'||wwv_flow.LF||
'fffffff7f7f7b5b5b57b7b7b4a4a4a2921213931313939393931312';
    wwv_flow_api.g_varchar2_table(916) := '92121393939393939393939292929393939424242313131313131636363a5a5a5dededeff'||wwv_flow.LF||
'fffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(917) := 'fffa5a5a56b6b6bcececeffffffc6c6c64242421010102929292929292929291010102929292121212121211010102121211';
    wwv_flow_api.g_varchar2_table(918) := '818'||wwv_flow.LF||
'18181818101010181818181818313131efefefffffffffffff7b7b7b000000101010080808080808000000080808000';
    wwv_flow_api.g_varchar2_table(919) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(920) := '000000000000000000000000000000008080800000008080808080808080808'||wwv_flow.LF||
'08080808086b6b6bffffffffffffffffff4';
    wwv_flow_api.g_varchar2_table(921) := '24242181818101010181818212121212121080808212121212121292929101010292929212121313131393939ffff'||wwv_flow.LF||
'ffd6d';
    wwv_flow_api.g_varchar2_table(922) := '6d6393939d6d6d6ffffff7b7b7b393939848484efefefffffffffffffffffffffffffffffffffffffe7e7e7cec6c6a59c9c9';
    wwv_flow_api.g_varchar2_table(923) := '49494736b6b7b7b7b7b7373'||wwv_flow.LF||
'7b7b7b7b7b7ba5a5a5b5b5b5dededefffffffffffffffffffffffffffffffffffff7f7f7ada';
    wwv_flow_api.g_varchar2_table(924) := 'dad4242425a5a5affffffffffffe7e7e7ffffffd6d6d621212129'||wwv_flow.LF||
'292929292921212118181821212129292921212118181';
    wwv_flow_api.g_varchar2_table(925) := '8181818212121181818101010181818212121d6d6d6ffffffffffffc6c6c60808080808080808081010'||wwv_flow.LF||
'100000000808080';
    wwv_flow_api.g_varchar2_table(926) := '0000008080800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(927) := '0000000000000'||wwv_flow.LF||
'000000000000000000000000000000080808080808101010080808080808080808101010a5a5a5fffffff';
    wwv_flow_api.g_varchar2_table(928) := 'fffffefefef29292908080810101018181818181810'||wwv_flow.LF||
'1010181818212121181818101010212121292929212121c6c6c6fff';
    wwv_flow_api.g_varchar2_table(929) := 'fff5a5a5ab5b5b5ffffffffffff4a4a4aa5a5a59c9c9c393939737373bdbdbdffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(930) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffdedede848484424';
    wwv_flow_api.g_varchar2_table(931) := '242'||wwv_flow.LF||
'212121292929949494ffffff848484292929bdbdbdffffff73737321212121212129292910101021212121212121212';
    wwv_flow_api.g_varchar2_table(932) := '108080818181818181821212108080818'||wwv_flow.LF||
'1818adadadffffffffffffefefef2121211010100808080808080808080808080';
    wwv_flow_api.g_varchar2_table(933) := '000000808080000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(934) := '000000000000000000000000000000000080808000000000000080808080808000000080808080808101010101010'||wwv_flow.LF||
'18181';
    wwv_flow_api.g_varchar2_table(935) := '8d6d6d6ffffffffffffd6d6d6181818181818181818181818101010212121181818292929101010292929212121636363fff';
    wwv_flow_api.g_varchar2_table(936) := 'fffb5b5b5949494ffffffff'||wwv_flow.LF||
'ffffcecece525252ffffffe7e7e7393939313131313131292929737373adadaddededefffff';
    wwv_flow_api.g_varchar2_table(937) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffe7e7e7bdbdbd8484844242422121213';
    wwv_flow_api.g_varchar2_table(938) := '93939313131212121292929848484ffffffadadad2929294a4a4afffffff7f7f7393939292929212121'||wwv_flow.LF||
'181818181818212';
    wwv_flow_api.g_varchar2_table(939) := '121212121101010212121181818181818101010949494ffffffffffffffffff4242421010101010100808080808080808080';
    wwv_flow_api.g_varchar2_table(940) := '8080808080800'||wwv_flow.LF||
'0000080808000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(941) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0008080800000000000000000008080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(942) := '8101010292929efefefffffffffffffc6c6c6181818181818181818101010181818181818'||wwv_flow.LF||
'212121101010212121292929d';
    wwv_flow_api.g_varchar2_table(943) := '6d6d6ffffff7b7b7bffffffcececeffffff6b6b6bcececeffffff63636329292931313131313118181831313152525284848';
    wwv_flow_api.g_varchar2_table(944) := '463'||wwv_flow.LF||
'63636b6b6b6b6b6b8c8c8c8c8c8c9494949c9c9c9494948484847373736b6b6b3939392121217b7b7bcecece6b6b6b2';
    wwv_flow_api.g_varchar2_table(945) := '121212929293131311818182929293131'||wwv_flow.LF||
'31f7f7f7ffffff5a5a5a212121949494ffffffadadad212121181818101010212';
    wwv_flow_api.g_varchar2_table(946) := '121181818212121080808181818101010181818848484ffffffffffffffffff'||wwv_flow.LF||
'63636310101008080810101000000008080';
    wwv_flow_api.g_varchar2_table(947) := '808080808080800000008080800000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(948) := '0000000000000000000000000000000000000000000000000000000000000000000000008080800000008080808080808080';
    wwv_flow_api.g_varchar2_table(949) := '80808081010100808084242'||wwv_flow.LF||
'42f7f7f7ffffffffffffc6c6c62121211818181010102121211818182121211010102121217';
    wwv_flow_api.g_varchar2_table(950) := 'b7b7bffffffb5b5b5f7f7f7dedede9c9c9cf7f7f7737373ffffff'||wwv_flow.LF||
'cecece181818292929292929313131181818313131848';
    wwv_flow_api.g_varchar2_table(951) := '484fffffffffffffffffff7f7f7bdbdbd181818313131313131313131212121949494ffffff52525221'||wwv_flow.LF||
'2121c6c6c6fffff';
    wwv_flow_api.g_varchar2_table(952) := 'fa5a5a52121213131312929292121212121213131317b7b7bffffffdedede292929292929e7e7e7ffffff525252212121101';
    wwv_flow_api.g_varchar2_table(953) := '0101818182121'||wwv_flow.LF||
'211818181010101818181818187b7b7bffffffffffffffffff84848408080808080810101008080808080';
    wwv_flow_api.g_varchar2_table(954) := '8080808080808000000080808000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(955) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000080808000000080';
    wwv_flow_api.g_varchar2_table(956) := '808080808080808080808080808080808525252f7f7f7ffffffffffffc6c6c62121211010101010101818181818181010102';
    wwv_flow_api.g_varchar2_table(957) := '929'||wwv_flow.LF||
'29f7f7f7f7f7f7e7e7e7efefef424242dededea5a5a5dededeffffff4a4a4a181818292929313131212121181818292';
    wwv_flow_api.g_varchar2_table(958) := '929a5a5a5ffffffb5b5b5adadadd6d6d6'||wwv_flow.LF||
'a5a5a5181818292929313131212121212121737373ffffff737373212121cecec';
    wwv_flow_api.g_varchar2_table(959) := 'effffffc6c6c6212121292929292929181818292929212121292929cececeff'||wwv_flow.LF||
'ffff7b7b7b2121215a5a5affffffcecece2';
    wwv_flow_api.g_varchar2_table(960) := '12121080808181818181818181818080808181818848484ffffffffffffffffff8c8c8c1010100808080808080808'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(961) := '8080000000808080000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(962) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000080808000000080';
    wwv_flow_api.g_varchar2_table(963) := '808000000080808080808080808000000101010080808525252f7'||wwv_flow.LF||
'f7f7ffffffffffffdedede21212118181818181818181';
    wwv_flow_api.g_varchar2_table(964) := '81010109c9c9cffffffffffffffffff5a5a5a5a5a5affffffa5a5a5ffffffadadad2929291818182929'||wwv_flow.LF||
'292929293131311';
    wwv_flow_api.g_varchar2_table(965) := '01010292929cececeffffff424242313131292929292929181818313131292929313131181818525252ffffff9c9c9c21212';
    wwv_flow_api.g_varchar2_table(966) := '1e7e7e7ffffff'||wwv_flow.LF||
'ffffff2121212929292929291818182121212929292929294a4a4affffffffffff313131181818bdbdbdf';
    wwv_flow_api.g_varchar2_table(967) := 'fffff7b7b7b1010101818182121211010101818189c'||wwv_flow.LF||
'9c9cffffffffffffffffff949494101010080808080808101010101';
    wwv_flow_api.g_varchar2_table(968) := '0100808080808080000000808080000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(969) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(970) := '000'||wwv_flow.LF||
'0000000808080000000808080808080808080808081010101010104a4a4af7f7f7ffffffffffffefefef42424218181';
    wwv_flow_api.g_varchar2_table(971) := '8181818393939ffffffffffffffffff7b'||wwv_flow.LF||
'7b7b181818b5b5b5e7e7e7f7f7f7f7f7f73939392121211818182121212929292';
    wwv_flow_api.g_varchar2_table(972) := '12121181818292929e7e7e7ffffff2929292121212929292929291818182929'||wwv_flow.LF||
'29292929292929181818292929f7f7f7cec';
    wwv_flow_api.g_varchar2_table(973) := 'ece212121efefefffffffffffff424242212121292929181818212121212121212121181818a5a5a5ffffffadadad'||wwv_flow.LF||
'08080';
    wwv_flow_api.g_varchar2_table(974) := '8393939ffffffefefef181818181818101010212121bdbdbdffffffffffffffffff848484101010080808101010080808080';
    wwv_flow_api.g_varchar2_table(975) := '80808080808080800000008'||wwv_flow.LF||
'080800000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(976) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(977) := '00000000000080808000000080808000000080808000000080808080808101010080808393939efefef'||wwv_flow.LF||
'fffffffffffffff';
    wwv_flow_api.g_varchar2_table(978) := 'fff7b7b7b181818636363ffffffffffffb5b5b5101010313131ffffffffffffffffff8c8c8c1818182929291010102929292';
    wwv_flow_api.g_varchar2_table(979) := '9292929292910'||wwv_flow.LF||
'1010313131ffffffefefef181818292929212121292929101010292929212121292929181818292929d6d';
    wwv_flow_api.g_varchar2_table(980) := '6d6f7f7f7212121ffffffefefefffffff7373732929'||wwv_flow.LF||
'29212121181818212121212121212121181818292929f7f7f7fffff';
    wwv_flow_api.g_varchar2_table(981) := 'f424242212121949494ffffff6363631818184a4a4ae7e7e7ffffffffffffffffff737373'||wwv_flow.LF||
'1010101010101010100808080';
    wwv_flow_api.g_varchar2_table(982) := '8080808080808080800000008080800000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(983) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(984) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000080808080808080808101010080808080808080808292929cececefff';
    wwv_flow_api.g_varchar2_table(985) := 'fffffffffffffffb5b5b52929293131319494941818181010107b7b7bffffff'||wwv_flow.LF||
'ffffffe7e7e721212129292918181818181';
    wwv_flow_api.g_varchar2_table(986) := '82121212121212121211010104a4a4affffffffffffffffffd6d6d65a5a5a21212118181821212129292921212118'||wwv_flow.LF||
'18182';
    wwv_flow_api.g_varchar2_table(987) := '12121adadadffffff4a4a4affffffb5b5b5ffffff9c9c9c21212129292910101021212121212121212110101018181884848';
    wwv_flow_api.g_varchar2_table(988) := '4ffffffcecece1818182121'||wwv_flow.LF||
'214a4a4a1010107b7b7bfffffffffffffffffff7f7f75252521010100000000808080808080';
    wwv_flow_api.g_varchar2_table(989) := '80808000000080808000000080808000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(990) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(991) := '0000000000000000000000000000000000000000000080808080808000000080808080808080808080808101010101010181';
    wwv_flow_api.g_varchar2_table(992) := '818a5a5a5ffff'||wwv_flow.LF||
'ffffffffffffffefefef636363181818181818080808dededeffffffffffff63636321212118181821212';
    wwv_flow_api.g_varchar2_table(993) := '1101010292929212121292929101010737373ffffff'||wwv_flow.LF||
'dededec6c6c6f7f7f75252522929291010102929292929292121211';
    wwv_flow_api.g_varchar2_table(994) := '818182929297b7b7bffffff8c8c8cffffff737373ffffffc6c6c621212121212118181818'||wwv_flow.LF||
'1818212121212121101010181';
    wwv_flow_api.g_varchar2_table(995) := '818181818d6d6d6f7f7f7313131181818393939cececeffffffffffffffffffd6d6d63131311010101010100808080808080';
    wwv_flow_api.g_varchar2_table(996) := '808'||wwv_flow.LF||
'08080808000000000000080808000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(997) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(998) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000808080808080808080808081';
    wwv_flow_api.g_varchar2_table(999) := '01010080808080808636363f7f7f7ffffffffffffffffffc6c6c6393939101010636363e7e7e7c6c6c61010101818'||wwv_flow.LF||
'18212';
    wwv_flow_api.g_varchar2_table(1000) := '1211818181010101818182121211818181010108c8c8cffffff8484841818182121212121211818181818182121212121211';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(1001) := '81818181818212121525252'||wwv_flow.LF||
'ffffffcececeffffff5a5a5ad6d6d6efefef212121212121101010181818181818212121101';
    wwv_flow_api.g_varchar2_table(1002) := '0101818181818183939391818182929298c8c8cffffffffffffff'||wwv_flow.LF||
'ffffffffffa5a5a508080810101008080810101000000';
    wwv_flow_api.g_varchar2_table(1003) := '01010100808080808080000000808080000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1004) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1005) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000808080000000808080000000';
    wwv_flow_api.g_varchar2_table(1006) := '80808080808080808080808101010292929c6c6c6ff'||wwv_flow.LF||
'ffffffffffffffffffffffa5a5a5313131181818393939101010181';
    wwv_flow_api.g_varchar2_table(1007) := '818181818212121101010181818181818212121101010b5b5b5ffffff6363631010102121'||wwv_flow.LF||
'2121212121212110101021212';
    wwv_flow_api.g_varchar2_table(1008) := '1212121212121181818212121292929ffffffffffffffffff525252adadadffffff313131181818101010181818212121181';
    wwv_flow_api.g_varchar2_table(1009) := '818'||wwv_flow.LF||
'1818181010101818181818187b7b7befefefffffffffffffffffffe7e7e75a5a5a08080810101008080810101008080';
    wwv_flow_api.g_varchar2_table(1010) := '808080808080808080800000008080800'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1011) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1012) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1013) := '0080808080808080808080808080808080808080808080808636363efefefffffffffffffffffffffffffa5a5a5313131101';
    wwv_flow_api.g_varchar2_table(1014) := '01018181818181818181810'||wwv_flow.LF||
'1010181818212121181818101010cececeffffff39393910101018181818181818181810101';
    wwv_flow_api.g_varchar2_table(1015) := '0181818181818181818101010181818212121d6d6d6ffffffffff'||wwv_flow.LF||
'ff3939397b7b7bffffff5a5a5a2121211010101818181';
    wwv_flow_api.g_varchar2_table(1016) := '818181818181010101818187b7b7befefefffffffffffffffffffffffff949494181818101010101010'||wwv_flow.LF||
'000000080808080';
    wwv_flow_api.g_varchar2_table(1017) := '8080808080000000808080000000808080000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1018) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1019) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000008080800000';
    wwv_flow_api.g_varchar2_table(1020) := '0080808000000080808080808080808000000080808101010101010080808212121949494'||wwv_flow.LF||
'fffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1021) := 'fffffb5b5b5636363181818181818101010181818181818212121080808f7f7f7ffffffffffffdededebdbdbd42424218181';
    wwv_flow_api.g_varchar2_table(1022) := '810'||wwv_flow.LF||
'1010212121181818181818101010212121181818b5b5b5ffffffffffff292929525252ffffff8484841818181010101';
    wwv_flow_api.g_varchar2_table(1023) := '818181818183939399c9c9cf7f7f7ffff'||wwv_flow.LF||
'ffffffffffffffffffffc6c6c6313131101010080808101010080808080808080';
    wwv_flow_api.g_varchar2_table(1024) := '808101010080808080808000000080808000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1025) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1026) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1027) := '00000000000000000000000'||wwv_flow.LF||
'000808080000000808080808080808081010100808080808081010102929299c9c9cf7f7f7f';
    wwv_flow_api.g_varchar2_table(1028) := 'ffffffffffffffffffffffff7f7f79c9c9c4a4a4a181818181818'||wwv_flow.LF||
'1010101818187b7b7ba5a5a5c6c6c6f7f7f7ffffff393';
    wwv_flow_api.g_varchar2_table(1029) := '939181818101010101010181818181818101010101010212121848484dededea5a5a518181818181829'||wwv_flow.LF||
'292918181818181';
    wwv_flow_api.g_varchar2_table(1030) := '8313131848484d6d6d6ffffffffffffffffffffffffffffffc6c6c64a4a4a080808101010080808080808080808080808000';
    wwv_flow_api.g_varchar2_table(1031) := '0000808080000'||wwv_flow.LF||
'0008080800000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1032) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1033) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1034) := '0000000000000000000000000000808080808080808080000000808080808080808080808081010100808081010100808082';
    wwv_flow_api.g_varchar2_table(1035) := '929'||wwv_flow.LF||
'298c8c8cefefefffffffffffffffffffffffffffffffffffffb5b5b5848484424242212121101010181818080808212';
    wwv_flow_api.g_varchar2_table(1036) := '121181818181818101010181818101010'||wwv_flow.LF||
'181818101010181818181818181818101010181818181818393939636363a5a5a';
    wwv_flow_api.g_varchar2_table(1037) := '5e7e7e7ffffffffffffffffffffffffffffffffffffb5b5b542424208080810'||wwv_flow.LF||
'10101010100808080808080808081010100';
    wwv_flow_api.g_varchar2_table(1038) := '000000808080808080808080000000808080000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1039) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1040) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1041) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000008080810101008080808080800000010101000000';
    wwv_flow_api.g_varchar2_table(1042) := '00808080808081010101010105a5a5ab5b5b5ffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffdededeadadad9';
    wwv_flow_api.g_varchar2_table(1043) := 'c9c9c7373736363635252524242424242424242424242425252525a5a5a737373848484a5a5a5cececef7f7f7fffffffffff';
    wwv_flow_api.g_varchar2_table(1044) := 'fffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffdedede7b7b7b2929290808081010100808080808080808081010100808080808080';
    wwv_flow_api.g_varchar2_table(1045) := '0000008080800000008080800000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1046) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1047) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1048) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000008080800000008080800000008080800000008080800000010101008080';
    wwv_flow_api.g_varchar2_table(1049) := '810101000000010101008080810101008'||wwv_flow.LF||
'0808101010212121737373b5b5b5fffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1050) := 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'fffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1051) := 'fffffffffffffffffffffcecece848484393939101010080808080808101010080808080808080808101010080808'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1052) := '0000000101010080808000000000000080808000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1053) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1054) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1055) := '00000000000000000000000000000000000000000000000000000000000000000000000000000080808'||wwv_flow.LF||
'000000080808000';
    wwv_flow_api.g_varchar2_table(1056) := '0000808080808080808080808080808080808080808080808080808080808080808081010104a4a4a7b7b7bb5b5b5dededef';
    wwv_flow_api.g_varchar2_table(1057) := 'fffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffefe';
    wwv_flow_api.g_varchar2_table(1058) := 'fefbdbdbd9494945252522121210808081010100808'||wwv_flow.LF||
'0810101000000008080808080808080800000008080808080808080';
    wwv_flow_api.g_varchar2_table(1059) := '8000000080808000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1060) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1061) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1062) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1063) := '000080808000000080808080808080808080808101010080808101010080808'||wwv_flow.LF||
'10101000000010101008080810101008080';
    wwv_flow_api.g_varchar2_table(1064) := '81010101010103939395252527373738484849c9c9c9c9c9ca5a5a5a5a5a5a5a5a59c9c9c8c8c8c73737363636342'||wwv_flow.LF||
'42422';
    wwv_flow_api.g_varchar2_table(1065) := '1212110101010101008080810101010101008080808080810101008080808080808080808080808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1066) := '80808080808080808080808'||wwv_flow.LF||
'080000000808080000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1067) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1068) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1069) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1070) := '0000000000000'||wwv_flow.LF||
'0008080800000008080800000008080800000008080808080808080808080808080808080810101008080';
    wwv_flow_api.g_varchar2_table(1071) := '8080808080808101010080808080808080808101010'||wwv_flow.LF||
'0808080808080808081010100808080808080808081010100808080';
    wwv_flow_api.g_varchar2_table(1072) := '8080808080810101008080808080808080808080808080808080808080808080800000008'||wwv_flow.LF||
'0808080808080808000000080';
    wwv_flow_api.g_varchar2_table(1073) := '8080000000808080000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1074) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1075) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1076) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1077) := '000000000000000000808080000000808080000000808080808080808080000000808080808080808080000001010'||wwv_flow.LF||
'10080';
    wwv_flow_api.g_varchar2_table(1078) := '8081010100808081010100808081010100808081010100808081010100808081010100808081010100808081010100808081';
    wwv_flow_api.g_varchar2_table(1079) := '01010080808101010080808'||wwv_flow.LF||
'080808080808101010080808080808080808101010080808080808000000080808000000080';
    wwv_flow_api.g_varchar2_table(1080) := '80800000008080800000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1081) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1082) := '0000008080800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1083) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1084) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000080808000000080808000';
    wwv_flow_api.g_varchar2_table(1085) := '0000808080808080808080808080808080808080808080808080808080808080808080808'||wwv_flow.LF||
'0808080808080808080808080';
    wwv_flow_api.g_varchar2_table(1086) := '8080808080808080808080808080808000000080808080808080808000000080808000000080808000000080808000000000';
    wwv_flow_api.g_varchar2_table(1087) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1088) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1089) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1090) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1091) := '0000000000000000000000000000000000000000000000000000000000000000000080808000000080808000000080808000';
    wwv_flow_api.g_varchar2_table(1092) := '00008080808080808080800'||wwv_flow.LF||
'000008080808080808080800000008080808080808080800000008080808080808080808080';
    wwv_flow_api.g_varchar2_table(1093) := '80808080808080808080808080808080808080808080000000808'||wwv_flow.LF||
'080000000808080000000808080000000808080000000';
    wwv_flow_api.g_varchar2_table(1094) := '80808000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1095) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1096) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1097) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1098) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1099) := '0000000000000000008080800000000000000000008080800000000000008080808080800000008080800000008080800000';
    wwv_flow_api.g_varchar2_table(1100) := '008'||wwv_flow.LF||
'08080000000808080000000808080000000808080000000000000000000808080000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1101) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1102) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1103) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1104) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1105) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000808080';
    wwv_flow_api.g_varchar2_table(1106) := '00000080808000000080808000000080808000000080808000000'||wwv_flow.LF||
'080808000000080808000000080808000000080808080';
    wwv_flow_api.g_varchar2_table(1107) := '80808080800000008080808080808080800000008080800000008080800000008080800000000000000'||wwv_flow.LF||
'000000000000000';
    wwv_flow_api.g_varchar2_table(1108) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1109) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1110) := '0000000000000000000000000000000080808000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1111) := '0000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1112) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1113) := '000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1114) := '000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1115) := '000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1116) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'00000';
    wwv_flow_api.g_varchar2_table(1117) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1118) := '00000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1119) := '00000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1120) := '00000000000000000000808080000000000000000000808080000000000000000000808080000000808'||wwv_flow.LF||
'080000000808080';
    wwv_flow_api.g_varchar2_table(1121) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1122) := '0000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1123) := '0000000000000000000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1124) := '000000000000000000000000000000000000000000000000000080808212121000000040000002701ffff030000000000}\p';
    wwv_flow_api.g_varchar2_table(1125) := 'ar}}}{\rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \b\fs18\insrsid8735851               \tab \tab }'||wwv_flow.LF||
'{\field{\';
    wwv_flow_api.g_varchar2_table(1126) := '*\fldinst {\rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \b\fs18\insrsid8735851\charrsid6776828  DATE \\@ "MMMM';
    wwv_flow_api.g_varchar2_table(1127) := ' d, yyyy" }}{\fldrslt {\rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \b\fs18\lang1024\langfe1024\noproof\insrsi';
    wwv_flow_api.g_varchar2_table(1128) := 'd15281513 September 18, 2021}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectdefaultcl\sftnbj {\rtlch\fcs1 \';
    wwv_flow_api.g_varchar2_table(1129) := 'af0\afs32 \ltrch\fcs0 \b\fs32\insrsid8735851 '||wwv_flow.LF||
'\par }\pard \ltrpar\s16\qc \li0\ri0\widctlpar\tqc\tx4';
    wwv_flow_api.g_varchar2_table(1130) := '680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8735851 {\rtlc';
    wwv_flow_api.g_varchar2_table(1131) := 'h\fcs1 \af0\afs32 \ltrch\fcs0 \b\fs32\insrsid8735851\charrsid14755898 Restaurant Management System'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1132) := '\par }\pard \ltrpar\s16\qc \li0\ri0\sl480\slmult1\widctlpar\tqc\tx4680\tqr\tx9360\wrapdefault\aspalp';
    wwv_flow_api.g_varchar2_table(1133) := 'ha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid852486 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs2';
    wwv_flow_api.g_varchar2_table(1134) := '4\insrsid8735851\charrsid14755898 '||wwv_flow.LF||
'286/E, Mogbazar, Dhaka-1271}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(1135) := '\fs24\insrsid8735851 '||wwv_flow.LF||
'\par }\pard \ltrpar\s16\qc \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wrapdefau';
    wwv_flow_api.g_varchar2_table(1136) := 'lt\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid852486 {\rtlch\fcs1 \af0\afs40 \ltrch\';
    wwv_flow_api.g_varchar2_table(1137) := 'fcs0 \b\fs40\cf19\insrsid8735851 Period-Wise}{\rtlch\fcs1 \af0\afs40 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs40\cf19\insr';
    wwv_flow_api.g_varchar2_table(1138) := 'sid8735851\charrsid14755898  Sales Report }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\par }}{\';
    wwv_flow_api.g_varchar2_table(1139) := 'footerl \ltrpar \pard\plain \ltrpar\s18\ql \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wrapdefault\aspa';
    wwv_flow_api.g_varchar2_table(1140) := 'lpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f3150';
    wwv_flow_api.g_varchar2_table(1141) := '6\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid79435';
    wwv_flow_api.g_varchar2_table(1142) := '41 '||wwv_flow.LF||
'\par }}{\footerr \ltrpar \pard\plain \ltrpar\s18\ql \li0\ri0\widctlpar\tqc\tx4680\tqr\tx9360\wr';
    wwv_flow_api.g_varchar2_table(1143) := 'apdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch';
    wwv_flow_api.g_varchar2_table(1144) := '\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0';
    wwv_flow_api.g_varchar2_table(1145) := ' \insrsid7943541 '||wwv_flow.LF||
'\par }}{\headerf \ltrpar \pard\plain \ltrpar\s16\ql \li0\ri0\widctlpar\tqc\tx4680';
    wwv_flow_api.g_varchar2_table(1146) := '\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af0\afs22\al';
    wwv_flow_api.g_varchar2_table(1147) := 'ang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1148) := 'f0 \ltrch\fcs0 \insrsid7943541 '||wwv_flow.LF||
'\par }}{\footerf \ltrpar \pard\plain \ltrpar\s18\ql \li0\ri0\widctl';
    wwv_flow_api.g_varchar2_table(1149) := 'par\tqc\tx4680\tqr\tx9360\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1';
    wwv_flow_api.g_varchar2_table(1150) := ' \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {';
    wwv_flow_api.g_varchar2_table(1151) := '\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid7943541 '||wwv_flow.LF||
'\par }}{\*\pnseclvl1\pnucrm\pnstart1\pnindent720\pnha';
    wwv_flow_api.g_varchar2_table(1152) := 'ng {\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl3\pndec\pns';
    wwv_flow_api.g_varchar2_table(1153) := 'tart1\pnindent720\pnhang {\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang {\pntxta )}}';
    wwv_flow_api.g_varchar2_table(1154) := ''||wwv_flow.LF||
'{\*\pnseclvl5\pndec\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl6\pnlcltr\pnstar';
    wwv_flow_api.g_varchar2_table(1155) := 't1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\pnhang {\pntx';
    wwv_flow_api.g_varchar2_table(1156) := 'tb (}{\pntxta )}}{\*\pnseclvl8'||wwv_flow.LF||
'\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}{\*\pnse';
    wwv_flow_api.g_varchar2_table(1157) := 'clvl9\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb (}{\pntxta )}}\pard\plain \ltrpar\ql \li0\ri0\sa20';
    wwv_flow_api.g_varchar2_table(1158) := '0\sl276\slmult1\widctlpar'||wwv_flow.LF||
'\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pa';
    wwv_flow_api.g_varchar2_table(1159) := 'rarsid8735851 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_api.g_varchar2_table(1160) := 'ngnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid3433759 '||wwv_flow.LF||
'\par }{\rtlch\fcs1 \af0\afs24 ';
    wwv_flow_api.g_varchar2_table(1161) := '\ltrch\fcs0 \b\fs24\insrsid3549643\charrsid3549643 Date:}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24';
    wwv_flow_api.g_varchar2_table(1162) := '\insrsid4855564 {\*\bkmkstart Text24} }{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(1163) := 'b\insrsid4855564\charrsid13843577  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid4855564\charrsi';
    wwv_flow_api.g_varchar2_table(1164) := 'd13843577 {\*\datafield 800100000000000006546578743234000d5034345f46524f4d5f444154450000000000113c3f';
    wwv_flow_api.g_varchar2_table(1165) := '5034345f46524f4d5f444154453f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\';
    wwv_flow_api.g_varchar2_table(1166) := 'ffname Text24}{\*\ffdeftext P44_FROM_DATE}{\*\ffstattext <?P44_FROM_DATE?>}}}}}{\fldrslt {\rtlch\fcs';
    wwv_flow_api.g_varchar2_table(1167) := '1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid4855564\charrsid13843577 P44_FROM_DATE}}}'||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1168) := '\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1169) := 'f0 \ltrch\fcs0 \b\insrsid3549643\charrsid13843577 {\*\bkmkend Text24}   to   {\*\bkmkstart Text25}}{';
    wwv_flow_api.g_varchar2_table(1170) := '\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs0 \b\insrsid4855564\charrsid13843577  FORMT';
    wwv_flow_api.g_varchar2_table(1171) := 'EXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid4855564\charrsid13843577 {\*\datafield 8001000000000000';
    wwv_flow_api.g_varchar2_table(1172) := '06546578743235000b5034345f544f5f4441544500000000000f3c3f5034345f544f5f444154453f3e0000000000}'||wwv_flow.LF||
'{\*\f';
    wwv_flow_api.g_varchar2_table(1173) := 'ormfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text25}{\*\ffdeftext P44_TO_DATE}{\*\ffst';
    wwv_flow_api.g_varchar2_table(1174) := 'attext <?P44_TO_DATE?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\in';
    wwv_flow_api.g_varchar2_table(1175) := 'srsid4855564\charrsid13843577 P44_TO_DATE}}}'||wwv_flow.LF||
'\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectde';
    wwv_flow_api.g_varchar2_table(1176) := 'faultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid15415714\charrsid8735851 {\*\bk';
    wwv_flow_api.g_varchar2_table(1177) := 'mkend Text25}'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trrh432\trleft-108\trhdr\t';
    wwv_flow_api.g_varchar2_table(1178) := 'rbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\b';
    wwv_flow_api.g_varchar2_table(1179) := 'rdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\t';
    wwv_flow_api.g_varchar2_table(1180) := 'rpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid4995876\tbllkhdrrows\tbllkhdrcols\tbllknoco';
    wwv_flow_api.g_varchar2_table(1181) := 'lband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\b';
    wwv_flow_api.g_varchar2_table(1182) := 'rdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth3888\clcbpatraw17 \cellx3780\c';
    wwv_flow_api.g_varchar2_table(1183) := 'lvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 ';
    wwv_flow_api.g_varchar2_table(1184) := ''||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2160\clcbpatraw17 \cellx5940\clvertalc\clbrdrt\brdrs\brdrw';
    wwv_flow_api.g_varchar2_table(1185) := '10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWid';
    wwv_flow_api.g_varchar2_table(1186) := 'th3\clwWidth2214\clcbpatraw17 \cellx8154\clvertalc'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \c';
    wwv_flow_api.g_varchar2_table(1187) := 'lbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2754\clcbpatraw1';
    wwv_flow_api.g_varchar2_table(1188) := '7 \cellx10908\pard\plain \ltrpar\qc \li0\ri0\widctlpar\intbl'||wwv_flow.LF||
'\tx1560\wrapdefault\aspalpha\aspnum\fa';
    wwv_flow_api.g_varchar2_table(1189) := 'auto\adjustright\rin0\lin0\pararsid1123090\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f3150';
    wwv_flow_api.g_varchar2_table(1190) := '6\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs';
    wwv_flow_api.g_varchar2_table(1191) := '24\insrsid8735851\charrsid7216684 Food Menu Name}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs24\insrsid87';
    wwv_flow_api.g_varchar2_table(1192) := '35851\charrsid7216684 \cell }{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid7216';
    wwv_flow_api.g_varchar2_table(1193) := '684 Quantity}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\fs24\insrsid8735851\charrsid7216684 \cell }{\rtl';
    wwv_flow_api.g_varchar2_table(1194) := 'ch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid7216684 Price}{\rtlch\fcs1 \af0\afs24 ';
    wwv_flow_api.g_varchar2_table(1195) := '\ltrch\fcs0 \fs24\insrsid8735851\charrsid7216684 \cell }{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs2';
    wwv_flow_api.g_varchar2_table(1196) := '4\insrsid8735851\charrsid7216684 Unit Total}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs24\insrsid8735851';
    wwv_flow_api.g_varchar2_table(1197) := '\charrsid7216684 \cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefa';
    wwv_flow_api.g_varchar2_table(1198) := 'ult\aspalpha\aspnum\faauto\adjustright\rin0\lin0 '||wwv_flow.LF||
'\rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31';
    wwv_flow_api.g_varchar2_table(1199) := '506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \fs24';
    wwv_flow_api.g_varchar2_table(1200) := '\insrsid8735851\charrsid7216684 \trowd \irow0\irowband0\ltrrow\ts15\trgaph108\trrh432\trleft-108\trh';
    wwv_flow_api.g_varchar2_table(1201) := 'dr'||wwv_flow.LF||
'\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trb';
    wwv_flow_api.g_varchar2_table(1202) := 'rdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpadd';
    wwv_flow_api.g_varchar2_table(1203) := 'l108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid4995876\tbllkhdrrows\tbllkhdrcols\tbl';
    wwv_flow_api.g_varchar2_table(1204) := 'lknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\b';
    wwv_flow_api.g_varchar2_table(1205) := 'rdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth3888\clcbpatraw17 \cellx';
    wwv_flow_api.g_varchar2_table(1206) := '3780\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\br';
    wwv_flow_api.g_varchar2_table(1207) := 'drw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2160\clcbpatraw17 \cellx5940\clvertalc\clbrdrt\brdrs';
    wwv_flow_api.g_varchar2_table(1208) := '\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\cl';
    wwv_flow_api.g_varchar2_table(1209) := 'ftsWidth3\clwWidth2214\clcbpatraw17 \cellx8154\clvertalc'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdr';
    wwv_flow_api.g_varchar2_table(1210) := 'w10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth2754\clcbp';
    wwv_flow_api.g_varchar2_table(1211) := 'atraw17 \cellx10908\row \ltrrow}\trowd \irow1\irowband1\lastrow \ltrrow\ts15\trgaph108\trrh346\trlef';
    wwv_flow_api.g_varchar2_table(1212) := 't-108\trbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \';
    wwv_flow_api.g_varchar2_table(1213) := 'trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trp';
    wwv_flow_api.g_varchar2_table(1214) := 'addl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid4995876\tbllkhdrrows\tbllkhdrcols\';
    wwv_flow_api.g_varchar2_table(1215) := 'tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb';
    wwv_flow_api.g_varchar2_table(1216) := ''||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth3888\clshdrawnil \cellx3780\clv';
    wwv_flow_api.g_varchar2_table(1217) := 'ertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \c';
    wwv_flow_api.g_varchar2_table(1218) := 'ltxlrtb\clftsWidth3\clwWidth2160\clshdrawnil \cellx5940'||wwv_flow.LF||
'\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\b';
    wwv_flow_api.g_varchar2_table(1219) := 'rdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2214\clshdr';
    wwv_flow_api.g_varchar2_table(1220) := 'awnil \cellx8154\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbr';
    wwv_flow_api.g_varchar2_table(1221) := 'drr'||wwv_flow.LF||
'\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2754\clshdrawnil \cellx10908\pard\plain \ltrpar\ql';
    wwv_flow_api.g_varchar2_table(1222) := ' \li0\ri0\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid11';
    wwv_flow_api.g_varchar2_table(1223) := '23090\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\la';
    wwv_flow_api.g_varchar2_table(1224) := 'ngnp1033\langfenp1033 {\*\bkmkstart Text1}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 ';
    wwv_flow_api.g_varchar2_table(1225) := '\cf9\insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid8735851\cha';
    wwv_flow_api.g_varchar2_table(1226) := 'rrsid8735851 '||wwv_flow.LF||
'{\*\datafield 8001000000000000055465787431000246200000000000183c3f666f722d656163683a5';
    wwv_flow_api.g_varchar2_table(1227) := '24f57534554315f524f573f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname ';
    wwv_flow_api.g_varchar2_table(1228) := 'Text1}{\*\ffdeftext F }{\*\ffstattext <?for-each:ROWSET1_ROW?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \lt';
    wwv_flow_api.g_varchar2_table(1229) := 'rch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid8735851\charrsid8735851 F }}}\sectd \ltrsect\linex0';
    wwv_flow_api.g_varchar2_table(1230) := '\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\*\bkmkstart Text2}{\*\bkmkend Text1';
    wwv_flow_api.g_varchar2_table(1231) := '}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851  FORMTE';
    wwv_flow_api.g_varchar2_table(1232) := 'XT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851 {\*\datafield '||wwv_flow.LF||
'800100000000000005';
    wwv_flow_api.g_varchar2_table(1233) := '5465787432000e464f4f445f4d454e555f4e414d450000000000123c3f464f4f445f4d454e555f4e414d453f3e0000000000';
    wwv_flow_api.g_varchar2_table(1234) := '}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\ffdeftext FOOD_MENU_NAME}';
    wwv_flow_api.g_varchar2_table(1235) := '{\*\ffstattext <?FOOD_MENU_NAME?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024';
    wwv_flow_api.g_varchar2_table(1236) := '\noproof\insrsid8735851\charrsid8735851 FOOD_MENU_NAME}}}\sectd \ltrsect\linex0\endnhere\sectlinegri';
    wwv_flow_api.g_varchar2_table(1237) := 'd360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'{\*\bkmken';
    wwv_flow_api.g_varchar2_table(1238) := 'd Text2}\cell }\pard \ltrpar\qc \li0\ri0\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\a';
    wwv_flow_api.g_varchar2_table(1239) := 'djustright\rin0\lin0\pararsid4995876\yts15 {\*\bkmkstart Text3}{\field\flddirty{\*\fldinst {\rtlch\f';
    wwv_flow_api.g_varchar2_table(1240) := 'cs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \ins';
    wwv_flow_api.g_varchar2_table(1241) := 'rsid8735851\charrsid8735851 {\*\datafield 800100000000000005546578743300085155414e544954590000000000';
    wwv_flow_api.g_varchar2_table(1242) := '0c3c3f5155414e544954593f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffna';
    wwv_flow_api.g_varchar2_table(1243) := 'me Text3}{\*\ffdeftext QUANTITY}{\*\ffstattext <?QUANTITY?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\f';
    wwv_flow_api.g_varchar2_table(1244) := 'cs0 \lang1024\langfe1024\noproof\insrsid8735851\charrsid8735851 QUANTITY}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\';
    wwv_flow_api.g_varchar2_table(1245) := 'endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid';
    wwv_flow_api.g_varchar2_table(1246) := '8735851 {\*\bkmkend Text3}\cell }\pard \ltrpar\qr \li0\ri0\widctlpar\intbl'||wwv_flow.LF||
'\tx1560\wrapdefault\aspa';
    wwv_flow_api.g_varchar2_table(1247) := 'lpha\aspnum\faauto\adjustright\rin0\lin0\pararsid1123090\yts15 {\*\bkmkstart Text4}{\field\flddirty{';
    wwv_flow_api.g_varchar2_table(1248) := '\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af';
    wwv_flow_api.g_varchar2_table(1249) := '0 \ltrch\fcs0 '||wwv_flow.LF||
'\insrsid8735851\charrsid8735851 {\*\datafield 80010000000000000554657874340005505249';
    wwv_flow_api.g_varchar2_table(1250) := '43450000000000093c3f50524943453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\';
    wwv_flow_api.g_varchar2_table(1251) := '*\ffname Text4}{\*\ffdeftext PRICE}{\*\ffstattext <?PRICE?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch';
    wwv_flow_api.g_varchar2_table(1252) := '\fcs0 \lang1024\langfe1024\noproof\insrsid8735851\charrsid8735851 PRICE}}}\sectd \ltrsect\linex0\end';
    wwv_flow_api.g_varchar2_table(1253) := 'nhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid873';
    wwv_flow_api.g_varchar2_table(1254) := '5851 '||wwv_flow.LF||
'{\*\bkmkend Text4}\cell {\*\bkmkstart Text5}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \l';
    wwv_flow_api.g_varchar2_table(1255) := 'trch\fcs0 \insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\c';
    wwv_flow_api.g_varchar2_table(1256) := 'harrsid8735851 {\*\datafield '||wwv_flow.LF||
'8001000000000000055465787435000a554e49545f544f54414c00000000000e3c3f5';
    wwv_flow_api.g_varchar2_table(1257) := '54e49545f544f54414c3f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Te';
    wwv_flow_api.g_varchar2_table(1258) := 'xt5}{\*\ffdeftext UNIT_TOTAL}{\*\ffstattext <?UNIT_TOTAL?>}}}}}{\fldrslt {\rtlch\fcs1 '||wwv_flow.LF||
'\af0 \ltrch\';
    wwv_flow_api.g_varchar2_table(1259) := 'fcs0 \lang1024\langfe1024\noproof\insrsid8735851\charrsid8735851 UNIT_TOTAL}}}\sectd \ltrsect\linex0';
    wwv_flow_api.g_varchar2_table(1260) := '\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\*\bkmkstart Text6}{\*\bkmkend Text5';
    wwv_flow_api.g_varchar2_table(1261) := '}{\field\flddirty{\*\fldinst {\rtlch\fcs1 '||wwv_flow.LF||
'\af0 \ltrch\fcs0 \cf9\insrsid8735851\charrsid8735851  FO';
    wwv_flow_api.g_varchar2_table(1262) := 'RMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid8735851\charrsid8735851 {\*\datafield 800100000000';
    wwv_flow_api.g_varchar2_table(1263) := '0000055465787436000220450000000000103c3f656e6420666f722d656163683f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\ffty';
    wwv_flow_api.g_varchar2_table(1264) := 'pe0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftext  E}{\*\ffstattext <?end for-each?>}';
    wwv_flow_api.g_varchar2_table(1265) := '}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid8735851\charrsid';
    wwv_flow_api.g_varchar2_table(1266) := '8735851  E}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj ';
    wwv_flow_api.g_varchar2_table(1267) := '{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 {\*\bkmkend Text6}\cell }\pard\plain \ltrpar\ql \li0\r';
    wwv_flow_api.g_varchar2_table(1268) := 'i0\sa200\sl276\slmult1'||wwv_flow.LF||
'\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \r';
    wwv_flow_api.g_varchar2_table(1269) := 'tlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 \f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfen';
    wwv_flow_api.g_varchar2_table(1270) := 'p1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\trowd \irow1\irowband1\lastrow \ltrrow\ts15\t';
    wwv_flow_api.g_varchar2_table(1271) := 'rgaph108\trrh346\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trb';
    wwv_flow_api.g_varchar2_table(1272) := 'rdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWi';
    wwv_flow_api.g_varchar2_table(1273) := 'dthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid4995876\tbllkh';
    wwv_flow_api.g_varchar2_table(1274) := 'drrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brd';
    wwv_flow_api.g_varchar2_table(1275) := 'rs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth3888\clshdr';
    wwv_flow_api.g_varchar2_table(1276) := 'awnil \cellx3780\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbr';
    wwv_flow_api.g_varchar2_table(1277) := 'drr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2160\clshdrawnil \cellx5940'||wwv_flow.LF||
'\clvertalc\clbrdrt\brdr';
    wwv_flow_api.g_varchar2_table(1278) := 's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3';
    wwv_flow_api.g_varchar2_table(1279) := '\clwWidth2214\clshdrawnil \cellx8154\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb';
    wwv_flow_api.g_varchar2_table(1280) := '\brdrs\brdrw10 \clbrdrr'||wwv_flow.LF||
'\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth2754\clshdrawnil \cellx10908\r';
    wwv_flow_api.g_varchar2_table(1281) := 'ow }\pard \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\tx1560\wrapdefault\aspalpha\aspnum\faaut';
    wwv_flow_api.g_varchar2_table(1282) := 'o\adjustright\rin0\lin0\itap0 {\*\bkmkstart Text7}{\field\flddirty{\*\fldinst {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \l';
    wwv_flow_api.g_varchar2_table(1283) := 'trch\fcs0 \cf9\insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid8';
    wwv_flow_api.g_varchar2_table(1284) := '735851\charrsid8735851 {\*\datafield '||wwv_flow.LF||
'80010000000000000554657874370014666f722d6561636820524f5753455';
    wwv_flow_api.g_varchar2_table(1285) := '4325f524f570000000000183c3f666f722d656163683a524f57534554325f524f573f3e0000000000}{\*\formfield{\fft';
    wwv_flow_api.g_varchar2_table(1286) := 'ype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text7}{\*\ffdeftext for-each ROWSET2_ROW}'||wwv_flow.LF||
'{\*\ffstatt';
    wwv_flow_api.g_varchar2_table(1287) := 'ext <?for-each:ROWSET2_ROW?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\lang1024\langfe1024\no';
    wwv_flow_api.g_varchar2_table(1288) := 'proof\insrsid8735851\charrsid8735851 for-each ROWSET2_ROW}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectli';
    wwv_flow_api.g_varchar2_table(1289) := 'negrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsi';
    wwv_flow_api.g_varchar2_table(1290) := 'd8735851 {\*\bkmkend Text7}'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband0\ltrrow\ts11\trgaph108\trrh144\trle';
    wwv_flow_api.g_varchar2_table(1291) := 'ft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\tr';
    wwv_flow_api.g_varchar2_table(1292) := 'paddfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband'||wwv_flow.LF||
'\tblind0\tblindtype3 \cl';
    wwv_flow_api.g_varchar2_table(1293) := 'vertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clw';
    wwv_flow_api.g_varchar2_table(1294) := 'Width8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdr';
    wwv_flow_api.g_varchar2_table(1295) := 'r\brdrtbl '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\pard \ltrpar\qr \li0\ri0\sa20';
    wwv_flow_api.g_varchar2_table(1296) := '0\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid15281513 {';
    wwv_flow_api.g_varchar2_table(1297) := '\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid8735851\charrsid15415714 Gross Sales}{\rtlch\fcs';
    wwv_flow_api.g_varchar2_table(1298) := '1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8994382\charrsid15415714 :}{\rtlch\fcs1 \af0\afs24 \ltrch\fc';
    wwv_flow_api.g_varchar2_table(1299) := 's0 \b\fs24\insrsid8735851\charrsid15415714 \cell {\*\bkmkstart Text8}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst ';
    wwv_flow_api.g_varchar2_table(1300) := '{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch';
    wwv_flow_api.g_varchar2_table(1301) := '\fcs0 \b\insrsid8735851\charrsid13843577 {\*\datafield '||wwv_flow.LF||
'8001000000000000055465787438000b47524f53535';
    wwv_flow_api.g_varchar2_table(1302) := 'f53414c455300000000000f3c3f47524f53535f53414c45533f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffo';
    wwv_flow_api.g_varchar2_table(1303) := 'wnstat\fftypetxt0{\*\ffname Text8}{\*\ffdeftext GROSS_SALES}{\*\ffstattext <?GROSS_SALES?>}}}}}{\fld';
    wwv_flow_api.g_varchar2_table(1304) := 'rslt {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid8735851\charrsid13843577 ';
    wwv_flow_api.g_varchar2_table(1305) := 'GROSS_SALES}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {';
    wwv_flow_api.g_varchar2_table(1306) := '\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid8735851\charrsid13843577 {\*\bkmkend Text8}\cell }\pard \lt';
    wwv_flow_api.g_varchar2_table(1307) := 'rpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\';
    wwv_flow_api.g_varchar2_table(1308) := 'rin0\lin0 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 \trowd \irow0\irowband0\ltrrow'||wwv_flow.LF||
'\ts11\trgaph';
    wwv_flow_api.g_varchar2_table(1309) := '108\trrh144\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpadd';
    wwv_flow_api.g_varchar2_table(1310) := 'fl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\t';
    wwv_flow_api.g_varchar2_table(1311) := 'blindtype3 \clvertalt\clbrdrt\brdrtbl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb';
    wwv_flow_api.g_varchar2_table(1312) := '\clftsWidth3\clwWidth8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb';
    wwv_flow_api.g_varchar2_table(1313) := '\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\row '||wwv_flow.LF||
'\ltrrow}\';
    wwv_flow_api.g_varchar2_table(1314) := 'pard \ltrpar\qr \li0\ri0\sa200\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright';
    wwv_flow_api.g_varchar2_table(1315) := '\rin0\lin0\pararsid15281513 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid15415';
    wwv_flow_api.g_varchar2_table(1316) := '714 Discount}{\rtlch\fcs1 \af0\afs24 '||wwv_flow.LF||
'\ltrch\fcs0 \b\fs24\insrsid8994382\charrsid15415714 :}{\rtlch';
    wwv_flow_api.g_varchar2_table(1317) := '\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid15415714 \cell {\*\bkmkstart Text9}}{\fi';
    wwv_flow_api.g_varchar2_table(1318) := 'eld\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 '||wwv_flow.LF||
' FORMTEXT';
    wwv_flow_api.g_varchar2_table(1319) := ' }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 {\*\datafield 8001000000000000055';
    wwv_flow_api.g_varchar2_table(1320) := '4657874390008444953434f554e5400000000000c3c3f444953434f554e543f3e0000000000}{\*\formfield{\fftype0\f';
    wwv_flow_api.g_varchar2_table(1321) := 'fownhelp\ffownstat\fftypetxt0{\*\ffname Text9}'||wwv_flow.LF||
'{\*\ffdeftext DISCOUNT}{\*\ffstattext <?DISCOUNT?>}}';
    wwv_flow_api.g_varchar2_table(1322) := '}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid8735851\charrsid138';
    wwv_flow_api.g_varchar2_table(1323) := '43577 DISCOUNT}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnb';
    wwv_flow_api.g_varchar2_table(1324) := 'j {'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 {\*\bkmkend Text9}\cell }\pard ';
    wwv_flow_api.g_varchar2_table(1325) := '\ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustrig';
    wwv_flow_api.g_varchar2_table(1326) := 'ht\rin0\lin0 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\trowd \irow1\irowband1\ltrrow\ts11\trg';
    wwv_flow_api.g_varchar2_table(1327) := 'aph108\trrh144\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trp';
    wwv_flow_api.g_varchar2_table(1328) := 'addfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind';
    wwv_flow_api.g_varchar2_table(1329) := '0\tblindtype3 '||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxl';
    wwv_flow_api.g_varchar2_table(1330) := 'rtb\clftsWidth3\clwWidth8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbr';
    wwv_flow_api.g_varchar2_table(1331) := 'drb\brdrtbl \clbrdrr\brdrtbl '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\row \ltrro';
    wwv_flow_api.g_varchar2_table(1332) := 'w}\pard \ltrpar\qr \li0\ri0\sa200\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustri';
    wwv_flow_api.g_varchar2_table(1333) := 'ght\rin0\lin0\pararsid15281513 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\cf18\insrsid8735851\cha';
    wwv_flow_api.g_varchar2_table(1334) := 'rrsid15415714 Net Sales}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid8994382\charrsid1541';
    wwv_flow_api.g_varchar2_table(1335) := '5714 :}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid8735851\charrsid15415714 \cell {\*\bk';
    wwv_flow_api.g_varchar2_table(1336) := 'mkstart Text10}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrs';
    wwv_flow_api.g_varchar2_table(1337) := 'id13843577  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 {\*\datafield';
    wwv_flow_api.g_varchar2_table(1338) := ' '||wwv_flow.LF||
'80010000000000000654657874313000094e45545f53414c455300000000000d3c3f4e45545f53414c45533f3e0000000';
    wwv_flow_api.g_varchar2_table(1339) := '000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text10}{\*\ffdeftext NET_SALES}{';
    wwv_flow_api.g_varchar2_table(1340) := '\*\ffstattext <?NET_SALES?>}}}}}{\fldrslt {\rtlch\fcs1 '||wwv_flow.LF||
'\af0 \ltrch\fcs0 \b\lang1024\langfe1024\nop';
    wwv_flow_api.g_varchar2_table(1341) := 'roof\insrsid8735851\charrsid13843577 NET_SALES}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sec';
    wwv_flow_api.g_varchar2_table(1342) := 'tdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 ';
    wwv_flow_api.g_varchar2_table(1343) := ''||wwv_flow.LF||
'{\*\bkmkend Text10}\cell }\pard \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault';
    wwv_flow_api.g_varchar2_table(1344) := '\aspalpha\aspnum\faauto\adjustright\rin0\lin0 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid873';
    wwv_flow_api.g_varchar2_table(1345) := '5851\charrsid4995876 \trowd \irow2\irowband2\ltrrow'||wwv_flow.LF||
'\ts11\trgaph108\trrh144\trleft-108\trftsWidth1\';
    wwv_flow_api.g_varchar2_table(1346) := 'trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\t';
    wwv_flow_api.g_varchar2_table(1347) := 'blrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalt\clbrdrt\brdrt';
    wwv_flow_api.g_varchar2_table(1348) := 'bl '||wwv_flow.LF||
'\clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth8388\clshdrawn';
    wwv_flow_api.g_varchar2_table(1349) := 'il \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb';
    wwv_flow_api.g_varchar2_table(1350) := '\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\row '||wwv_flow.LF||
'\ltrrow}\pard \ltrpar\qr \li0\ri0\sa200\widc';
    wwv_flow_api.g_varchar2_table(1351) := 'tlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid15281513 {\rtlch';
    wwv_flow_api.g_varchar2_table(1352) := '\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid15415714 Vat}{\rtlch\fcs1 \af0\afs24 \lt';
    wwv_flow_api.g_varchar2_table(1353) := 'rch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid8994382\charrsid15415714 :}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\ins';
    wwv_flow_api.g_varchar2_table(1354) := 'rsid8735851\charrsid15415714 \cell {\*\bkmkstart Text11}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1355) := 'f0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577  FORMTEXT }{'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insr';
    wwv_flow_api.g_varchar2_table(1356) := 'sid8735851\charrsid13843577 {\*\datafield 80010000000000000654657874313100035641540000000000073c3f56';
    wwv_flow_api.g_varchar2_table(1357) := '41543f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text11}{\*\ffdeft';
    wwv_flow_api.g_varchar2_table(1358) := 'ext VAT}'||wwv_flow.LF||
'{\*\ffstattext <?VAT?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\';
    wwv_flow_api.g_varchar2_table(1359) := 'noproof\insrsid8735851\charrsid13843577 VAT}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectde';
    wwv_flow_api.g_varchar2_table(1360) := 'faultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid8735851\charrsid13843577 {\';
    wwv_flow_api.g_varchar2_table(1361) := '*\bkmkend Text11}\cell }\pard \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\as';
    wwv_flow_api.g_varchar2_table(1362) := 'palpha\aspnum\faauto\adjustright\rin0\lin0 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\trowd \i';
    wwv_flow_api.g_varchar2_table(1363) := 'row3\irowband3\ltrrow\ts11\trgaph108\trrh144\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trauto';
    wwv_flow_api.g_varchar2_table(1364) := 'fit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbll';
    wwv_flow_api.g_varchar2_table(1365) := 'khdrcols\tbllknocolband\tblind0\tblindtype3 '||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\b';
    wwv_flow_api.g_varchar2_table(1366) := 'rdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWidth8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\';
    wwv_flow_api.g_varchar2_table(1367) := 'brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2628\clsh';
    wwv_flow_api.g_varchar2_table(1368) := 'drawnil \cellx10908\row \ltrrow}\pard \ltrpar\qr \li0\ri0\sa200\widctlpar\intbl\tx1560\wrapdefault\a';
    wwv_flow_api.g_varchar2_table(1369) := 'spalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid15281513 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\';
    wwv_flow_api.g_varchar2_table(1370) := 'b\fs24\insrsid8735851\charrsid15415714 Gross Received}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\in';
    wwv_flow_api.g_varchar2_table(1371) := 'srsid8994382\charrsid15415714 :}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid1';
    wwv_flow_api.g_varchar2_table(1372) := '5415714 \cell {\*\bkmkstart Text12}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\i';
    wwv_flow_api.g_varchar2_table(1373) := 'nsrsid8735851\charrsid13843577  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13';
    wwv_flow_api.g_varchar2_table(1374) := '843577 {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743132000e47524f53535f52454345495645440000000000123c3';
    wwv_flow_api.g_varchar2_table(1375) := 'f47524f53535f52454345495645443f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*';
    wwv_flow_api.g_varchar2_table(1376) := '\ffname Text12}{\*\ffdeftext GROSS_RECEIVED}{\*\ffstattext <?GROSS_RECEIVED?>}'||wwv_flow.LF||
'}}}}{\fldrslt {\rtlc';
    wwv_flow_api.g_varchar2_table(1377) := 'h\fcs1 \af0 \ltrch\fcs0 \b\lang1024\langfe1024\noproof\insrsid8735851\charrsid13843577 GROSS_RECEIVE';
    wwv_flow_api.g_varchar2_table(1378) := 'D}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs';
    wwv_flow_api.g_varchar2_table(1379) := '1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\b\insrsid8735851\charrsid13843577 {\*\bkmkend Text12}\cell }\pard \ltrpar\ql \';
    wwv_flow_api.g_varchar2_table(1380) := 'li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0';
    wwv_flow_api.g_varchar2_table(1381) := ' {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\trowd \irow4\irowband4\ltrrow\ts11\trgaph108\trrh1';
    wwv_flow_api.g_varchar2_table(1382) := '44\trleft-108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpad';
    wwv_flow_api.g_varchar2_table(1383) := 'dft3\trpaddfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype';
    wwv_flow_api.g_varchar2_table(1384) := '3 '||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWid';
    wwv_flow_api.g_varchar2_table(1385) := 'th3\clwWidth8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl ';
    wwv_flow_api.g_varchar2_table(1386) := '\clbrdrr\brdrtbl '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\row \ltrrow}\pard \ltr';
    wwv_flow_api.g_varchar2_table(1387) := 'par\qr \li0\ri0\sa200\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin';
    wwv_flow_api.g_varchar2_table(1388) := '0\pararsid15281513 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\cf18\insrsid8735851\charrsid1541571';
    wwv_flow_api.g_varchar2_table(1389) := '4 Cash To Account}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid8994382\charrsid15415714 :';
    wwv_flow_api.g_varchar2_table(1390) := '}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\cf18\insrsid8735851\charrsid15415714 \cell {\*\bkmkstar';
    wwv_flow_api.g_varchar2_table(1391) := 't Text13}}'||wwv_flow.LF||
'{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid1384';
    wwv_flow_api.g_varchar2_table(1392) := '3577  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851\charrsid13843577 {\*\datafield '||wwv_flow.LF||
'800';
    wwv_flow_api.g_varchar2_table(1393) := '100000000000006546578743133000f434153485f544f5f4143434f554e540000000000133c3f434153485f544f5f4143434';
    wwv_flow_api.g_varchar2_table(1394) := 'f554e543f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text13}{\*\ffd';
    wwv_flow_api.g_varchar2_table(1395) := 'eftext CASH_TO_ACCOUNT}{\*\ffstattext '||wwv_flow.LF||
'<?CASH_TO_ACCOUNT?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\f';
    wwv_flow_api.g_varchar2_table(1396) := 'cs0 \b\lang1024\langfe1024\noproof\insrsid8735851\charrsid13843577 CASH_TO_ACCOUNT}}}\sectd \ltrsect';
    wwv_flow_api.g_varchar2_table(1397) := '\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 '||wwv_flow.LF||
'\ltrch\fcs';
    wwv_flow_api.g_varchar2_table(1398) := '0 \b\insrsid8735851\charrsid13843577 {\*\bkmkend Text13}\cell }\pard \ltrpar\ql \li0\ri0\sa200\sl276';
    wwv_flow_api.g_varchar2_table(1399) := '\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 {\rtlch\fcs1 \af0 ';
    wwv_flow_api.g_varchar2_table(1400) := '\ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'\trowd \irow5\irowband5\lastrow \ltrrow\ts11\trgaph108\trrh144\trleft-';
    wwv_flow_api.g_varchar2_table(1401) := '108\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpad';
    wwv_flow_api.g_varchar2_table(1402) := 'dfb3\trpaddfr3\tblrsid15281513\tbllkhdrrows\tbllkhdrcols\tbllknocolband'||wwv_flow.LF||
'\tblind0\tblindtype3 \clver';
    wwv_flow_api.g_varchar2_table(1403) := 'talt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\brdrtbl \cltxlrtb\clftsWidth3\clwWid';
    wwv_flow_api.g_varchar2_table(1404) := 'th8388\clshdrawnil \cellx8280\clvertalt\clbrdrt\brdrtbl \clbrdrl\brdrtbl \clbrdrb\brdrtbl \clbrdrr\b';
    wwv_flow_api.g_varchar2_table(1405) := 'rdrtbl '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth2628\clshdrawnil \cellx10908\row }\pard \ltrpar\ql \li0\ri0\s';
    wwv_flow_api.g_varchar2_table(1406) := 'a200\sl276\slmult1\widctlpar\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {';
    wwv_flow_api.g_varchar2_table(1407) := '\*\bkmkstart Text14}{\field\flddirty{\*\fldinst {\rtlch\fcs1 '||wwv_flow.LF||
'\af0 \ltrch\fcs0 \b\i\cf9\insrsid8735';
    wwv_flow_api.g_varchar2_table(1408) := '851\charrsid8994382  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\i\cf9\insrsid8735851\charrsid8994382';
    wwv_flow_api.g_varchar2_table(1409) := ' {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743134000f656e6420524f57534554325f524f570000000000103c3f656';
    wwv_flow_api.g_varchar2_table(1410) := 'e6420666f722d656163683f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname ';
    wwv_flow_api.g_varchar2_table(1411) := 'Text14}{\*\ffdeftext end ROWSET2_ROW}{\*\ffstattext <?end for-each?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1412) := 'f0 \ltrch\fcs0 \b\i\cf9\lang1024\langfe1024\noproof\insrsid8735851\charrsid8994382 end ROWSET2_ROW}}';
    wwv_flow_api.g_varchar2_table(1413) := '}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \';
    wwv_flow_api.g_varchar2_table(1414) := 'af0\afs24 \ltrch\fcs0 '||wwv_flow.LF||
'\b\fs24\insrsid8735851\charrsid15415714 {\*\bkmkend Text14}'||wwv_flow.LF||
'\par }\pard \lt';
    wwv_flow_api.g_varchar2_table(1415) := 'rpar\qc \li0\ri0\sa200\sl276\slmult1\widctlpar\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright';
    wwv_flow_api.g_varchar2_table(1416) := '\rin0\lin0\itap0\pararsid10628002 {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8994382\charrsi';
    wwv_flow_api.g_varchar2_table(1417) := 'd15415714 Settlement'||wwv_flow.LF||
'\par \ltrrow}\trowd \irow0\irowband0\ltrrow\ts15\trqc\trgaph108\trrh448\trleft';
    wwv_flow_api.g_varchar2_table(1418) := '-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw1';
    wwv_flow_api.g_varchar2_table(1419) := '0 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\';
    wwv_flow_api.g_varchar2_table(1420) := 'trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid8994382\tbllkhdrrows\tbllkhdrco';
    wwv_flow_api.g_varchar2_table(1421) := 'ls\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrd';
    wwv_flow_api.g_varchar2_table(1422) := 'rb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth4714\clcbpatraw17 ';
    wwv_flow_api.g_varchar2_table(1423) := '\cellx4606\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\br';
    wwv_flow_api.g_varchar2_table(1424) := 'drs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2305\clcbpatraw17 \cellx6911\pard\plain \ltrpa';
    wwv_flow_api.g_varchar2_table(1425) := 'r\qc \li0\ri0\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\parars';
    wwv_flow_api.g_varchar2_table(1426) := 'id8994382\yts15 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgri';
    wwv_flow_api.g_varchar2_table(1427) := 'd\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735851 Payment Mode}{\rtlch\fcs1 ';
    wwv_flow_api.g_varchar2_table(1428) := '\af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851 \cell }{\rtlch\fcs1 \af0 \ltrch\fcs0 \b\insrsid8735';
    wwv_flow_api.g_varchar2_table(1429) := '851 Amount}{'||wwv_flow.LF||
'\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851 \cell }\pard\plain \ltrpa';
    wwv_flow_api.g_varchar2_table(1430) := 'r\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\intbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin';
    wwv_flow_api.g_varchar2_table(1431) := '0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1';
    wwv_flow_api.g_varchar2_table(1432) := '033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 \trowd \irow0\irowband0\ltrrow\ts15\t';
    wwv_flow_api.g_varchar2_table(1433) := 'rqc\trgaph108\trrh448\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\b';
    wwv_flow_api.g_varchar2_table(1434) := 'rdrw10 '||wwv_flow.LF||
'\trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWi';
    wwv_flow_api.g_varchar2_table(1435) := 'dthB3\trftsWidthA3\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid8';
    wwv_flow_api.g_varchar2_table(1436) := '994382\tbllkhdrrows\tbllkhdrcols\tbllknocolband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10';
    wwv_flow_api.g_varchar2_table(1437) := ' \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWid';
    wwv_flow_api.g_varchar2_table(1438) := 'th3\clwWidth4714\clcbpatraw17 \cellx4606\clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clb';
    wwv_flow_api.g_varchar2_table(1439) := 'rdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth2305\clcbpatraw1';
    wwv_flow_api.g_varchar2_table(1440) := '7 \cellx6911\row \ltrrow}\trowd \irow1\irowband1\lastrow \ltrrow\ts15\trqc\trgaph108\trrh359\trleft-';
    wwv_flow_api.g_varchar2_table(1441) := '108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\tr';
    wwv_flow_api.g_varchar2_table(1442) := 'brdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 \trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl';
    wwv_flow_api.g_varchar2_table(1443) := '108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid8994382\tbllkhdrrows\tbllkhdrcols\tbll';
    wwv_flow_api.g_varchar2_table(1444) := 'knocolband\tblind0\tblindtype3 \clvertalc\clbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\br';
    wwv_flow_api.g_varchar2_table(1445) := 'drs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth4714\clshdrawnil \cellx4606\clverta';
    wwv_flow_api.g_varchar2_table(1446) := 'lc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clt';
    wwv_flow_api.g_varchar2_table(1447) := 'xlrtb\clftsWidth3\clwWidth2305\clshdrawnil \cellx6911\pard\plain \ltrpar\ql \li0\ri0\widctlpar\intbl';
    wwv_flow_api.g_varchar2_table(1448) := '\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid8994382\yts15 \rtlch\fcs1 \';
    wwv_flow_api.g_varchar2_table(1449) := 'af0\afs22\alang1025 \ltrch\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\*';
    wwv_flow_api.g_varchar2_table(1450) := '\bkmkstart Text15}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid8735851\char';
    wwv_flow_api.g_varchar2_table(1451) := 'rsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\insrsid8735851\charrsid8735851 '||wwv_flow.LF||
'{\*\dataf';
    wwv_flow_api.g_varchar2_table(1452) := 'ield 800100000000000006546578743135000246200000000000183c3f666f722d656163683a524f57534554335f524f573';
    wwv_flow_api.g_varchar2_table(1453) := 'f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text15}{\*\ffdeftext F';
    wwv_flow_api.g_varchar2_table(1454) := ' }{\*\ffstattext <?for-each:ROWSET3_ROW?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \cf9\lang102';
    wwv_flow_api.g_varchar2_table(1455) := '4\langfe1024\noproof\insrsid8735851\charrsid8735851 F }}}\sectd \ltrsect\linex0\endnhere\sectlinegri';
    wwv_flow_api.g_varchar2_table(1456) := 'd360\sectdefaultcl\sectrsid8735851\sftnbj {\*\bkmkstart Text16}{\*\bkmkend Text15}'||wwv_flow.LF||
'{\field\flddirty';
    wwv_flow_api.g_varchar2_table(1457) := '{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \a';
    wwv_flow_api.g_varchar2_table(1458) := 'f0 \ltrch\fcs0 \insrsid8735851\charrsid8735851 {\*\datafield '||wwv_flow.LF||
'800100000000000006546578743136000c504';
    wwv_flow_api.g_varchar2_table(1459) := '1594d454e545f4d4f44450000000000103c3f5041594d454e545f4d4f44453f3e0000000000}{\*\formfield{\fftype0\f';
    wwv_flow_api.g_varchar2_table(1460) := 'fownhelp\ffownstat\fftypetxt0{\*\ffname Text16}{\*\ffdeftext PAYMENT_MODE}{\*\ffstattext <?PAYMENT_M';
    wwv_flow_api.g_varchar2_table(1461) := 'ODE?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insrsid8735851\char';
    wwv_flow_api.g_varchar2_table(1462) := 'rsid8735851 PAYMENT_MODE}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sectrsid873';
    wwv_flow_api.g_varchar2_table(1463) := '5851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851 '||wwv_flow.LF||
'{\*\bkmkend Text16}\cell }\pard \ltrpar\';
    wwv_flow_api.g_varchar2_table(1464) := 'qr \li0\ri0\widctlpar\intbl\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\pararsid';
    wwv_flow_api.g_varchar2_table(1465) := '8994382\yts15 {\*\bkmkstart Text17}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insr';
    wwv_flow_api.g_varchar2_table(1466) := 'sid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 \insrsid8735851\charrsid8735851 ';
    wwv_flow_api.g_varchar2_table(1467) := '{\*\datafield 8001000000000000065465787431370006414d4f554e5400000000000a3c3f414d4f554e543f3e00000000';
    wwv_flow_api.g_varchar2_table(1468) := '00}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text17}{\*\ffdeftext AMOUNT}{\*';
    wwv_flow_api.g_varchar2_table(1469) := '\ffstattext <?AMOUNT?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \ltrch\fcs0 \lang1024\langfe1024\noproof\insr';
    wwv_flow_api.g_varchar2_table(1470) := 'sid8735851\charrsid8735851 AMOUNT}}}\sectd \ltrsect'||wwv_flow.LF||
'\linex0\endnhere\sectlinegrid360\sectdefaultcl\';
    wwv_flow_api.g_varchar2_table(1471) := 'sectrsid8735851\sftnbj {\*\bkmkstart Text18}{\*\bkmkend Text17}{\field\flddirty{\*\fldinst {\rtlch\f';
    wwv_flow_api.g_varchar2_table(1472) := 'cs1 \af0 \ltrch\fcs0 \cf9\insrsid8735851\charrsid8735851  FORMTEXT }{\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'';
    wwv_flow_api.g_varchar2_table(1473) := '\cf9\insrsid8735851\charrsid8735851 {\*\datafield 80010000000000000654657874313800022045000000000010';
    wwv_flow_api.g_varchar2_table(1474) := '3c3f656e6420666f722d656163683f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\';
    wwv_flow_api.g_varchar2_table(1475) := 'ffname Text18}{\*\ffdeftext  E}{\*\ffstattext '||wwv_flow.LF||
'<?end for-each?>}}}}}{\fldrslt {\rtlch\fcs1 \af0 \lt';
    wwv_flow_api.g_varchar2_table(1476) := 'rch\fcs0 \cf9\lang1024\langfe1024\noproof\insrsid8735851\charrsid8735851  E}}}\sectd \ltrsect\linex0';
    wwv_flow_api.g_varchar2_table(1477) := '\endnhere\sectlinegrid360\sectdefaultcl\sectrsid8735851\sftnbj {\rtlch\fcs1 \af0 \ltrch\fcs0 '||wwv_flow.LF||
'\insr';
    wwv_flow_api.g_varchar2_table(1478) := 'sid8735851 {\*\bkmkend Text18}\cell }\pard\plain \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\widctlpar\i';
    wwv_flow_api.g_varchar2_table(1479) := 'ntbl\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0 \rtlch\fcs1 \af0\afs22\alang1025 \ltrc';
    wwv_flow_api.g_varchar2_table(1480) := 'h\fcs0 '||wwv_flow.LF||
'\f31506\fs22\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\rtlch\fcs1 \af0 \ltrch\fcs';
    wwv_flow_api.g_varchar2_table(1481) := '0 \insrsid8735851 \trowd \irow1\irowband1\lastrow \ltrrow\ts15\trqc\trgaph108\trrh359\trleft-108\trb';
    wwv_flow_api.g_varchar2_table(1482) := 'rdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb'||wwv_flow.LF||
'\brdrs\brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\b';
    wwv_flow_api.g_varchar2_table(1483) := 'rdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trftsWidthB3\trftsWidthA3\trautofit1\trpaddl108\t';
    wwv_flow_api.g_varchar2_table(1484) := 'rpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblrsid8994382\tbllkhdrrows\tbllkhdrcols\tbllknoco';
    wwv_flow_api.g_varchar2_table(1485) := 'lband\tblind0\tblindtype3 \clvertalc\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb'||wwv_flow.LF||
'\brdrs\b';
    wwv_flow_api.g_varchar2_table(1486) := 'rdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth4714\clshdrawnil \cellx4606\clvertalc\cl';
    wwv_flow_api.g_varchar2_table(1487) := 'brdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\c';
    wwv_flow_api.g_varchar2_table(1488) := 'lftsWidth3\clwWidth2305\clshdrawnil \cellx6911'||wwv_flow.LF||
'\row }\pard \ltrpar\ql \li0\ri0\sa200\sl276\slmult1\';
    wwv_flow_api.g_varchar2_table(1489) := 'widctlpar\tx1560\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {\rtlch\fcs1 \af0 \l';
    wwv_flow_api.g_varchar2_table(1490) := 'trch\fcs0 \insrsid11102424 \tab \tab \tab \tab \tab \tab \tab \tab }{\rtlch\fcs1 \af0\afs24 '||wwv_flow.LF||
'\ltrch';
    wwv_flow_api.g_varchar2_table(1491) := '\fcs0 \b\fs24\insrsid11102424\charrsid11102424 Total:}{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\in';
    wwv_flow_api.g_varchar2_table(1492) := 'srsid11102424  {\*\bkmkstart Text19}}{\field\flddirty{\*\fldinst {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0';
    wwv_flow_api.g_varchar2_table(1493) := ' \b\fs24\insrsid1123090\charrsid1123090 '||wwv_flow.LF||
' FORMTEXT }{\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\ins';
    wwv_flow_api.g_varchar2_table(1494) := 'rsid1123090\charrsid1123090 {\*\datafield 800100000000000006546578743139000e47524f53535f524543454956';
    wwv_flow_api.g_varchar2_table(1495) := '45440000000000123c3f47524f53535f52454345495645443f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ff';
    wwv_flow_api.g_varchar2_table(1496) := 'ownstat\fftypetxt0{\*\ffname Text19}{\*\ffdeftext GROSS_RECEIVED}{\*\ffstattext <?GROSS_RECEIVED?>}}';
    wwv_flow_api.g_varchar2_table(1497) := '}}}{\fldrslt {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\lang1024\langfe1024\noproof\insrsid1123090\';
    wwv_flow_api.g_varchar2_table(1498) := 'charrsid1123090 '||wwv_flow.LF||
'GROSS_RECEIVED}}}\sectd \ltrsect\linex0\endnhere\sectlinegrid360\sectdefaultcl\sec';
    wwv_flow_api.g_varchar2_table(1499) := 'trsid8735851\sftnbj {\rtlch\fcs1 \af0\afs24 \ltrch\fcs0 \b\fs24\insrsid8735851\charrsid11102424 {\*\';
    wwv_flow_api.g_varchar2_table(1500) := 'bkmkend Text19}'||wwv_flow.LF||
'\par }{\*\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b4';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
    wwv_flow_api.g_varchar2_table(1501) := '36f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a'||wwv_flow.LF||
'9cb2400825e982c78ec7a27cc0c899241';
    wwv_flow_api.g_varchar2_table(1502) := '6c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad'||wwv_flow.LF||
'568';
    wwv_flow_api.g_varchar2_table(1503) := '9811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551d';
    wwv_flow_api.g_varchar2_table(1504) := 'c18eb899138e3c943d7e503b6'||wwv_flow.LF||
'b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f';
    wwv_flow_api.g_varchar2_table(1505) := '52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0'||wwv_flow.LF||
'0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb';
    wwv_flow_api.g_varchar2_table(1506) := '28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6'||wwv_flow.LF||
'a7e7c00000003';
    wwv_flow_api.g_varchar2_table(1507) := '60100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f6';
    wwv_flow_api.g_varchar2_table(1508) := '8221bdb1bebdb4f'||wwv_flow.LF||
'c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085';
    wwv_flow_api.g_varchar2_table(1509) := 'b787086a37bdbb55fbc50d1a33ccd311ba548b6309512'||wwv_flow.LF||
'0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f9';
    wwv_flow_api.g_varchar2_table(1510) := '89e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462'||wwv_flow.LF||
'a1a82fe353bd90a865aad41';
    wwv_flow_api.g_varchar2_table(1511) := 'ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f7';
    wwv_flow_api.g_varchar2_table(1512) := '46865'||wwv_flow.LF||
'6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439';
    wwv_flow_api.g_varchar2_table(1513) := 'c1a41c7a0d29fdbd7e5e38337cedf14d59b'||wwv_flow.LF||
'4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e9781';
    wwv_flow_api.g_varchar2_table(1514) := '8c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b'||wwv_flow.LF||
'4757e8d3f729e245eb2b260a0238fd010';
    wwv_flow_api.g_varchar2_table(1515) := '000ffff0300504b03041400060008000000210030dd4329a8060000a41b0000160000007468656d652f7468656d652f'||wwv_flow.LF||
'746';
    wwv_flow_api.g_varchar2_table(1516) := '8656d65312e786d6cec594f6fdb3614bf0fd87720746f6327761a07758ad8b19b2d4d1bc46e871e698996d850a240d2497d1';
    wwv_flow_api.g_varchar2_table(1517) := 'bdae38001c3ba618715d86d87'||wwv_flow.LF||
'615b8116d8a5fb34d93a6c1dd0afb0475292c5585e9236d88aad3e2412f9e3fbff1e1fa9a';
    wwv_flow_api.g_varchar2_table(1518) := 'bd7eec70c1d1221294fda5efd72cd4324f1794093b0eddd1ef62fad'||wwv_flow.LF||
'79482a9c0498f184b4bd2991deb58df7dfbb8ad7554';
    wwv_flow_api.g_varchar2_table(1519) := '46282607d22d771db8b944ad79796a40fc3585ee62949606ecc458c15bc8a702910f808e8c66c69b9565b'||wwv_flow.LF||
'5d8a314d3c94e';
    wwv_flow_api.g_varchar2_table(1520) := '018c8de1a8fa94fd05093f43672e23d06af89927ac06762a049136785c10607758d9053d965021d62d6f6804fc08f86e4bef';
    wwv_flow_api.g_varchar2_table(1521) := '210c352c144dbab'||wwv_flow.LF||
'999fb7b4717509af678b985ab0b6b4ae6f7ed9ba6c4170b06c788a705430adf71bad2b5b057d03606a1';
    wwv_flow_api.g_varchar2_table(1522) := 'ed7ebf5babd7a41cf00b0ef83a6569632cd467faddec9'||wwv_flow.LF||
'699640f6719e76b7d6ac355c7c89feca9cccad4ea7d36c65b258a';
    wwv_flow_api.g_varchar2_table(1523) := '206641f1b73f8b5da6a6373d9c11b90c537e7f08dce66b7bbeae00dc8e257e7f0fd2badd586'||wwv_flow.LF||
'8b37a088d1e4600ead1ddae';
    wwv_flow_api.g_varchar2_table(1524) := 'f67d40bc898b3ed4af81ac0d76a197c86826828a24bb318f3442d8ab518dfe3a20f000d6458d104a9694ac6d88728eee2782';
    wwv_flow_api.g_varchar2_table(1525) := '428d6'||wwv_flow.LF||
'0cf03ac1a5193be4cbb921cd0b495fd054b5bd0f530c1931a3f7eaf9f7af9e3f45c70f9e1d3ff8e9f8e1c3e3073f5';
    wwv_flow_api.g_varchar2_table(1526) := 'a42ceaa6d9c84e5552fbffdeccfc71fa33f'||wwv_flow.LF||
'9e7ef3f2d117d57859c6fffac327bffcfc793510d26726ce8b2f9ffcf6ecc98';
    wwv_flow_api.g_varchar2_table(1527) := 'baf3efdfdbb4715f04d814765f890c644a29be408edf3181433567125272371be'||wwv_flow.LF||
'15c308d3f28acd249438c19a4b05fd9e8';
    wwv_flow_api.g_varchar2_table(1528) := 'a1cf4cd296699771c393ac4b5e01d01e5a30a787d72cf1178108989a2159c77a2d801ee72ce3a5c545a6147f32a9979'||wwv_flow.LF||
'384';
    wwv_flow_api.g_varchar2_table(1529) := '9c26ae66252c6ed637c58c5bb8b13c7bfbd490a75330f4b47f16e441c31f7184e140e494214d273fc80900aedee52ead8759';
    wwv_flow_api.g_varchar2_table(1530) := '7fa824b3e56e82e451d4c2b4d'||wwv_flow.LF||
'32a423279a668bb6690c7e9956e90cfe766cb37b077538abd27a8b1cba48c80acc2a841f1';
    wwv_flow_api.g_varchar2_table(1531) := '2e698f13a9e281c57911ce298950d7e03aba84ac8c154f8655c4f2a'||wwv_flow.LF||
'f074481847bd804859b5e696007d4b4edfc150b12ad';
    wwv_flow_api.g_varchar2_table(1532) := 'dbecba6b18b148a1e54d1bc81392f23b7f84137c2715a851dd0242a633f900710a218ed715505dfe56e86'||wwv_flow.LF||
'e877f0034e16b';
    wwv_flow_api.g_varchar2_table(1533) := 'afb0e258ebb4faf06b769e888340b103d331115bebc4eb813bf83291b63624a0d1475a756c734f9bbc2cd28546ecbe1e20a3';
    wwv_flow_api.g_varchar2_table(1534) := '794ca175f3fae90'||wwv_flow.LF||
'fb6d2dd99bb07b55e5ccf68942bd0877b23c77b908e8db5f9db7f024d9239010f35bd4bbe2fcae387bf';
    wwv_flow_api.g_varchar2_table(1535) := 'ff9e2bc289f2fbe24cfaa301468dd8bd846dbb4ddf1c2'||wwv_flow.LF||
'ae7b4c191ba8292337a469bc25ec3d411f06f53a73e224c5292c8';
    wwv_flow_api.g_varchar2_table(1536) := 'de0516732307070a1c0660d125c7d44553488700a4d7bddd3444299910e254ab984c3a219ae'||wwv_flow.LF||
'a4adf1d0f82b7bd46cea438';
    wwv_flow_api.g_varchar2_table(1537) := '8ad1c12ab5d1ed8e1153d9c9f350a3246aad01c6873462b9ac05999ad5cc988826eafc3acae853a33b7ba11cd1445875ba1b';
    wwv_flow_api.g_varchar2_table(1538) := '236b1'||wwv_flow.LF||
'399483c90bd560b0b0263435085a21b0f22a9cf9356b38ec6046026d77eba3dc2dc60b17e92219e180643ed27acff';
    wwv_flow_api.g_varchar2_table(1539) := 'ba86e9c94c7ca9c225a0f1b0cfae0788ad5'||wwv_flow.LF||
'4adc5a9aec1b703b8b93caec1a0bd8e5de7b132fe5113cf312503b998e2c292';
    wwv_flow_api.g_varchar2_table(1540) := '7274bd051db6b35979b1ef271daf6c6704e86c73805af4bdd476216c26593af84'||wwv_flow.LF||
'0dfb5393d964f9cc9bad5c313709ea70f';
    wwv_flow_api.g_varchar2_table(1541) := '561ed3ea7b053075221d51696910d0d339585004b34272bff7213cc7a510a5454a3b349b1b206c1f0af490176745d4b'||wwv_flow.LF||
'c66';
    wwv_flow_api.g_varchar2_table(1542) := '3e2abb2b34b23da76f6352ba57ca2881844c1111ab189d8c7e07e1daaa04f40255c77988aa05fe06e4e5bdb4cb9c5394bbaf';
    wwv_flow_api.g_varchar2_table(1543) := '28d98c1d971ccd20867e556a7'||wwv_flow.LF||
'689ec9166e0a522183792b8907ba55ca6e943bbf2a26e52f48957218ffcf54d1fb09dc3ea';
    wwv_flow_api.g_varchar2_table(1544) := 'c04da033e5c0d0b8c74a6b43d2e54c4a10aa511f5fb021a07533b20'||wwv_flow.LF||
'5ae07e17a621a8e082dafc17e450ffb739676998b48';
    wwv_flow_api.g_varchar2_table(1545) := '643a4daa7211214f623150942f6a02c99e83b85583ddbbb2c4996113211551257a656ec1139246ca86be0'||wwv_flow.LF||
'aadedb3d1441a';
    wwv_flow_api.g_varchar2_table(1546) := '89b6a929501833b197fee7b9641a3503739e57c732a59b1f7da1cf8a73b1f9bcca0945b874d4393dbbf10b1680f66bbaa5d6';
    wwv_flow_api.g_varchar2_table(1547) := 'f96e77b6f59113d'||wwv_flow.LF||
'316bb31a795600b3d256d0cad2fe354538e7566b2bd69cc6cbcd5c38f0e2bcc63058344429dc2121fd0';
    wwv_flow_api.g_varchar2_table(1548) := '7f63f2a7c66bf76e80d75c8f7a1b622f878a18941d840'||wwv_flow.LF||
'545fb28d07d205d20e8ea071b283369834296bdaac75d256cb37e';
    wwv_flow_api.g_varchar2_table(1549) := 'b0bee740bbe278cad253b8bbfcf69eca23973d939b97891c6ce2cecd8da8e2d343578f6648a'||wwv_flow.LF||
'c2d0383fc818c798cf64e52';
    wwv_flow_api.g_varchar2_table(1550) := 'f597c740f1cbd05df0c264c49134cf09d4a60e8a107260f20f92d47b374e32f000000ffff0300504b0304140006000800000';
    wwv_flow_api.g_varchar2_table(1551) := '02100'||wwv_flow.LF||
'0dd1909fb60000001b010000270000007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722';
    wwv_flow_api.g_varchar2_table(1552) := 'e786d6c2e72656c73848f4d0ac2301484f7'||wwv_flow.LF||
'8277086f6fd3ba109126dd88d0add40384e4350d363f2451eced0dae2c082e8';
    wwv_flow_api.g_varchar2_table(1553) := '761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec8e4052164e89'||wwv_flow.LF||
'd93b64b060828e6f37ed1567914b284d2';
    wwv_flow_api.g_varchar2_table(1554) := '62452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524bd62107bd500'||wwv_flow.LF||
'199';
    wwv_flow_api.g_varchar2_table(1555) := '6509affb3fd381a89672f1f165dfe514173d9850528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d001';
    wwv_flow_api.g_varchar2_table(1556) := '4000600080000002100e9de0f'||wwv_flow.LF||
'bfff0000001c0200001300000000000000000000000000000000005b436f6e74656e745f5';
    wwv_flow_api.g_varchar2_table(1557) := '4797065735d2e786d6c504b01022d0014000600080000002100a5d6'||wwv_flow.LF||
'a7e7c0000000360100000b000000000000000000000';
    wwv_flow_api.g_varchar2_table(1558) := '00000300100005f72656c732f2e72656c73504b01022d00140006000800000021006b799616830000008a'||wwv_flow.LF||
'0000001c00000';
    wwv_flow_api.g_varchar2_table(1559) := '000000000000000000000190200007468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d00140';
    wwv_flow_api.g_varchar2_table(1560) := '006000800000021'||wwv_flow.LF||
'0030dd4329a8060000a41b00001600000000000000000000000000d60200007468656d652f7468656d6';
    wwv_flow_api.g_varchar2_table(1561) := '52f7468656d65312e786d6c504b01022d001400060008'||wwv_flow.LF||
'00000021000dd1909fb60000001b0100002700000000000000000';
    wwv_flow_api.g_varchar2_table(1562) := '000000000b20900007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b0';
    wwv_flow_api.g_varchar2_table(1563) := '50600000000050005005d010000ad0a00000000}'||wwv_flow.LF||
'{\*\colorschememapping 3c3f786d6c2076657273696f6e3d22312e3';
    wwv_flow_api.g_varchar2_table(1564) := '02220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d'||wwv_flow.LF||
'61702';
    wwv_flow_api.g_varchar2_table(1565) := '0786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e6';
    wwv_flow_api.g_varchar2_table(1566) := '76d6c2f323030362f6d6169'||wwv_flow.LF||
'6e22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d2';
    wwv_flow_api.g_varchar2_table(1567) := '2646b322220616363656e74313d22616363656e74312220616363'||wwv_flow.LF||
'656e74323d22616363656e74322220616363656e74333';
    wwv_flow_api.g_varchar2_table(1568) := 'd22616363656e74332220616363656e74343d22616363656e74342220616363656e74353d22616363656e743522206163636';
    wwv_flow_api.g_varchar2_table(1569) := '56e74363d22616363656e74362220686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}';
    wwv_flow_api.g_varchar2_table(1570) := ''||wwv_flow.LF||
'{\*\latentstyles\lsdstimax267\lsdlockeddef0\lsdsemihiddendef1\lsdunhideuseddef1\lsdqformatdef0\lsd';
    wwv_flow_api.g_varchar2_table(1571) := 'prioritydef99{\lsdlockedexcept \lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority0 \lsdlocked';
    wwv_flow_api.g_varchar2_table(1572) := '0 Normal;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;\lsdqfor';
    wwv_flow_api.g_varchar2_table(1573) := 'mat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 3;\lsdqforma';
    wwv_flow_api.g_varchar2_table(1574) := 't1 \lsdpriority9 \lsdlocked0 heading 4;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 5;\lsdqforma';
    wwv_flow_api.g_varchar2_table(1575) := 't1 \lsdpriority9 \lsdlocked0 heading 6;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;\lsdqformat1';
    wwv_flow_api.g_varchar2_table(1576) := ' \lsdpriority9 \lsdlocked0 heading 8;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 9;'||wwv_flow.LF||
'\lsdpriority';
    wwv_flow_api.g_varchar2_table(1577) := '39 \lsdlocked0 toc 1;\lsdpriority39 \lsdlocked0 toc 2;\lsdpriority39 \lsdlocked0 toc 3;\lsdpriority3';
    wwv_flow_api.g_varchar2_table(1578) := '9 \lsdlocked0 toc 4;\lsdpriority39 \lsdlocked0 toc 5;\lsdpriority39 \lsdlocked0 toc 6;\lsdpriority39';
    wwv_flow_api.g_varchar2_table(1579) := ' \lsdlocked0 toc 7;'||wwv_flow.LF||
'\lsdpriority39 \lsdlocked0 toc 8;\lsdpriority39 \lsdlocked0 toc 9;\lsdqformat1 ';
    wwv_flow_api.g_varchar2_table(1580) := '\lsdpriority35 \lsdlocked0 caption;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority10 \lsdl';
    wwv_flow_api.g_varchar2_table(1581) := 'ocked0 Title;\lsdpriority1 \lsdlocked0 Default Paragraph Font;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(1582) := 'qformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriori';
    wwv_flow_api.g_varchar2_table(1583) := 'ty22 \lsdlocked0 Strong;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority20 \lsdlocked0 Emph';
    wwv_flow_api.g_varchar2_table(1584) := 'asis;'||wwv_flow.LF||
'\lsdpriority59 \lsdlocked0 Table Grid;\lsdunhideused0 \lsdlocked0 Placeholder Text;\lsdsemihi';
    wwv_flow_api.g_varchar2_table(1585) := 'dden0 \lsdunhideused0 \lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdsemihidden0 \lsdunhideus';
    wwv_flow_api.g_varchar2_table(1586) := 'ed0 \lsdpriority60 \lsdlocked0 Light Shading;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlo';
    wwv_flow_api.g_varchar2_table(1587) := 'cked0 Light List;\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid;\lsdsemihidde';
    wwv_flow_api.g_varchar2_table(1588) := 'n0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \ls';
    wwv_flow_api.g_varchar2_table(1589) := 'dpriority64 \lsdlocked0 Medium Shading 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 ';
    wwv_flow_api.g_varchar2_table(1590) := 'Medium List 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2;'||wwv_flow.LF||
'\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1591) := 'den0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(1592) := 'iority68 \lsdlocked0 Medium Grid 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium';
    wwv_flow_api.g_varchar2_table(1593) := ' Grid 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List;\lsdsemihidden0 \lsdu';
    wwv_flow_api.g_varchar2_table(1594) := 'nhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading;\lsdsemihidden0 \lsdunhideused0 \lsdpriority7';
    wwv_flow_api.g_varchar2_table(1595) := '2 \lsdlocked0 Colorful List;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Gr';
    wwv_flow_api.g_varchar2_table(1596) := 'id;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 1;\lsdsemihidden0';
    wwv_flow_api.g_varchar2_table(1597) := ' \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \l';
    wwv_flow_api.g_varchar2_table(1598) := 'sdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlock';
    wwv_flow_api.g_varchar2_table(1599) := 'ed0 Medium Shading 1 Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shad';
    wwv_flow_api.g_varchar2_table(1600) := 'ing 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 1;\';
    wwv_flow_api.g_varchar2_table(1601) := 'lsdunhideused0 \lsdlocked0 Revision;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority34 \lsd';
    wwv_flow_api.g_varchar2_table(1602) := 'locked0 List Paragraph;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority29 \lsdlocked0 Quo';
    wwv_flow_api.g_varchar2_table(1603) := 'te;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority30 \lsdlocked0 Intense Quote;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1604) := 'den0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideu';
    wwv_flow_api.g_varchar2_table(1605) := 'sed0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority6';
    wwv_flow_api.g_varchar2_table(1606) := '8 \lsdlocked0 Medium Grid 2 Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medi';
    wwv_flow_api.g_varchar2_table(1607) := 'um Grid 3 Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 1;\';
    wwv_flow_api.g_varchar2_table(1608) := 'lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 1;\lsdsemihidden0 ';
    wwv_flow_api.g_varchar2_table(1609) := '\lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 1;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1610) := '\lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \ls';
    wwv_flow_api.g_varchar2_table(1611) := 'dlocked0 Light Shading Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light Lis';
    wwv_flow_api.g_varchar2_table(1612) := 't Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 2;\lsdsemi';
    wwv_flow_api.g_varchar2_table(1613) := 'hidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 2;\lsdsemihidden0 \lsdunh';
    wwv_flow_api.g_varchar2_table(1614) := 'ideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsd';
    wwv_flow_api.g_varchar2_table(1615) := 'priority65 \lsdlocked0 Medium List 1 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdloc';
    wwv_flow_api.g_varchar2_table(1616) := 'ked0 Medium List 2 Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1';
    wwv_flow_api.g_varchar2_table(1617) := ' Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 2;\lsdse';
    wwv_flow_api.g_varchar2_table(1618) := 'mihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(1619) := 'deused0 \lsdpriority70 \lsdlocked0 Dark List Accent 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority';
    wwv_flow_api.g_varchar2_table(1620) := '71 \lsdlocked0 Colorful Shading Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 ';
    wwv_flow_api.g_varchar2_table(1621) := 'Colorful List Accent 2;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Acce';
    wwv_flow_api.g_varchar2_table(1622) := 'nt 2;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 3;\lsdsemihid';
    wwv_flow_api.g_varchar2_table(1623) := 'den0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 3;\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1624) := '\lsdpriority62 \lsdlocked0 Light Grid Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsd';
    wwv_flow_api.g_varchar2_table(1625) := 'locked0 Medium Shading 1 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium ';
    wwv_flow_api.g_varchar2_table(1626) := 'Shading 2 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 3';
    wwv_flow_api.g_varchar2_table(1627) := ';'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 3;\lsdsemihidden0';
    wwv_flow_api.g_varchar2_table(1628) := ' \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(1629) := 'lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 3;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \l';
    wwv_flow_api.g_varchar2_table(1630) := 'sdlocked0 Medium Grid 3 Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark Lis';
    wwv_flow_api.g_varchar2_table(1631) := 't Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 3;'||wwv_flow.LF||
'\l';
    wwv_flow_api.g_varchar2_table(1632) := 'sdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 3;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(1633) := 'unhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdsemihidden0 \lsdunhideused0 \lsdpr';
    wwv_flow_api.g_varchar2_table(1634) := 'iority60 \lsdlocked0 Light Shading Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdloc';
    wwv_flow_api.g_varchar2_table(1635) := 'ked0 Light List Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accen';
    wwv_flow_api.g_varchar2_table(1636) := 't 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 4;'||wwv_flow.LF||
'\lsdsemih';
    wwv_flow_api.g_varchar2_table(1637) := 'idden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 4;\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(1638) := 'deused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriori';
    wwv_flow_api.g_varchar2_table(1639) := 'ty66 \lsdlocked0 Medium List 2 Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0';
    wwv_flow_api.g_varchar2_table(1640) := ' Medium Grid 1 Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Acc';
    wwv_flow_api.g_varchar2_table(1641) := 'ent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;'||wwv_flow.LF||
'\lsdsemihi';
    wwv_flow_api.g_varchar2_table(1642) := 'dden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 4;\lsdsemihidden0 \lsdunhideused0 ';
    wwv_flow_api.g_varchar2_table(1643) := '\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 ';
    wwv_flow_api.g_varchar2_table(1644) := '\lsdlocked0 Colorful List Accent 4;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colo';
    wwv_flow_api.g_varchar2_table(1645) := 'rful Grid Accent 4;\lsdsemihidden0 \lsdunhideused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 5';
    wwv_flow_api.g_varchar2_table(1646) := ';\lsdsemihidden0 \lsdunhideused0 \lsdpriority61 \lsdlocked0 Light List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \l';
    wwv_flow_api.g_varchar2_table(1647) := 'sdunhideused0 \lsdpriority62 \lsdlocked0 Light Grid Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpri';
    wwv_flow_api.g_varchar2_table(1648) := 'ority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdloc';
    wwv_flow_api.g_varchar2_table(1649) := 'ked0 Medium Shading 2 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium L';
    wwv_flow_api.g_varchar2_table(1650) := 'ist 1 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 5;\ls';
    wwv_flow_api.g_varchar2_table(1651) := 'dsemihidden0 \lsdunhideused0 \lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \ls';
    wwv_flow_api.g_varchar2_table(1652) := 'dunhideused0 \lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdp';
    wwv_flow_api.g_varchar2_table(1653) := 'riority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlock';
    wwv_flow_api.g_varchar2_table(1654) := 'ed0 Dark List Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading';
    wwv_flow_api.g_varchar2_table(1655) := ' Accent 5;\lsdsemihidden0 \lsdunhideused0 \lsdpriority72 \lsdlocked0 Colorful List Accent 5;\lsdsemi';
    wwv_flow_api.g_varchar2_table(1656) := 'hidden0 \lsdunhideused0 \lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhi';
    wwv_flow_api.g_varchar2_table(1657) := 'deused0 \lsdpriority60 \lsdlocked0 Light Shading Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriori';
    wwv_flow_api.g_varchar2_table(1658) := 'ty61 \lsdlocked0 Light List Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority62 \lsdlocked0 Ligh';
    wwv_flow_api.g_varchar2_table(1659) := 't Grid Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority63 \lsdlocked0 Medium Shading 1 Accent';
    wwv_flow_api.g_varchar2_table(1660) := ' 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 6;\lsdsemihidd';
    wwv_flow_api.g_varchar2_table(1661) := 'en0 \lsdunhideused0 \lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideus';
    wwv_flow_api.g_varchar2_table(1662) := 'ed0 \lsdpriority66 \lsdlocked0 Medium List 2 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority67';
    wwv_flow_api.g_varchar2_table(1663) := ' \lsdlocked0 Medium Grid 1 Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority68 \lsdlocked0 Mediu';
    wwv_flow_api.g_varchar2_table(1664) := 'm Grid 2 Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdpriority69 \lsdlocked0 Medium Grid 3 Accent ';
    wwv_flow_api.g_varchar2_table(1665) := '6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority70 \lsdlocked0 Dark List Accent 6;\lsdsemihidden0 \lsd';
    wwv_flow_api.g_varchar2_table(1666) := 'unhideused0 \lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \';
    wwv_flow_api.g_varchar2_table(1667) := 'lsdpriority72 \lsdlocked0 Colorful List Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdpriority73 \lsd';
    wwv_flow_api.g_varchar2_table(1668) := 'locked0 Colorful Grid Accent 6;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority19 \lsdlocke';
    wwv_flow_api.g_varchar2_table(1669) := 'd0 Subtle Emphasis;'||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority21 \lsdlocked0 Intense';
    wwv_flow_api.g_varchar2_table(1670) := ' Emphasis;\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority31 \lsdlocked0 Subtle Reference;';
    wwv_flow_api.g_varchar2_table(1671) := ''||wwv_flow.LF||
'\lsdsemihidden0 \lsdunhideused0 \lsdqformat1 \lsdpriority32 \lsdlocked0 Intense Reference;\lsdsemih';
    wwv_flow_api.g_varchar2_table(1672) := 'idden0 \lsdunhideused0 \lsdqformat1 \lsdpriority33 \lsdlocked0 Book Title;\lsdpriority37 \lsdlocked0';
    wwv_flow_api.g_varchar2_table(1673) := ' Bibliography;'||wwv_flow.LF||
'\lsdqformat1 \lsdpriority39 \lsdlocked0 TOC Heading;}}{\*\datastore 0105000002000000';
    wwv_flow_api.g_varchar2_table(1674) := '180000004d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000'||wwv_flow.LF||
'd0cf11e0a1b11ae100';
    wwv_flow_api.g_varchar2_table(1675) := '0000000000000000000000000000003e000300feff0900060000000000000000000000010000000100000000000000001000';
    wwv_flow_api.g_varchar2_table(1676) := '00feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1677) := 'ffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1678) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1679) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffff';
    wwv_flow_api.g_varchar2_table(1680) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1681) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1682) := 'ffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1683) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1684) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ff';
    wwv_flow_api.g_varchar2_table(1685) := 'fffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1686) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1687) := 'ffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1688) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1689) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1690) := 'ffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1691) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1692) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1693) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1694) := 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1695) := 'ffffffffffff'||wwv_flow.LF||
'ffffffffffffffffffffffffffffffff52006f006f007400200045006e0074007200790000000000000000';
    wwv_flow_api.g_varchar2_table(1696) := '0000000000000000000000000000000000000000000000000000000000000000000000000016000500ffffffffffffffffff';
    wwv_flow_api.g_varchar2_table(1697) := 'ffffff0c6ad98892f1d411a65f0040963251e500000000000000000000000000d9'||wwv_flow.LF||
'48d519acd701feffffff000000000000';
    wwv_flow_api.g_varchar2_table(1698) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1699) := '0000000000000000000000000000000000000000ffffffffffffffffffffffff000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1700) := '00000000000000000000'||wwv_flow.LF||
'000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1701) := '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff';
    wwv_flow_api.g_varchar2_table(1702) := 'ffffffffffffffffffffff0000000000000000000000000000000000000000000000000000'||wwv_flow.LF||
'000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1703) := '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
    wwv_flow_api.g_varchar2_table(1704) := '00000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000';
    wwv_flow_api.g_varchar2_table(1705) := '0000000000000000000000000000'||wwv_flow.LF||
'0000000000000000000000000000000000000000000000000105000000000000}}';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.4'
,p_default_workspace_id=>20952813001415487158
,p_default_application_id=>141546
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DDD451261366WORKSPACE'
);
wwv_flow_api.create_report_layout(
 p_id=>wwv_flow_api.id(34820929501495509834)
,p_report_layout_name=>'period_wise_sales_report'
,p_report_layout_type=>'RTF_FILE'
,p_varchar2_table=>wwv_flow_api.g_varchar2_table
);
null;
wwv_flow_api.component_end;
end;
/
